<?php

declare(strict_types=1);

/**
 *  _                               _ _
 * | |   _   _ _ __   __ _ _ __ ___| | |_   _
 * | |  | | | |  _ \ / _  |  __/ _ \ | | | | |
 * | |__| |_| | | | | (_| | | |  __/ | | |_| |
 * |_____\____|_| |_|\____|_|  \___|_|_|\___ |
 *                                      |___/
 *
 * @author Lunarelly
 * @link https://github.com/Lunarelly
 *
 */

namespace antralia\core\form;

use pocketmine\form\FormValidationException;

class SimpleForm extends AbstractForm
{

    /**
     * @var int
     */
    public const IMAGE_TYPE_NONE = -1;

    /**
     * @var int
     */
    public const IMAGE_TYPE_PATH = 0;

    /**
     * @var int
     */
    public const IMAGE_TYPE_URL = 1;

    /**
     * @var string
     */
    private string $content = "";

    /**
     * @var array
     */
    private array $labelMap = [];

    /**
     * @param callable|null $callable
     */
    public function __construct(?callable $callable)
    {
        parent::__construct($callable);

        $this->data["type"] = "form";
        $this->data["title"] = "";
        $this->data["content"] = $this->content;
        $this->data["buttons"] = [];
    }

    /**
     * @param mixed $data
     * @return void
     */
    public function processData(mixed &$data): void
    {
        if ($data !== null) {
            if (!(is_int($data))) {
                $data = intval($data);
            }

            $count = count($this->data["buttons"]);

            if ($data >= $count || $data < 0) {
                throw new FormValidationException("Button " . $data . " does not exist");
            }

            $data = $this->labelMap[$data] ?? null;
        }
    }

    /**
     * @param string $title
     * @return void
     */
    public function setTitle(string $title): void
    {
        $this->data["title"] = $title;
    }

    /**
     * @return string
     */
    public function getTitle(): string
    {
        return $this->data["title"];
    }

    /**
     * @return string
     */
    public function getContent(): string
    {
        return $this->data["content"];
    }

    /**
     * @param string $content
     * @return void
     */
    public function setContent(string $content): void
    {
        $this->data["content"] = $content;
    }

    /**
     * @param string $text
     * @param int $imageType
     * @param string $imagePath
     * @param string|null $label
     * @return void
     */
    public function addButton(string $text, int $imageType = self::IMAGE_TYPE_NONE, string $imagePath = "", ?string $label = null): void
    {
        if ($imageType !== self::IMAGE_TYPE_NONE && $imageType !== self::IMAGE_TYPE_PATH && $imageType !== self::IMAGE_TYPE_URL) {
            throw new FormValidationException("Unknown image type: " . $imageType);
        }

        $content = ["text" => $text];

        if ($imageType !== self::IMAGE_TYPE_NONE) {
            $content["image"]["type"] = $imageType === self::IMAGE_TYPE_PATH ? "path" : "url";
            $content["image"]["data"] = $imagePath;
        }

        $this->data["buttons"][] = $content;
        $this->labelMap[] = $label ?? count($this->labelMap);
    }
}