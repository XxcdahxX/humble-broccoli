<?php

declare(strict_types=1);

/**
 *  _                               _ _
 * | |   _   _ _ __   __ _ _ __ ___| | |_   _
 * | |  | | | |  _ \ / _  |  __/ _ \ | | | | |
 * | |__| |_| | | | | (_| | | |  __/ | | |_| |
 * |_____\____|_| |_|\____|_|  \___|_|_|\___ |
 *                                      |___/
 *
 * @author Lunarelly
 * @link https://github.com/Lunarelly
 *
 */

namespace antralia\core\form;

class ModalForm extends AbstractForm
{

    /**
     * @var string
     */
    private string $content = "";

    /**
     * @param callable|null $callable
     */
    public function __construct(?callable $callable)
    {
        parent::__construct($callable);

        $this->data["type"] = "modal";
        $this->data["title"] = "";
        $this->data["content"] = $this->content;
        $this->data["button1"] = "";
        $this->data["button2"] = "";
    }

    /**
     * @param mixed $data
     * @return void
     */
    public function processData(mixed &$data): void
    {
        if ($data !== null) {
            if (!(is_bool($data))) {
                $data = boolval($data);
            }
        }
    }

    /**
     * @param string $title
     * @return void
     */
    public function setTitle(string $title): void
    {
        $this->data["title"] = $title;
    }

    /**
     * @return string
     */
    public function getTitle(): string
    {
        return $this->data["title"];
    }

    /**
     * @return string
     */
    public function getContent(): string
    {
        return $this->data["content"];
    }

    /**
     * @param string $content
     * @return void
     */
    public function setContent(string $content): void
    {
        $this->data["content"] = $content;
    }

    /**
     * @param string $text
     * @return void
     */
    public function setFirstButton(string $text): void
    {
        $this->data["button1"] = $text;
    }

    /**
     * @return string
     */
    public function getFirstButton(): string
    {
        return $this->data["button1"];
    }

    /**
     * @param string $text
     * @return void
     */
    public function setSecondButton(string $text): void
    {
        $this->data["button2"] = $text;
    }

    /**
     * @return string
     */
    public function getSecondButton(): string
    {
        return $this->data["button2"];
    }
}