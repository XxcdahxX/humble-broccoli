<?php

declare(strict_types=1);

/**
 *  _                               _ _
 * | |   _   _ _ __   __ _ _ __ ___| | |_   _
 * | |  | | | |  _ \ / _  |  __/ _ \ | | | | |
 * | |__| |_| | | | | (_| | | |  __/ | | |_| |
 * |_____\____|_| |_|\____|_|  \___|_|_|\___ |
 *                                      |___/
 *
 * @author Lunarelly
 * @link https://github.com/Lunarelly
 *
 */

namespace antralia\core\telegram;

use pocketmine\Server;

class Telegram
{

    /**
     * @var string
     */
    private const TOKEN = "5152469017:AAEhglBd6ENmrhbsH71ITd3rwSgWKf0-NRw";

    /**
     * @var string
     */
    private const CHANNEL_ID = "-1001733711111";

    /**
     * Nothing there.
     */
    private function __construct()
    {
    }

    /**
     * @param string $link
     * @return void
     */
    public static function curl(string $link): void
    {
        $curl = curl_init($link);

        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

        curl_exec($curl);
        curl_close($curl);
    }

    /**
     * @param string $message
     * @return void
     */
    public static function sendMessage(string $message): void
    {
        $message = str_replace([" ", "\n"], ["%20", "%0A"], $message);
        $link = "https://api.telegram.org/bot" . self::TOKEN . "/sendMessage?chat_id=" . self::CHANNEL_ID . "&text=" . $message;
        $task = new TelegramAsyncTask($link);

        Server::getInstance()->getAsyncPool()->submitTask($task);
    }
}