<?php

declare(strict_types=1);

/**
 *  _                               _ _
 * | |   _   _ _ __   __ _ _ __ ___| | |_   _
 * | |  | | | |  _ \ / _  |  __/ _ \ | | | | |
 * | |__| |_| | | | | (_| | | |  __/ | | |_| |
 * |_____\____|_| |_|\____|_|  \___|_|_|\___ |
 *                                      |___/
 *
 * @author Lunarelly
 * @link https://github.com/Lunarelly
 *
 */

namespace antralia\core\telegram;

use pocketmine\scheduler\AsyncTask;

class TelegramAsyncTask extends AsyncTask
{

    /**
     * @var string
     */
    private string $link;

    /**
     * @param string $link
     */
    public function __construct(string $link)
    {
        $this->link = $link;
    }

    /**
     * @return void
     */
    public function onRun(): void
    {
        Telegram::curl($this->link);
    }
}