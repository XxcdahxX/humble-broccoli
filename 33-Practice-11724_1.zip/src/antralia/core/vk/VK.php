<?php

declare(strict_types=1);

/**
 *  _                               _ _
 * | |   _   _ _ __   __ _ _ __ ___| | |_   _
 * | |  | | | |  _ \ / _  |  __/ _ \ | | | | |
 * | |__| |_| | | | | (_| | | |  __/ | | |_| |
 * |_____\____|_| |_|\____|_|  \___|_|_|\___ |
 *                                      |___/
 *
 * @author Lunarelly
 * @link https://github.com/Lunarelly
 *
 */

namespace antralia\core\vk;

use pocketmine\Server;

class VK
{

    /**
     * @var string
     */
    private const TOKEN = "d44486c99a8d820a27d000cfffcd923b4b845be05587e6fb0d7f24ed9f663aff48ab6cd27d319cd6c3008";

    /**
     * @var int
     */
    private const CHAT_ID = 1;

    /**
     * @var int
     */
    private const RANDOM_ID = 0;

    /**
     * Nothing there.
     */
    private function __construct()
    {
    }

    /**
     * @param string $link
     * @return void
     */
    public static function curl(string $link): void
    {
        $curl = curl_init($link);

        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

        curl_exec($curl);
        curl_close($curl);
    }

    /**
     * @param string $message
     * @return void
     */
    public static function sendMessage(string $message): void
    {
        $message = str_replace([" ", "\n"], ["%20", "%0A"], $message);

        $link = "https://api.vk.com/method/messages.send?chat_id=" . self::CHAT_ID . "&message=" . $message . "&access_token=" . self::TOKEN . "&v=5.131&random_id=" . self::RANDOM_ID;
        $task = new VKAsyncTask($link);
        Server::getInstance()->getAsyncPool()->submitTask($task);
    }
}