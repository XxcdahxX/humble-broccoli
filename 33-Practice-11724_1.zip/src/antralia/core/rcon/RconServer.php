<?php

declare(strict_types=1);

/**
 *
 *  ____            _        _   __  __ _                  __  __ ____
 * |  _ \ ___   ___| | _____| |_|  \/  (_)_ __   ___      |  \/  |  _ \
 * | |_) / _ \ / __| |/ / _ \ __| |\/| | | '_ \ / _ \_____| |\/| | |_) |
 * |  __/ (_) | (__|   <  __/ |_| |  | | | | | |  __/_____| |  | |  __/
 * |_|   \___/ \___|_|\_\___|\__|_|  |_|_|_| |_|\___|     |_|  |_|_|
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * @author PocketMine Team
 * @link http://www.pocketmine.net/
 *
 *
 */

namespace antralia\core\rcon;

use pocketmine\plugin\PluginBase;

class RconServer
{

    /**
     * @var string
     */
    private const PASSWORD = "818F174DAC0F65AE65";

    /**
     * @var int
     */
    private const MAX_CONNECTIONS = 35;

    /**
     * @var PluginBase
     */
    private PluginBase $plugin;

    /**
     * @param PluginBase $plugin
     */
    public function __construct(PluginBase $plugin)
    {
        $this->plugin = $plugin;
        $ip = $plugin->getServer()->getIp();
        $port = $plugin->getServer()->getPort();
		$plugin->getLogger()->info("RCON running on " . $ip . ":" . $port);
		try {
			$plugin->getServer()->getNetwork()->registerInterface(new Rcon(
				$ip,
                $port,
                self::PASSWORD,
                self::MAX_CONNECTIONS,
				function (string $commandLine): string {
					$response = new RconCommandSender($this->plugin->getServer(), $this->plugin->getServer()->getLanguage());
					$response->recalculatePermissions();
					$this->plugin->getServer()->dispatchCommand($response, $commandLine);

					return $response->getMessage();
				},
				$plugin->getServer()->getLogger(),
				$plugin->getServer()->getTickSleeper()
			));
		} catch (RconException $exception) {
			$plugin->getLogger()->alert("Failed to start RCON: " . $exception->getMessage());
			$plugin->getLogger()->logException($exception);
			return;
		}
	}
}