<?php

declare(strict_types=1);

/**
 *  _                               _ _
 * | |   _   _ _ __   __ _ _ __ ___| | |_   _
 * | |  | | | |  _ \ / _  |  __/ _ \ | | | | |
 * | |__| |_| | | | | (_| | | |  __/ | | |_| |
 * |_____\____|_| |_|\____|_|  \___|_|_|\___ |
 *                                      |___/
 *
 * @author Lunarelly
 * @link https://github.com/Lunarelly
 *
 */

namespace antralia\core\scoreboard;

use pocketmine\network\mcpe\protocol\RemoveObjectivePacket;
use pocketmine\network\mcpe\protocol\SetDisplayObjectivePacket;
use pocketmine\network\mcpe\protocol\SetScorePacket;
use pocketmine\network\mcpe\protocol\types\ScorePacketEntry;
use pocketmine\player\Player;
use pocketmine\Server;

class Scoreboard
{

    /**
     * @var string
     */
    private const OBJECTIVE_NAME = "objective";

    /**
     * @var string
     */
    private const CRITERIA_NAME = "dummy";

    /**
     * @var int
     */
    private const MIN_LINES = 1;

    /**
     * @var int
     */
    private const MAX_LINES = 15;

    /**
     * @var int
     */
    public const SORT_ASCENDING = 0;

    /**
     * @var int
     */
    public const SORT_DESCENDING = 1;

    /**
     * @var string
     */
    public const SLOT_LIST = "list";

    /**
     * @var string
     */
    public const SLOT_SIDEBAR = "sidebar";

    /**
     * @var string
     */
    public const SLOT_BELOW_NAME = "belowname";

    /**
     * @var array<string, string>
     */
    private static array $scoreboards = array();

    /**
     * Nothing there.
     */
    private function __construct()
    {
    }

    /**
     * @param Player $player
     * @param string $displayName
     * @param int $slotOrder
     * @param string $displaySlot
     * @return void
     */
    public static function setScore(Player $player, string $displayName, int $slotOrder = self::SORT_ASCENDING, string $displaySlot = self::SLOT_SIDEBAR): void
    {
        if (isset(self::$scoreboards[$player->getName()])) {
            self::removeScorePacket($player);
        }

        $packet = new SetDisplayObjectivePacket();
        $packet->displaySlot = $displaySlot;
        $packet->objectiveName = self::OBJECTIVE_NAME;
        $packet->displayName = $displayName;
        $packet->criteriaName = self::CRITERIA_NAME;
        $packet->sortOrder = $slotOrder;
        $player->getNetworkSession()->sendDataPacket($packet);

        if (!(isset(self::$scoreboards[$player->getName()]))) {
            self::$scoreboards[$player->getName()] = self::OBJECTIVE_NAME;
        }
    }

    /**
     * @param Player $player
     * @return void
     */
    public static function removeScore(Player $player): void
    {
        $packet = new RemoveObjectivePacket();
        $packet->objectiveName = self::OBJECTIVE_NAME;
        $player->getNetworkSession()->sendDataPacket($packet);

        if (isset(self::$scoreboards[$player->getName()])) {
            unset(self::$scoreboards[$player->getName()]);
        }
    }

    /**
     * @param Player $player
     * @return void
     */
    public static function removeScorePacket(Player $player): void
    {
        $packet = new RemoveObjectivePacket();
        $packet->objectiveName = self::OBJECTIVE_NAME;
        $player->getNetworkSession()->sendDataPacket($packet);
    }

    /**
     * @param Player $player
     * @return void
     */
    public static function removeScoreFromArray(Player $player): void
    {
        if (isset(self::$scoreboards[$player->getName()])) {
            unset(self::$scoreboards[$player->getName()]);
        }
    }

    /**
     * @return array
     */
    public static function getScoreboards(): array
    {
        return self::$scoreboards;
    }

    /**
     * @param Player $player
     * @return bool
     */
    public static function hasScore(Player $player): bool
    {
        return isset(self::$scoreboards[$player->getName()]);
    }

    /**
     * @param Player $player
     * @param int $line
     * @param string $message
     * @return void
     */
    public static function setScoreLine(Player $player, int $line, string $message): void
    {
        if (!(isset(self::$scoreboards[$player->getName()]))) {
            Server::getInstance()->getLogger()->error("Cannot set a score to a player with no scoreboard");
            return;
        }

        if ($line < self::MIN_LINES || $line > self::MAX_LINES){
            Server::getInstance()->getLogger()->error("Score must be between the value of " . self::MIN_LINES .  " to " . self::MAX_LINES . ".");
            Server::getInstance()->getLogger()->error($line . " is out of range");
            return;
        }

        $entry = new ScorePacketEntry();
        $entry->objectiveName = self::OBJECTIVE_NAME;
        $entry->type = $entry::TYPE_FAKE_PLAYER;
        $entry->customName = $message;
        $entry->score = $line;
        $entry->scoreboardId = $line;

        $packet = new SetScorePacket();
        $packet->type = $packet::TYPE_CHANGE;
        $packet->entries[] = $entry;

        $player->getNetworkSession()->sendDataPacket($packet);
    }
}