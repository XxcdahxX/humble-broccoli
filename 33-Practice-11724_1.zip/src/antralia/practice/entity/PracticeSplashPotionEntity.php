<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\entity;

use antralia\practice\player\PracticePlayer;
use antralia\practice\PracticePlugin;
use antralia\practice\utils\PracticeUtils;
use pocketmine\color\Color;
use pocketmine\entity\effect\InstantEffect;
use pocketmine\entity\Entity;
use pocketmine\entity\projectile\SplashPotion;
use pocketmine\event\entity\ProjectileHitEntityEvent;
use pocketmine\event\entity\ProjectileHitEvent;
use pocketmine\world\particle\PotionSplashParticle;
use pocketmine\world\sound\PotionSplashSound;

final class PracticeSplashPotionEntity extends SplashPotion
{

    /**
     * @var float
     */
    public const MAX_HIT = 1.3055;

    /**
     * @var float
     */
    public const MAX_MISS = 1.2015;

    /**
     * @var float
     */
    protected $gravity = 0.06;

    /**
     * @var float
     */
    protected $drag = 0.01;

    /**
     * @return void
     */
    public function spawnToAll(): void
    {
        $entity = $this->getOwningEntity();
        $plugin = PracticePlugin::getInstance();
        $ffaManager = $plugin->getFFAManager();
        $viewers = $this->getWorld()->getViewersForPosition($this->getLocation());

        foreach ($viewers as $player) {
            if (!($player instanceof PracticePlayer)) {
                continue;
            }

            if (!($player->isConnected())) {
                continue;
            }

            if ($this->getOwningEntityId() === $player->getId()) {
                $this->spawnTo($player);
                continue;
            }

            if ($entity instanceof PracticePlayer) {
                if ($ffaManager->getEnemyName($entity) === $player->getName()) {
                    $this->spawnTo($player);
                    continue;
                }
            }

            if (!($plugin->getTogglesManager()->getToggleStatus($player, "hide_players") && $ffaManager->isInCombat($player))) {
                $this->spawnTo($player);
            }
        }
    }

    /**
     * @param Entity $entity
     * @return bool
     */
    public function canCollideWith(Entity $entity): bool
    {
        if (!(parent::canCollideWith($entity))) {
            return false;
        }

        $ffaManager = PracticePlugin::getInstance()->getFFAManager();
        $owningEntity = $this->getOwningEntity();

        if ($entity instanceof PracticePlayer && $owningEntity instanceof PracticePlayer) {
            if ($entity->getId() === $this->getOwningEntityId()) {
                return true;
            }

            if ($entity->getName() === $ffaManager->getEnemyName($owningEntity)) {
                return true;
            }

            if ($ffaManager->getEnemyName($owningEntity) !== "" && $ffaManager->isInCombat($owningEntity)) {
                return false;
            }
        }
        return true;
    }

    /**
     * @param ProjectileHitEvent $event
     * @return void
     */
    protected function onHit(ProjectileHitEvent $event): void
    {
        $effects = $this->getPotionEffects();
        $hasEffects = true;

        if (count($effects) === 0) {
            $particle = new PotionSplashParticle(PotionSplashParticle::DEFAULT_COLOR());
            $hasEffects = false;
        } else {
            $owningEntity = $this->getOwningEntity();
            if ($owningEntity instanceof PracticePlayer) {
                $potionColorManager = PracticePlugin::getInstance()->getPotionColorManager();
                if ($potionColorManager->hasPotionColorFromArray($owningEntity)) {
                    $colors = [$potionColorManager->getPotionColorForGame($owningEntity)];
                } else {
                    $colors = [];
                    foreach ($effects as $effect) {
                        for ($i = 0; $i < $effect->getEffectLevel(); ++$i) {
                            $colors[] = $effect->getColor();
                        }
                    }
                }
            } else {
                $colors = [];
                foreach ($effects as $effect) {
                    for ($i = 0; $i < $effect->getEffectLevel(); ++$i) {
                        $colors[] = $effect->getColor();
                    }
                }
            }
            $particle = new PotionSplashParticle(Color::mix(...$colors));
        }

        $viewers = PracticeUtils::getViewersForFFAEntity($this);
        $this->getWorld()->addParticle($this->getLocation(), $particle, $viewers);
        $this->broadcastSound(new PotionSplashSound(), $viewers);

        if ($hasEffects) {
            $entityHitId = null;
            if ($event instanceof ProjectileHitEntityEvent) {
                $entityHit = $event->getEntityHit();
                if ($entityHit instanceof PracticePlayer) {
                    $entityHitId = $entityHit->getId();
                }
            }

            foreach ($this->getWorld()->getNearbyEntities($this->getBoundingBox()->expandedCopy(1.85, 2.65, 1.85)) as $nearby) {
                if ($nearby instanceof PracticePlayer) {
                    if ($nearby->isAlive() and !($nearby->isImmobile())) {
                        $enemy = PracticePlugin::getInstance()->getFFAManager()->getEnemy($nearby);
                        if ($enemy instanceof PracticePlayer) {
                            if ($nearby->getId() !== $this->getOwningEntityId() && $enemy->getId() !== $this->getOwningEntityId()) {
                                return;
                            }
                        }
                        foreach ($this->getPotionEffects() as $effect) {
                            if (!($effect->getType() instanceof InstantEffect)) {
                                $newDuration = (int) round($effect->getDuration() * 0.75 * ($nearby->getId() === $entityHitId ? self::MAX_HIT : self::MAX_MISS));
                                if ($newDuration < 20) {
                                    continue;
                                }

                                $effect->setDuration($newDuration);
                                $nearby->getEffects()->add($effect);
                            } else {
                                $effect->getType()->applyEffect($nearby, $effect, $nearby->getId() === $entityHitId ? self::MAX_HIT : self::MAX_MISS, $this);
                            }
                        }
                    }
                }
            }
        }
    }
}