<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\entity;

use antralia\practice\player\PracticePlayer;
use antralia\practice\PracticePlugin;
use pocketmine\entity\Human;
use pocketmine\entity\Location;
use pocketmine\entity\Skin;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\timings\Timings;

final class FakeDeadHuman extends Human
{

    /**
     * @var Location
     */
    private Location $damagerLocation;

    /**
     * @param Location $location
     * @param Skin $skin
     * @param Location $damagerLocation
     * @param CompoundTag|null $nbt
     */
    public function __construct(Location $location, Skin $skin, Location $damagerLocation, ?CompoundTag $nbt = null)
    {
        $this->damagerLocation = $damagerLocation;
        parent::__construct($location, $skin, $nbt);
    }

    /**
     * @return Location
     */
    public function getDamagerLocation(): Location
    {
        return $this->damagerLocation;
    }

    /**
     * @return void
     */
    public function spawnToAll(): void
    {
        $plugin = PracticePlugin::getInstance();
        $location = $this->getLocation();
        $damagerLocation = $this->getDamagerLocation();

        foreach ($this->getWorld()->getViewersForPosition($location) as $player) {
            if (!($player instanceof PracticePlayer)) {
                continue;
            }

            if (!($player->isConnected())) {
                continue;
            }

            if (!($plugin->getTogglesManager()->getToggleStatus($player, "hide_players") && $plugin->getFFAManager()->isInCombat($player))) {
                $this->spawnTo($player);
            }
        }

        $this->kill();
        $this->knockBack($location->getX() - $damagerLocation->getX(), $location->getZ() - $damagerLocation->getZ(), 0.32);
    }

    /**
     * @return bool
     */
    public function canSaveWithChunk(): bool
    {
        return false;
    }

    /**
     * @return bool
     */
    public function isNameTagVisible(): bool
    {
        return false;
    }

    /**
     * @param int $currentTick
     * @return bool
     */
    public function onUpdate(int $currentTick): bool
    {
        if ($this->closed) {
            return false;
        }

        $tickDiff = $currentTick - $this->lastUpdate;
        if ($tickDiff <= 0) {
            if (!($this->justCreated)) {
                $this->server->getLogger()->debug("Expected tick difference of at least 1, got " . $tickDiff . " for " . get_class($this));
            }
            return true;
        }

        $this->lastUpdate = $currentTick;

        if (!($this->isAlive())) {
            if ($this->onDeathUpdate($tickDiff)) {
                $this->flagForDespawn();
            }
        }

        $this->timings->startTiming();

        if ($this->hasMovementUpdate()) {
            $this->tryChangeMovement();

            $this->motion = $this->motion->withComponents(
                abs($this->motion->x) <= self::MOTION_THRESHOLD ? 0 : null,
                abs($this->motion->y) <= self::MOTION_THRESHOLD ? 0 : null,
                abs($this->motion->z) <= self::MOTION_THRESHOLD ? 0 : null
            );

            if ($this->motion->x !== 0 || $this->motion->y !== 0 || $this->motion->z !== 0) {
                $this->move($this->motion->x, $this->motion->y, $this->motion->z);
            }
            $this->forceMovementUpdate = false;
        }

        $this->updateMovement();

        Timings::$entityBaseTick->startTiming();
        $hasUpdate = $this->entityBaseTick($tickDiff);
        Timings::$entityBaseTick->stopTiming();

        $this->timings->stopTiming();

        if ($this->ticksLived >= 25) {
            $this->close();
            return false;
        }

        return ($hasUpdate || $this->hasMovementUpdate());
    }
}