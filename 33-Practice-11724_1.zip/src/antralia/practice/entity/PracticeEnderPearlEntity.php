<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\entity;

use antralia\practice\player\PracticePlayer;
use antralia\practice\PracticePlugin;
use antralia\practice\utils\PracticeUtils;
use pocketmine\entity\Entity;
use pocketmine\entity\EntitySizeInfo;
use pocketmine\entity\projectile\EnderPearl;
use pocketmine\event\entity\ProjectileHitEvent;
use pocketmine\world\particle\EndermanTeleportParticle;
use pocketmine\world\sound\EndermanTeleportSound;

final class PracticeEnderPearlEntity extends EnderPearl
{

    /**
     * @return void
     */
    public function spawnToAll(): void
    {
        $entity = $this->getOwningEntity();
        $plugin = PracticePlugin::getInstance();
        $ffaManager = $plugin->getFFAManager();
        $viewers = $this->getWorld()->getViewersForPosition($this->getLocation());

        foreach ($viewers as $player) {
            if (!($player instanceof PracticePlayer)) {
                continue;
            }

            if (!($player->isConnected())) {
                continue;
            }

            if ($this->getOwningEntityId() === $player->getId()) {
                $this->spawnTo($player);
                continue;
            }

            if ($entity instanceof PracticePlayer) {
                if ($ffaManager->getEnemyName($entity) === $player->getName()) {
                    $this->spawnTo($player);
                    continue;
                }
            }

            if (!($plugin->getTogglesManager()->getToggleStatus($player, "hide_players") && $ffaManager->isInCombat($player))) {
                $this->spawnTo($player);
            }
        }
    }

    /**
     * @param ProjectileHitEvent $event
     * @return void
     */
    protected function onHit(ProjectileHitEvent $event): void
    {
        $entity = $this->getOwningEntity();

        if ($entity instanceof PracticePlayer) {
            $viewers = PracticeUtils::getViewersForFFAEntity($this);

            $this->getWorld()->addParticle($entity->getPosition(), new EndermanTeleportParticle(), $viewers);
            $this->getWorld()->addSound($entity->getPosition(), new EndermanTeleportSound(), $viewers);

            if ($entity->getWorld() === $this->getWorld()) {
                $entity->setPosition($event->getRayTraceResult()->getHitVector());
                $entity->getNetworkSession()->syncMovement($entity->getLocation(), $entity->getLocation()->getYaw(), $entity->getLocation()->getPitch());
            }

            $this->getWorld()->addSound($event->getRayTraceResult()->getHitVector(), new EndermanTeleportSound(), $viewers);
        } else {
            parent::onHit($event);
        }
    }

    /**
     * @param Entity $entity
     * @return bool
     */
    public function canCollideWith(Entity $entity): bool
    {
        if (!(parent::canCollideWith($entity))) {
            return false;
        }

        $ffaManager = PracticePlugin::getInstance()->getFFAManager();
        $owningEntity = $this->getOwningEntity();

        if ($entity instanceof PracticePlayer && $owningEntity instanceof PracticePlayer) {
            if ($entity->getId() === $this->getOwningEntityId()) {
                return true;
            }

            if ($entity->getName() === $ffaManager->getEnemyName($owningEntity)) {
                return true;
            }

            if ($ffaManager->getEnemyName($owningEntity) !== "" && $ffaManager->isInCombat($owningEntity)) {
                return false;
            }
        }
        return true;
    }

    /**
     * @return EntitySizeInfo
     */
    protected function getInitialSizeInfo(): EntitySizeInfo
    {
        return new EntitySizeInfo(0.1, 0.1);
    }
}