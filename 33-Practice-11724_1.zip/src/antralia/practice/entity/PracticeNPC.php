<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\entity;

use antralia\practice\emote\EmoteIds;
use pocketmine\entity\Human;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\network\mcpe\protocol\types\entity\EntityMetadataFlags;
use pocketmine\utils\Limits;
use pocketmine\world\ChunkLoader;

final class PracticeNPC extends Human implements ChunkLoader
{

    /**
     * @var float
     */
    private float $lastEmote = 0.0;

    /**
     * @var int
     */
    protected $gravity = 0;

    /**
     * @var array
     */
    private array $emotes = [
        EmoteIds::THE_ELYTRA,
        EmoteIds::BREAKDANCE,
        EmoteIds::CHUN_LI_SPINNING_KICK,
        EmoteIds::GIDDY
    ];

    /**
     * @param CompoundTag $nbt
     * @return void
     */
    protected function initEntity(CompoundTag $nbt): void
    {
        parent::initEntity($nbt);

        $this->getNetworkProperties()->setGenericFlag(EntityMetadataFlags::SILENT, true);

        $this->setImmobile();
        $this->setMaxHealth(Limits::INT32_MAX);
        $this->setHealth(Limits::INT32_MAX);
        $this->setNameTagVisible();
        $this->setNameTagAlwaysVisible();
        $this->setCanSaveWithChunk(true);
    }

    /**
     * @param int $currentTick
     * @return bool
     */
    public function onUpdate(int $currentTick): bool
    {
        if ((8.0 + $this->lastEmote) > microtime(true)) {
            return parent::onUpdate($currentTick);
        }

        $this->lastEmote = microtime(true);
        $this->emote($this->emotes[array_rand($this->emotes)]);

        return parent::onUpdate($currentTick);
    }

    /**
     * @param float $x
     * @param float $z
     * @param float $force
     * @param float|null $verticalLimit
     * @return void
     */
    public function knockBack(float $x, float $z, float $force = 0.4, ?float $verticalLimit = 0.4): void
    {
    }
}