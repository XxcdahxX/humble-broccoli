<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\entity;

use antralia\practice\player\PracticePlayer;
use antralia\practice\PracticePlugin;
use pocketmine\entity\Entity;
use pocketmine\entity\EntitySizeInfo;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\network\mcpe\protocol\types\entity\EntityIds;
use pocketmine\Server;

final class PracticeLightningBoltEntity extends Entity
{

    /**
     * @return void
     */
    public function spawnToAll(): void
    {
        $plugin = PracticePlugin::getInstance();
        $togglesManager = $plugin->getTogglesManager();
        $viewers = $this->getWorld()->getViewersForPosition($this->getLocation());

        foreach ($viewers as $player) {
            if (!($player instanceof PracticePlayer)) {
                continue;
            }

            if (!($player->isConnected())) {
                continue;
            }

            if ($togglesManager->getToggleStatus($player, "lightning")) {
                if (!($togglesManager->getToggleStatus($player, "hide_players") && $plugin->getFFAManager()->isInCombat($player))) {
                    $this->spawnTo($player);
                }
            }
        }

        $position = $this->getPosition();
        $sound = PlaySoundPacket::create(
            "ambient.weather.thunder",
            $position->getX(),
            $position->getY(),
            $position->getZ(),
            1,
            1
        );
        Server::getInstance()->broadcastPackets($togglesManager->getLightningViewers($viewers), [$sound]);
    }

    /**
     * @return EntitySizeInfo
     */
    protected function getInitialSizeInfo(): EntitySizeInfo
    {
        return new EntitySizeInfo(0.1, 0.1);
    }

    /**
     * @return string
     */
    public static function getNetworkTypeId(): string
    {
        return EntityIds::LIGHTNING_BOLT;
    }

    /**
     * @param int $currentTick
     * @return bool
     */
    public function onUpdate(int $currentTick): bool
    {
        parent::onUpdate($currentTick);

        if ($this->ticksLived >= 25) {
            $this->close();
            return false;
        }
        return true;
    }
}