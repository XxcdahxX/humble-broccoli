<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\emote;

final class EmoteIds
{

    /**
     * @var string
     */
    public const BREAKDANCE = "1dbaa006-0ec6-42c3-9440-a3bfa0c6fdbe";

    /**
     * @var string
     */
    public const GIDDY = "738497ce-539f-4e06-9a03-dc528506a468";

    /**
     * @var string
     */
    public const THE_ELYTRA = "7393aa53-9145-4e66-b23b-ec86def6c6f2";

    /**
     * @var string
     */
    public const CHUN_LI_SPINNING_KICK = "af61c759-6252-431d-a7de-94d477cfb54c";
}