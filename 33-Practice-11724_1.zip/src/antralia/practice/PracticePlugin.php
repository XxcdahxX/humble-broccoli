<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice;

use antralia\core\rcon\RconServer;
use antralia\practice\command\CommandListener;
use antralia\practice\entity\FakeDeadHuman;
use antralia\practice\entity\PracticeEnderPearlEntity;
use antralia\practice\entity\PracticeEntityIds;
use antralia\practice\entity\PracticeNPC;
use antralia\practice\entity\PracticeSplashPotionEntity;
use antralia\practice\entity\PracticeSplashPotionListener;
use antralia\practice\ffa\FFAListener;
use antralia\practice\ffa\FFAManager;
use antralia\practice\ffa\task\FFARespawnTask;
use antralia\practice\ffa\task\FFATask;
use antralia\practice\hub\HubListener;
use antralia\practice\hub\HubManager;
use antralia\practice\hub\HubTask;
use antralia\practice\item\PracticeEnderPearlItem;
use antralia\practice\item\PracticeMushroomStewItem;
use antralia\practice\item\PracticeMushroomStewListener;
use antralia\practice\item\PracticeSplashPotionItem;
use antralia\practice\overall\PracticeListener;
use antralia\practice\overall\task\ScoreTagTask;
use antralia\practice\overall\task\BroadcastTask;
use antralia\practice\player\animation\AnimationListener;
use antralia\practice\player\anticheat\AntiCheatListener;
use antralia\practice\player\anticheat\AntiCheatManager;
use antralia\practice\player\anticheat\AntiCheatTask;
use antralia\practice\player\cosmetics\capes\CapesListener;
use antralia\practice\player\cosmetics\capes\CapesManager;
use antralia\practice\player\chat\ChatListener;
use antralia\practice\player\chat\ChatManager;
use antralia\practice\player\cooldown\CooldownListener;
use antralia\practice\player\cooldown\CooldownManager;
use antralia\practice\player\cooldown\CooldownTask;
use antralia\practice\player\cosmetics\CosmeticsManager;
use antralia\practice\player\cosmetics\fly\FlyListener;
use antralia\practice\player\cosmetics\fly\FlyManager;
use antralia\practice\player\cosmetics\potioncolor\PotionColorListener;
use antralia\practice\player\cosmetics\potioncolor\PotionColorManager;
use antralia\practice\player\info\InfoManager;
use antralia\practice\player\language\LanguageListener;
use antralia\practice\player\language\LanguageManager;
use antralia\practice\player\PlayerListener;
use antralia\practice\player\punishment\PunishmentListener;
use antralia\practice\player\punishment\PunishmentManager;
use antralia\practice\player\rank\RankListener;
use antralia\practice\player\rank\RankManager;
use antralia\practice\player\report\ReportManager;
use antralia\practice\player\resourcepack\ResourcePackListener;
use antralia\practice\player\resourcepack\ResourcePackManager;
use antralia\practice\player\rules\RulesManager;
use antralia\practice\player\skin\SkinManager;
use antralia\practice\player\spectator\SpectatorListener;
use antralia\practice\player\spectator\SpectatorManager;
use antralia\practice\player\spectator\SpectatorTask;
use antralia\practice\player\statistics\StatisticsListener;
use antralia\practice\player\statistics\StatisticsManager;
use antralia\practice\player\cosmetics\tags\TagsListener;
use antralia\practice\player\cosmetics\tags\TagsManager;
use antralia\practice\player\toggles\TogglesListener;
use antralia\practice\player\toggles\TogglesManager;
use antralia\practice\player\translation\TranslationManager;
use antralia\practice\provider\Provider;
use antralia\practice\restart\AutoRestartTask;
use antralia\practice\restart\RestartManager;
use antralia\practice\world\generator\VoidGenerator;
use antralia\practice\command\CommandManager;
use pocketmine\block\ChemistryTable;
use pocketmine\block\Element;
use pocketmine\block\VanillaBlocks;
use pocketmine\data\bedrock\EntityLegacyIds;
use pocketmine\data\bedrock\PotionTypeIdMap;
use pocketmine\data\bedrock\PotionTypeIds;
use pocketmine\data\SavedDataLoadingException;
use pocketmine\entity\EntityDataHelper;
use pocketmine\entity\EntityFactory;
use pocketmine\inventory\CreativeInventory;
use pocketmine\item\ItemFactory;
use pocketmine\item\ItemIdentifier;
use pocketmine\item\ItemIds;
use pocketmine\item\PotionType;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\plugin\PluginBase;
use pocketmine\world\generator\GeneratorManager;
use pocketmine\world\World;

final class PracticePlugin extends PluginBase
{

    /**
     * @var float
     */
    private float $loadTime;

    /**
     * @var self
     */
    private static self $instance;

    /**
     * @var Provider
     */
    private Provider $provider;

    /**
     * @var AntiCheatManager
     */
    private AntiCheatManager $antiCheatManager;

    /**
     * @var CapesManager
     */
    private CapesManager $capesManager;

    /**
     * @var ChatManager
     */
    private ChatManager $chatManager;

    /**
     * @var CommandManager
     */
    private CommandManager $commandManager;

    /**
     * @var CooldownManager
     */
    private CooldownManager $cooldownManager;

    /**
     * @var CosmeticsManager
     */
    private CosmeticsManager $cosmeticsManager;

    /**
     * @var FFAManager
     */
    private FFAManager $ffaManager;

    /**
     * @var FlyManager
     */
    private FlyManager $flyManager;

    /**
     * @var HubManager
     */
    private HubManager $hubManager;

    /**
     * @var InfoManager
     */
    private InfoManager $infoManager;

    /**
     * @var LanguageManager
     */
    private LanguageManager $languageManager;

    /**
     * @var PotionColorManager
     */
    private PotionColorManager $potionColorManager;

    /**
     * @var PunishmentManager
     */
    private PunishmentManager $punishmentManager;

    /**
     * @var RankManager
     */
    private RankManager $rankManager;

    /**
     * @var ReportManager
     */
    private ReportManager $reportManager;

    /**
     * @var ResourcePackManager
     */
    private ResourcePackManager $resourcePackManager;

    /**
     * @var RestartManager
     */
    private RestartManager $restartManager;

    /**
     * @var RulesManager
     */
    private RulesManager $rulesManager;

    /**
     * @var SkinManager
     */
    private SkinManager $skinManager;

    /**
     * @var SpectatorManager
     */
    private SpectatorManager $spectatorManager;

    /**
     * @var StatisticsManager
     */
    private StatisticsManager $statisticsManager;

    /**
     * @var TagsManager
     */
    private TagsManager $tagsManager;

    /**
     * @var TogglesManager
     */
    private TogglesManager $togglesManager;

    /**
     * @var TranslationManager
     */
    private TranslationManager $translationManager;

    /**
     * @return self
     */
    public static function getInstance(): self
    {
        return self::$instance;
    }

    /**
     * @return void
     */
    private function createFolders(): void
    {
        if (!(is_dir($this->getDataFolder() . "data"))) {
            @mkdir($this->getDataFolder() . "data");
        }
    }

    /**
     * @return void
     */
    private function registerProvider(): void
    {
        $this->provider = new Provider($this);
    }

    /**
     * @return void
     */
    private function registerGenerators(): void
    {
        GeneratorManager::getInstance()->addGenerator(VoidGenerator::class, "void", fn() => null, true);
    }

    /**
     * @return void
     */
    private function registerManagers(): void
    {
        $this->antiCheatManager = new AntiCheatManager($this);
        $this->capesManager = new CapesManager($this);
        $this->chatManager = new ChatManager($this);
        $this->commandManager = new CommandManager($this);
        $this->cooldownManager = new CooldownManager($this);
        $this->cosmeticsManager = new CosmeticsManager($this);
        $this->ffaManager = new FFAManager($this);
        $this->flyManager = new FlyManager($this);
        $this->hubManager = new HubManager($this);
        $this->infoManager = new InfoManager($this);
        $this->languageManager = new LanguageManager($this);
        $this->potionColorManager = new PotionColorManager($this);
        $this->punishmentManager = new PunishmentManager($this);
        $this->rankManager = new RankManager($this);
        $this->reportManager = new ReportManager($this);
        $this->resourcePackManager = new ResourcePackManager($this);
        $this->restartManager = new RestartManager($this);
        $this->rulesManager = new RulesManager($this);
        $this->skinManager = new SkinManager($this);
        $this->spectatorManager = new SpectatorManager($this);
        $this->statisticsManager = new StatisticsManager($this);
        $this->tagsManager = new TagsManager($this);
        $this->togglesManager = new TogglesManager($this);
        $this->translationManager = new TranslationManager($this);
    }

    /**
     * @return void
     */
    private function unregisterCommands(): void
    {
        foreach ($this->getCommandManager()->getCommandsToUnregister() as $command) {
            $commandMap = $this->getServer()->getCommandMap();
            $commandMap->unregister($commandMap->getCommand($command));
        }
    }

    /**
     * @return void
     */
    private function registerCommands(): void
    {
        $this->getServer()->getCommandMap()->registerAll("practice", $this->getCommandManager()->getCommands());
    }

    /**
     * @return void
     */
    private function registerListeners(): void
    {
        $pluginManager = $this->getServer()->getPluginManager();

        $pluginManager->registerEvents(new PracticeListener($this), $this);
        $pluginManager->registerEvents(new PlayerListener($this), $this);
        $pluginManager->registerEvents(new AnimationListener($this), $this);
        $pluginManager->registerEvents(new AntiCheatListener($this), $this);
        $pluginManager->registerEvents(new CapesListener($this), $this);
        $pluginManager->registerEvents(new ChatListener($this), $this);
        $pluginManager->registerEvents(new CommandListener($this), $this);
        $pluginManager->registerEvents(new CooldownListener($this), $this);
        $pluginManager->registerEvents(new FFAListener($this), $this);
        $pluginManager->registerEvents(new FlyListener($this), $this);
        $pluginManager->registerEvents(new HubListener($this), $this);
        $pluginManager->registerEvents(new LanguageListener($this), $this);
        $pluginManager->registerEvents(new PotionColorListener($this), $this);
        $pluginManager->registerEvents(new PracticeMushroomStewListener($this), $this);
        $pluginManager->registerEvents(new PracticeSplashPotionListener($this), $this);
        $pluginManager->registerEvents(new PunishmentListener($this), $this);
        $pluginManager->registerEvents(new RankListener($this), $this);
        $pluginManager->registerEvents(new ResourcePackListener($this), $this);
        $pluginManager->registerEvents(new SpectatorListener($this), $this);
        $pluginManager->registerEvents(new StatisticsListener($this), $this);
        $pluginManager->registerEvents(new TagsListener($this), $this);
        $pluginManager->registerEvents(new TogglesListener($this), $this);
    }

    /**
     * @return void
     */
    private function scheduleTasks(): void
    {
        $scheduler = $this->getScheduler();

        $scheduler->scheduleRepeatingTask(new AntiCheatTask($this), 20);
        $scheduler->scheduleRepeatingTask(new AutoRestartTask($this), 20);
        $scheduler->scheduleRepeatingTask(new BroadcastTask($this), 8400);
        $scheduler->scheduleRepeatingTask(new CooldownTask($this), 1);
        $scheduler->scheduleRepeatingTask(new FFATask($this), 20);
        $scheduler->scheduleRepeatingTask(new FFARespawnTask($this), 20);
        $scheduler->scheduleRepeatingTask(new HubTask($this), 20);
        $scheduler->scheduleRepeatingTask(new ScoreTagTask($this), 20);
        $scheduler->scheduleRepeatingTask(new SpectatorTask($this), 20);
    }

    /**
     * @return void
     */
    private function registerEntities(): void
    {
        $entityFactory = EntityFactory::getInstance();

        $entityFactory->register(PracticeSplashPotionEntity::class, function (World $world, CompoundTag $nbt): PracticeSplashPotionEntity {
            $potionType = PotionTypeIdMap::getInstance()->fromId($nbt->getShort("PotionId", PotionTypeIds::WATER));

            if ($potionType === null) {
                throw new SavedDataLoadingException("No such potion type");
            }

            return new PracticeSplashPotionEntity(EntityDataHelper::parseLocation($nbt, $world), null, $potionType, $nbt);
        }, ["ThrownPotion", "minecraft:potion", "thrownpotion"], EntityLegacyIds::SPLASH_POTION);

        $entityFactory->register(PracticeEnderPearlEntity::class, function (World $world, CompoundTag $nbt): PracticeEnderPearlEntity {
            return new PracticeEnderPearlEntity(EntityDataHelper::parseLocation($nbt, $world), null, $nbt);
        }, ["ThrownEnderpearl", "minecraft:ender_pearl"], EntityLegacyIds::ENDER_PEARL);

        $entityFactory->register(PracticeNPC::class, function (World $world, CompoundTag $nbt): PracticeNPC {
            return new PracticeNPC(EntityDataHelper::parseLocation($nbt, $world), PracticeNPC::parseSkinNBT($nbt), $nbt);
        }, ["NPC", "antralia:npc"], PracticeEntityIds::NPC);

        $entityFactory->register(FakeDeadHuman::class, function (World $world, CompoundTag $nbt): FakeDeadHuman {
            return new FakeDeadHuman(EntityDataHelper::parseLocation($nbt, $world), FakeDeadHuman::parseSkinNBT($nbt), EntityDataHelper::parseLocation($nbt, $world), $nbt);
        }, ["FakeDeadHuman", "antralia:fake_dead_human"], PracticeEntityIds::FAKE_DEAD_HUMAN);
    }

    /**
     * @return void
     */
    private function registerItems(): void
    {
        $itemFactory = ItemFactory::getInstance();

        $itemFactory->register(new PracticeEnderPearlItem(new ItemIdentifier(ItemIds::ENDER_PEARL, 0), "Ender Pearl"), true);
        $itemFactory->register(new PracticeMushroomStewItem(new ItemIdentifier(ItemIds::MUSHROOM_STEW, 0), "Mushroom Stew"), true);

        foreach (PotionType::getAll() as $potionType) {
            $itemFactory->register(new PracticeSplashPotionItem(new ItemIdentifier(ItemIds::SPLASH_POTION, PotionTypeIdMap::getInstance()->toId($potionType)), $potionType->getDisplayName() . " Splash Potion", $potionType), true);
        }
    }

    /**
     * @return void
     */
    private function unregisterCreativeChemistryItems(): void
    {
        $creativeInventory = CreativeInventory::getInstance();

        $creativeInventory->remove(VanillaBlocks::ELEMENT_ZERO()->asItem());
        foreach (VanillaBlocks::getAll() as $block) {
            if ($block instanceof ChemistryTable) {
                $creativeInventory->remove($block->asItem());
            }
            if ($block instanceof Element) {
                $creativeInventory->remove($block->asItem());
            }
        }
    }

    /**
     * @return void
     */
    public function startRcon(): void
    {
        new RconServer($this);
    }

    /**
     * @return void
     */
    protected function onLoad(): void
    {
        $this->loadTime = microtime(true);
        self::$instance = $this;

        $this->registerGenerators();
    }

    /**
     * @return void
     */
    protected function onEnable(): void
    {
        $this->createFolders();
        $this->registerProvider();

        $this->registerManagers();
        $this->registerListeners();
        $this->scheduleTasks();
        $this->unregisterCommands();
        $this->registerCommands();

        $this->registerEntities();
        $this->registerItems();
        $this->unregisterCreativeChemistryItems();

        $this->startRcon();

        $loadTime = round(microtime(true) - $this->loadTime, 3);
        unset($this->loadTime);

        $this->getLogger()->info("Done (" . $loadTime . "s)! Practice enabled!");
    }

    /**
     * @return Provider
     */
    public function getProvider(): Provider
    {
        return $this->provider;
    }

    /**
     * @return AntiCheatManager
     */
    public function getAntiCheatManager(): AntiCheatManager
    {
        return $this->antiCheatManager;
    }

    /**
     * @return CapesManager
     */
    public function getCapesManager(): CapesManager
    {
        return $this->capesManager;
    }

    /**
     * @return ChatManager
     */
    public function getChatManager(): ChatManager
    {
        return $this->chatManager;
    }

    /**
     * @return CommandManager
     */
    public function getCommandManager(): CommandManager
    {
        return $this->commandManager;
    }

    /**
     * @return CooldownManager
     */
    public function getCooldownManager(): CooldownManager
    {
        return $this->cooldownManager;
    }

    /**
     * @return CosmeticsManager
     */
    public function getCosmeticsManager(): CosmeticsManager
    {
        return $this->cosmeticsManager;
    }

    /**
     * @return FFAManager
     */
    public function getFFAManager(): FFAManager
    {
        return $this->ffaManager;
    }

    /**
     * @return FlyManager
     */
    public function getFlyManager(): FlyManager
    {
        return $this->flyManager;
    }

    /**
     * @return HubManager
     */
    public function getHubManager(): HubManager
    {
        return $this->hubManager;
    }

    /**
     * @return InfoManager
     */
    public function getInfoManager(): InfoManager
    {
        return $this->infoManager;
    }

    /**
     * @return LanguageManager
     */
    public function getLanguageManager(): LanguageManager
    {
        return $this->languageManager;
    }

    /**
     * @return PotionColorManager
     */
    public function getPotionColorManager(): PotionColorManager
    {
        return $this->potionColorManager;
    }

    /**
     * @return PunishmentManager
     */
    public function getPunishmentManager(): PunishmentManager
    {
        return $this->punishmentManager;
    }

    /**
     * @return RankManager
     */
    public function getRankManager(): RankManager
    {
        return $this->rankManager;
    }

    /**
     * @return ReportManager
     */
    public function getReportManager(): ReportManager
    {
        return $this->reportManager;
    }

    /**
     * @return ResourcePackManager
     */
    public function getResourcePackManager(): ResourcePackManager
    {
        return $this->resourcePackManager;
    }

    /**
     * @return RestartManager
     */
    public function getRestartManager(): RestartManager
    {
        return $this->restartManager;
    }

    /**
     * @return RulesManager
     */
    public function getRulesManager(): RulesManager
    {
        return $this->rulesManager;
    }

    /**
     * @return SkinManager
     */
    public function getSkinManager(): SkinManager
    {
        return $this->skinManager;
    }

    /**
     * @return SpectatorManager
     */
    public function getSpectatorManager(): SpectatorManager
    {
        return $this->spectatorManager;
    }

    /**
     * @return StatisticsManager
     */
    public function getStatisticsManager(): StatisticsManager
    {
        return $this->statisticsManager;
    }

    /**
     * @return TagsManager
     */
    public function getTagsManager(): TagsManager
    {
        return $this->tagsManager;
    }

    /**
     * @return TogglesManager
     */
    public function getTogglesManager(): TogglesManager
    {
        return $this->togglesManager;
    }

    /**
     * @return TranslationManager
     */
    public function getTranslationManager(): TranslationManager
    {
        return $this->translationManager;
    }

    /**
     * @return void
     */
    protected function onDisable(): void
    {
        foreach ($this->getServer()->getWorldManager()->getDefaultWorld()->getEntities() as $entity) {
            if ($entity instanceof PracticeNPC) {
                $entity->close();
            }
        }
    }
}