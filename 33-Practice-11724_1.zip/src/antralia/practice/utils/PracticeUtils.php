<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\utils;

use antralia\practice\player\PracticePlayer;
use antralia\practice\PracticePlugin;
use pocketmine\entity\Entity;
use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\utils\Process;

final class PracticeUtils
{

    /**
     * 1 day and + or - your difference from UTC time.
     *
     * @var int
     */
    public const DATE_INACCURACY = 97200;

    /**
     * @var string
     */
    public const ITEM_LORE = "§r§aantralia.net";

    /**
     * Nothing there.
     */
    private function __construct()
    {
    }

    /**
     * @param string $string
     * @return string
     */
    public static function filterStringForSQL(string $string): string
    {
        return str_replace(["'", "`", '"', ";"], ["", "", "", ""], $string);
    }

    /**
     * @param string $nickname
     * @return Player|null
     */
    public static function getPlayerByPrefix(string $nickname): ?Player
    {
        $nickname = strtolower($nickname);
        $result = null;
        $delta = PHP_INT_MAX;
        foreach (Server::getInstance()->getOnlinePlayers() as $player) {
            if (stripos($player->getName(), $nickname) === 0) {
                $currentDelta = strlen($player->getName()) - strlen($nickname);
                if ($currentDelta < $delta) {
                    $result = $player;
                    $delta = $currentDelta;
                }
                if ($currentDelta === 0) {
                    break;
                }
            }
        }
        return $result;
    }

    /**
     * @return string
     */
    public static function getPrettyServerUptime(): string
    {
        $time = (int) (microtime(true) - Server::getInstance()->getStartTime());
        $seconds = $time % 60;
        $minutes = null;
        $hours = null;
        $days = null;

        if ($time >= 60) {
            $minutes = floor(($time % 3600) / 60);
            if ($time >= 3600) {
                $hours = floor(($time % (3600 * 24)) / 3600);
                if ($time >= 3600 * 24) {
                    $days = floor($time / (3600 * 24));
                }
            }
        }
        return ($minutes !== null ? ($hours !== null ? ($days !== null ? $days . " days " : "") . $hours . " hours " : "") . $minutes . " minutes " : "") . $seconds .  " seconds";
    }

    /**
     * @return string
     */
    public static function getMemoryUsage(): string
    {
        return number_format(round((Process::getAdvancedMemoryUsage()[1] / 1024) / 1024, 2), 2);
    }

    /**
     * @param Entity $entity
     * @return PracticePlayer[]
     */
    public static function getViewersForFFAEntity(Entity $entity): array
    {
        $entityPlayer = $entity->getOwningEntity();
        $plugin = PracticePlugin::getInstance();
        $ffaManager = $plugin->getFFAManager();
        $viewers = $entity->getWorld()->getViewersForPosition($entity->getLocation());

        $newViewers = [];
        foreach ($viewers as $player) {
            if (!($player instanceof PracticePlayer)) {
                continue;
            }

            if (!($player->isConnected())) {
                continue;
            }

            if ($entity->getOwningEntityId() === $player->getId()) {
                $newViewers[] = $player;
                continue;
            }

            if ($entityPlayer instanceof PracticePlayer) {
                if ($ffaManager->getEnemyName($entityPlayer) === $player->getName()) {
                    $newViewers[] = $player;
                    continue;
                }
            }

            if (!($plugin->getTogglesManager()->getToggleStatus($player, "hide_players") && $ffaManager->isInCombat($player))) {
                $newViewers[] = $player;
            }
        }
        return $newViewers;
    }

    /**
     * @param int $timeStamp
     * @return int
     */
    public static function convertTimeStampToHours(int $timeStamp): int
    {
        return intval($timeStamp / 3600);
    }
}