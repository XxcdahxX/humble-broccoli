<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\hub;

use antralia\core\form\SimpleForm;
use antralia\core\scoreboard\Scoreboard;
use antralia\practice\entity\PracticeNPC;
use antralia\practice\exception\PracticeException;
use antralia\practice\player\info\InfoManager;
use antralia\practice\player\PracticePlayer;
use antralia\practice\player\rules\RulesManager;
use antralia\practice\player\skin\SkinManager;
use antralia\practice\PracticePlugin;
use antralia\practice\utils\PracticeUtils;
use pocketmine\entity\Location;
use pocketmine\entity\Skin;
use pocketmine\item\VanillaItems;
use pocketmine\math\Vector3;
use pocketmine\player\GameMode;
use pocketmine\world\format\Chunk;
use pocketmine\world\particle\FloatingTextParticle;
use pocketmine\world\World;

use JsonException;

final class HubManager
{

    /**
     * @var string
     */
    public const MOTD = "§l§aAntralia§r";

    /**
     * @var string
     */
    public const NPC_NAME_TAG = "§f>§c>§f> §cA§fn§ct§fr§ca§fl§ci§fa §cN§fe§ct§fw§co§fr§ck §f<§c<§f<";

    /**
     * @var int
     */
    public const HUB_YAW = 180;

    /**
     * @var int
     */
    public const HUB_PITCH = 0;

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @var Skin
     */
    private Skin $npcSkin;

    /**
     * @var int
     */
    private int $npcId;

    /**
     * @var array<string, bool>
     */
    private array $players = [];

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;

        $plugin->getServer()->getNetwork()->setName(self::MOTD);

        if (!($defaultWorld = $plugin->getServer()->getWorldManager()->getDefaultWorld())) {
            $defaultWorldName = $plugin->getServer()->getConfigGroup()->getConfigString("level-name", "world");
            $plugin->getServer()->getWorldManager()->loadWorld($defaultWorldName);
            $defaultWorld = $plugin->getServer()->getWorldManager()->getWorldByName($defaultWorldName);
        }
        $defaultWorld->setTime(World::TIME_NIGHT);
        $defaultWorld->stopTime();

        $this->registerNPCSkin();

        $npc = new PracticeNPC(new Location(801.5, 50, 772.5, $defaultWorld, 1, 0), $this->getNPCSkin());
        $npc->setScale(1.5);
        $npc->setNameTag(self::NPC_NAME_TAG);
        $npc->spawnToAll();
        $this->npcId = $npc->getId();

        $defaultWorld->registerChunkLoader($npc, $npc->getLocation()->getFloorX() >> Chunk::COORD_BIT_SIZE, $npc->getLocation()->getFloorZ() >> Chunk::COORD_BIT_SIZE);
    }

    /**
     * @return void
     */
    public function registerNPCSkin(): void
    {
        $this->plugin->saveResource("skins/NPC.png");
        $this->plugin->saveResource("skins/NPC_geometry.json");

        try {
            $image = imagecreatefrompng($this->plugin->getDataFolder() . "skins/NPC.png");

            if ($image === false) {
                throw new PracticeException("Image cannot be created");
            }

            $this->npcSkin = new Skin(
                "NPC_Antralia",
                SkinManager::fromImage($image),
                "",
                "geometry.antralia.npc",
                file_get_contents($this->plugin->getDataFolder() . "skins/NPC_geometry.json")
            );
            @imagedestroy($image);
        } catch (JsonException $e) {
            $this->plugin->getLogger()->logException($e);
        }
    }

    /**
     * @return Skin
     */
    public function getNPCSkin(): Skin
    {
        return $this->npcSkin;
    }

    /**
     * @return int
     */
    public function getNPCId(): int
    {
        return $this->npcId;
    }

    /**
     * @param PracticePlayer $player
     * @return bool
     */
    public function isInHub(PracticePlayer $player): bool
    {
        return isset($this->players[$player->getName()]);
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function addToHub(PracticePlayer $player): void
    {
        $this->players[$player->getName()] = true;
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function removeFromHub(PracticePlayer $player): void
    {
        if (isset($this->players[$player->getName()])) {
            unset($this->players[$player->getName()]);
        }
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function setPlayerSettings(PracticePlayer $player): void
    {
        if (!($player->isConnected())) {
            return;
        }

        $player->setGamemode(GameMode::ADVENTURE());
        $player->setFlying(false);
        $player->setAllowFlight(false);

        $player->setMaxHealth(20);
        $player->setHealth(20);
        $player->getHungerManager()->setFood(20);
        $player->getXpManager()->setXpAndProgress(0, 0);

        $player->extinguish();
        $player->getEffects()->clear();

        $player->getInventory()->clearAll();
        $player->getArmorInventory()->clearAll();
        $player->getCursorInventory()->clearAll();
        $player->getCraftingGrid()->clearAll();

        if (!($this->isInHub($player))) {
            $this->addToHub($player);
        }

        $player->teleport($this->plugin->getServer()->getWorldManager()->getDefaultWorld()->getSpawnLocation(), self::HUB_YAW, self::HUB_PITCH);

        $flyManager = $this->plugin->getFlyManager();
        if ($flyManager->hasFlyFromArray($player)) {
            $player->setAllowFlight(true);
        }
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function addFloatingText(PracticePlayer $player): void
    {
        $translationManager = $this->plugin->getTranslationManager();
        $particle = new FloatingTextParticle($translationManager->translate($player, "hubFloatingText")[1], $translationManager->translate($player, "hubFloatingText")[0]);
        $player->getWorld()->addParticle(new Vector3(801.5, 52.4, 793.5), $particle, [$player]);
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function sendMenuItems(PracticePlayer $player): void
    {
        if (!($player->isConnected())) {
            return;
        }

        $inventory = $player->getInventory();
        $itemNames = $this->plugin->getTranslationManager()->translate($player, "hubItems");

        $inventory->clearAll();
        $inventory->setItem(0, VanillaItems::DIAMOND_SWORD()->setCustomName($itemNames[0])->setLore([PracticeUtils::ITEM_LORE]));
        $inventory->setItem(4, VanillaItems::CLOCK()->setCustomName($itemNames[1])->setLore([PracticeUtils::ITEM_LORE]));
        $inventory->setItem(8, VanillaItems::BOOK()->setCustomName($itemNames[2])->setLore([PracticeUtils::ITEM_LORE]));
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function updateScoreboard(PracticePlayer $player): void
    {
        if ($this->plugin->getTogglesManager()->getToggleStatus($player, "scoreboard")) {
            $line = $this->plugin->getTranslationManager()->translate($player, "hubScoreboard");

            Scoreboard::setScore($player, $line[0]);
            Scoreboard::setScoreLine($player, 1, $line[1]);
            Scoreboard::setScoreLine($player, 2, sprintf($line[2], $player->getRankColored()));
            Scoreboard::setScoreLine($player, 3, sprintf($line[3], $this->plugin->getStatisticsManager()->getDivisionColoredFromArray($player)));
            Scoreboard::setScoreLine($player, 4, $line[4]);
            Scoreboard::setScoreLine($player, 5, sprintf($line[5], (string)count($this->plugin->getServer()->getOnlinePlayers())));
            Scoreboard::setScoreLine($player, 6, sprintf($line[6], (string)$this->plugin->getFFAManager()->getOnlinePlayersCount()));
            Scoreboard::setScoreLine($player, 7, $line[7]);
            Scoreboard::setScoreLine($player, 8, $line[8]);
        }
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function updateScoreTag(PracticePlayer $player): void
    {
        $tagsManager = $this->plugin->getTagsManager();

        if ($tagsManager->hasTagFromArray($player)) {
            $player->setScoreTag($tagsManager->getTagFromArrayColored($player));
        } else {
            $player->setScoreTag("");
        }
    }


    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function sendGamesForm(PracticePlayer $player): void
    {
        $form = new SimpleForm(function (PracticePlayer $player, int $data = null): void {
            if ($data === null) {
                return;
            }

            if ($data == 0) {
                $this->plugin->getFFAManager()->sendFFAForm($player);
            }
        });

        $formContents = $this->plugin->getTranslationManager()->translate($player, "gamesForm");

        $form->setTitle($formContents[0]);

        $form->setContent($formContents[1]);

        $form->addButton(sprintf($formContents[2], $this->plugin->getFFAManager()->getOnlinePlayersCount()));

        $player->sendForm($form);
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function sendPreferencesForm(PracticePlayer $player): void
    {
        $form = new SimpleForm(function (PracticePlayer $player, int $data = null): void {
            if ($data === null) {
                return;
            }

            switch ($data) {
                case 0:
                    $this->plugin->getLanguageManager()->sendLanguageForm($player);
                    break;
                case 1:
                    $this->plugin->getTogglesManager()->sendTogglesForm($player);
                    break;
                case 2:
                    $this->plugin->getCosmeticsManager()->sendCosmeticsForm($player);
                    break;
            }
        });

        $formContents = $this->plugin->getTranslationManager()->translate($player, "preferencesForm");

        $form->setTitle($formContents[0]);

        $form->addButton($formContents[1]);
        $form->addButton($formContents[2]);
        $form->addButton($formContents[3]);

        $player->sendForm($form);
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function sendMenuForm(PracticePlayer $player): void
    {
        $form = new SimpleForm(function (PracticePlayer $player, int $data = null): void {
            if ($data === null) {
                return;
            }

            switch ($data) {
                case 0:
                    $this->plugin->getInfoManager()->sendInfoForm($player, InfoManager::BACK_BUTTON_MODE);
                    break;
                case 1:
                    $this->plugin->getRulesManager()->sendRulesForm($player, RulesManager::BACK_BUTTON_MODE);
                    break;
            }
        });

        $formContents = $this->plugin->getTranslationManager()->translate($player, "menuForm");

        $form->setTitle($formContents[0]);

        $form->addButton($formContents[1]);
        $form->addButton($formContents[2]);

        $player->sendForm($form);
    }
}