<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\hub;

use antralia\practice\player\language\PlayerLanguageChangeEvent;
use antralia\practice\player\PracticePlayer;
use antralia\practice\PracticePlugin;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\inventory\InventoryTransactionEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerEntityInteractEvent;
use pocketmine\event\player\PlayerItemUseEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\world\sound\NoteInstrument;
use pocketmine\world\sound\NoteSound;

final class HubListener implements Listener
{

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @param PlayerJoinEvent $event
     * @return void
     */
    public function handlePlayerJoin(PlayerJoinEvent $event): void
    {
        $player = $event->getPlayer();

        if (!($player instanceof PracticePlayer)) {
            return;
        }

        $hubManager = $this->plugin->getHubManager();
        $translationManager = $this->plugin->getTranslationManager();

        $hubManager->setPlayerSettings($player);
        $hubManager->sendMenuItems($player);
        $hubManager->updateScoreboard($player);
        $hubManager->updateScoreTag($player);
        $hubManager->addFloatingText($player);

        $player->sendMessage(sprintf($translationManager->translate($player, "joinMessage"), count($this->plugin->getServer()->getOnlinePlayers())));
        $player->sendTitle($translationManager->translate($player, "joinTitle")[0], $translationManager->translate($player, "joinTitle")[1]);
        $player->getWorld()->addSound($player->getLocation(), new NoteSound(NoteInstrument::PIANO(), 10), [$player]);

        $rankColor = $player->getRankColor() === "§7" ? "§f" : $player->getRankColor();
        $event->setJoinMessage("§a+ §7| §f" . $rankColor . $player->getDisplayName());
    }

    /**
     * @param PlayerItemUseEvent $event
     * @return void
     */
    public function handlePlayerItemUse(PlayerItemUseEvent $event): void
    {
        $player = $event->getPlayer();

        if (!($player instanceof PracticePlayer)) {
            return;
        }

        $hubManager = $this->plugin->getHubManager();
        if ($hubManager->isInHub($player)) {
            $item = $event->getItem();
            $items = $this->plugin->getTranslationManager()->translate($player, "hubItems");

            $event->cancel();
            if ($item->getCustomName() === $items[0]) {
                $hubManager->sendGamesForm($player);
            } elseif ($item->getCustomName() === $items[1]) {
                $hubManager->sendPreferencesForm($player);
            } elseif ($item->getCustomName() === $items[2]) {
                $this->plugin->getStatisticsManager()->sendStatisticsForm($player);
            }
        }
    }

    /**
     * @param PlayerMoveEvent $event
     * @return void
     */
    public function handlePlayerMove(PlayerMoveEvent $event): void
    {
        $player = $event->getPlayer();

        if (!($player instanceof PracticePlayer)) {
            return;
        }

        $hubManager = $this->plugin->getHubManager();
        if ($hubManager->isInHub($player)) {
            if ($player->getLocation()->distance($this->plugin->getServer()->getWorldManager()->getDefaultWorld()->getSpawnLocation()) > 160) {
                $hubManager->setPlayerSettings($player);
                $hubManager->sendMenuItems($player);
                $hubManager->updateScoreboard($player);
                $hubManager->updateScoreTag($player);
            }
        }
    }

    /**
     * @param PlayerQuitEvent $event
     * @return void
     */
    public function handlePlayerQuit(PlayerQuitEvent $event): void
    {
        $player = $event->getPlayer();

        if (!($player instanceof PracticePlayer)) {
            return;
        }

        $hubManager = $this->plugin->getHubManager();
        if ($hubManager->isInHub($player)) {
            $hubManager->removeFromHub($player);
        }

        $rankColor = $player->getRankColor() === "§7" ? "§f" : $player->getRankColor();
        $event->setQuitMessage("§c- §7| §f" . $rankColor . $player->getName());
    }

    /**
     * @param PlayerRespawnEvent $event
     * @return void
     */
    public function handlePlayerRespawn(PlayerRespawnEvent $event): void
    {
        $player = $event->getPlayer();

        if (!($player instanceof PracticePlayer)) {
            return;
        }

        $hubManager = $this->plugin->getHubManager();
        if ($hubManager->isInHub($player)) {
            $hubManager = $this->plugin->getHubManager();
            $hubManager->setPlayerSettings($player);
            $hubManager->sendMenuItems($player);
            $hubManager->updateScoreboard($player);
            $hubManager->updateScoreTag($player);
        }
    }

    /**
     * @param PlayerDeathEvent $event
     * @return void
     */
    public function handlePlayerDeath(PlayerDeathEvent $event): void
    {
        $player = $event->getPlayer();

        if (!($player instanceof PracticePlayer)) {
            return;
        }

        if ($this->plugin->getHubManager()->isInHub($player)) {
            $event->setDrops([]);
            $event->setXpDropAmount(0);
        }
    }

    /**
     * @param PlayerLanguageChangeEvent $event
     * @return void
     */
    public function handlePlayerLanguageChange(PlayerLanguageChangeEvent $event): void
    {
        $player = $event->getPlayer();

        $hubManager = $this->plugin->getHubManager();
        if ($hubManager->isInHub($player)) {
            $hubManager->sendMenuItems($player);
            $hubManager->updateScoreboard($player);
            $player->getNetworkSession()->syncAvailableCommands();
        }
    }

    /**
     * @param EntityDamageEvent $event
     * @return void
     */
    public function handleEntityDamage(EntityDamageEvent $event): void
    {
        $entity = $event->getEntity();
        $hubManager = $this->plugin->getHubManager();

        if ($event instanceof EntityDamageByEntityEvent) {
            $damager = $event->getDamager();
            if ($damager instanceof PracticePlayer) {
                if ($entity->getId() === $hubManager->getNPCId()) {
                    if ($hubManager->isInHub($damager)) {
                        $hubManager->sendMenuForm($damager);
                    }
                    $event->cancel();
                } elseif ($hubManager->isInHub($damager)) {
                    $event->cancel();
                }
            }
        }

        if (!($entity instanceof PracticePlayer)) {
            return;
        }

        if ($hubManager->isInHub($entity)) {
            if ($event->getCause() === EntityDamageEvent::CAUSE_VOID) {
                $hubManager->setPlayerSettings($entity);
                $hubManager->sendMenuItems($entity);
                $hubManager->updateScoreboard($entity);
                $hubManager->updateScoreTag($entity);
            }
            $event->cancel();
        }
    }

    /**
     * @param PlayerEntityInteractEvent $event
     * @return void
     */
    public function handlePlayerEntityInteract(PlayerEntityInteractEvent $event): void
    {
        $player = $event->getPlayer();
        $entity = $event->getEntity();

        if (!($player instanceof PracticePlayer)) {
            return;
        }

        $hubManager = $this->plugin->getHubManager();
        if ($hubManager->isInHub($player)) {
            if ($entity->getId() === $hubManager->getNPCId()) {
                $hubManager->sendMenuForm($player);
            }
        }
    }

    /**
     * @param InventoryTransactionEvent $event
     * @return void
     */
    public function handleInventoryTransaction(InventoryTransactionEvent $event): void
    {
        $player = $event->getTransaction()->getSource();

        if (!($player instanceof PracticePlayer)) {
            return;
        }

        if ($this->plugin->getHubManager()->isInHub($player)) {
            $event->cancel();
        }
    }
}