<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\restart;

use antralia\practice\player\PracticePlayer;
use antralia\practice\PracticePlugin;
use pocketmine\scheduler\Task;

final class AutoRestartTask extends Task
{

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @var int
     */
    private int $time = 0;

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @return void
     */
    public function onRun(): void
    {
        if ($this->time >= RestartManager::RESTART_TIME) {
            $this->plugin->getRestartManager()->restartServer();
            return;
        }

        foreach ($this->plugin->getServer()->getOnlinePlayers() as $player) {
            if (!($player instanceof PracticePlayer)) {
                continue;
            }

            if (!($player->isConnected())) {
                continue;
            }

            $restartTime = RestartManager::RESTART_TIME - $this->time;
            $translationManager = $this->plugin->getTranslationManager();
            $restartTitle = $translationManager->translate($player, "serverRestartTitle");

            switch ($restartTime) {
                case 600:
                    $player->sendMessage(sprintf($translationManager->translate($player, "serverRestartNotificationInMinutes"), "10"));
                    break;
                case 300:
                    $player->sendMessage(sprintf($translationManager->translate($player, "serverRestartNotificationInMinutes"), "5"));
                    break;
                case 5:
                    $player->sendMessage(sprintf($translationManager->translate($player, "serverRestartNotificationInSeconds"), "5"));
                    $player->sendTitle($restartTitle[0], sprintf($restartTitle[1], "§e5"));
                    break;
                case 4:
                    $player->sendMessage(sprintf($translationManager->translate($player, "serverRestartNotificationInSeconds"), "4"));
                    $player->sendTitle($restartTitle[0], sprintf($restartTitle[1], "§g4"));
                    break;
                case 3:
                    $player->sendMessage(sprintf($translationManager->translate($player, "serverRestartNotificationInSeconds"), "3"));
                    $player->sendTitle($restartTitle[0], sprintf($restartTitle[1], "§63"));
                    break;
                case 2:
                    $player->sendMessage(sprintf($translationManager->translate($player, "serverRestartNotificationInSeconds"), "2"));
                    $player->sendTitle($restartTitle[0], sprintf($restartTitle[1], "§c2"));
                    break;
                case 1:
                    $player->sendMessage(sprintf($translationManager->translate($player, "serverRestartNotificationInSeconds"), "1"));
                    $player->sendTitle($restartTitle[0], sprintf($restartTitle[1], "§41"));
                    break;
            }
        }
        $this->time++;
    }
}