<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\restart;

use antralia\practice\PracticePlugin;
use pocketmine\utils\Internet;
use pocketmine\utils\Utils;

final class RestartManager
{

    /**
     * @var int
     */
    public const RESTART_TIME = 14400;

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @return void
     */
    public function restartServer(): void
    {
        foreach ($this->plugin->getServer()->getOnlinePlayers() as $player) {
            $player->transfer(Internet::getIP(), $this->plugin->getServer()->getPort(), "Restart");
        }

        if (Utils::getOS() === "linux") {
            register_shutdown_function(function (): void {
                pcntl_exec("./start.sh");
            });
        }

        $this->plugin->getServer()->shutdown();
    }
}