<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\provider;

use antralia\practice\player\PracticePlayer;
use antralia\practice\player\rank\RankManager;
use antralia\practice\PracticePlugin;

use SQLite3;

final class Provider
{

    /**
     * @var SQLite3
     */
    private SQLite3 $database;

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $database = new SQLite3($plugin->getDataFolder() . "data/players.db");
        $database->exec("CREATE TABLE IF NOT EXISTS `player_data` (`nickname` TEXT NOT NULL, `xuid` TEXT NOT NULL, `ip` TEXT NOT NULL, `deviceid` TEXT NOT NULL);");
        $database->exec("CREATE TABLE IF NOT EXISTS `server_data` (`nickname` TEXT NOT NULL, `xuid` TEXT NOT NULL, `rank` TEXT NOT NULL, `locale` TEXT NOT NULL);");
        $database->exec("CREATE TABLE IF NOT EXISTS `statistics` (`nickname` TEXT NOT NULL, `xuid` TEXT NOT NULL, `kills` INTEGER NOT NULL, `deaths` INTEGER NOT NULL, `playtime` INTEGER NOT NULL);");
        $database->exec("CREATE TABLE IF NOT EXISTS `toggles` (`xuid` TEXT NOT NULL, `scoreboard` TEXT NOT NULL, `cps` TEXT NOT NULL, `autosprint` TEXT NOT NULL, `lightning` TEXT NOT NULL, `hide_players` TEXT NOT NULL, `arena_respawn` TEXT NOT NULL);");
        $database->exec("CREATE TABLE IF NOT EXISTS `cosmetics` (`xuid` TEXT NOT NULL, `cape` TEXT NOT NULL, `tag` TEXT NOT NULL, `fly` TEXT NOT NULL, `potion_color` TEXT NOT NULL);");
        $this->database = $database;
    }

    /**
     * @return SQLite3
     */
    public function getDatabase(): SQLite3
    {
        return $this->database;
    }

    /**
     * @param PracticePlayer $player
     * @return bool
     */
    public function isNewPlayer(PracticePlayer $player): bool
    {
        $query = $this->getDatabase()->prepare("SELECT * FROM `player_data` WHERE `xuid` = :xuid;");
        $query->bindValue(":xuid", $player->getXuid());
        $result = $query->execute()->fetchArray(SQLITE3_ASSOC);

        return $result === false;
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function processNewPlayerData(PracticePlayer $player): void
    {
        if ($this->isNewPlayer($player)) {
            $database = $this->getDatabase();
            $nickname = $player->getLowerCaseName();
            $xuid = $player->getXuid();

            if ($player->getLocale() === "ru_RU") {
                $locale = "ru";
            } else {
                $locale = "en";
            }

            $playerQuery = $database->prepare("INSERT INTO `player_data` VALUES (:nickname, :xuid, :ip, :deviceid);");
            $playerQuery->bindValue(":nickname", $nickname);
            $playerQuery->bindValue(":xuid", $xuid);
            $playerQuery->bindValue(":ip", $player->getNetworkSession()->getIp());
            $playerQuery->bindValue(":deviceid", $player->getPlayerInfo()->getExtraData()["DeviceId"]);
            $playerQuery->execute();

            $serverQuery = $database->prepare("INSERT INTO `server_data` VALUES (:nickname, :xuid, '" . RankManager::DEFAULT_RANK . "', :locale);");
            $serverQuery->bindValue(":nickname", $nickname);
            $serverQuery->bindValue(":xuid", $xuid);
            $serverQuery->bindValue(":locale", $locale);
            $serverQuery->execute();

            $statisticsQuery = $database->prepare("INSERT INTO `statistics` VALUES (:nickname, :xuid, 0, 0, 0);");
            $statisticsQuery->bindValue(":nickname", $nickname);
            $statisticsQuery->bindValue(":xuid", $xuid);
            $statisticsQuery->execute();

            $togglesQuery = $database->prepare("INSERT INTO `toggles` VALUES (:xuid, 'enabled', 'disabled', 'disabled', 'enabled', 'disabled', 'disabled');");
            $togglesQuery->bindValue(":xuid", $xuid);
            $togglesQuery->execute();

            $cosmeticsQuery = $database->prepare("INSERT INTO `cosmetics` VALUES (:xuid, 'disabled', 'disabled', 'disabled', 'disabled');");
            $cosmeticsQuery->bindValue(":xuid", $xuid);
            $cosmeticsQuery->execute();
        }
    }

    /**
     * @param string $nickname
     * @return bool
     */
    public function isPlayerRegisteredByNickname(string $nickname): bool
    {
        $query = $this->getDatabase()->prepare("SELECT * FROM `player_data` WHERE `nickname` = :nickname;");
        $query->bindValue(":nickname", strtolower($nickname));
        $result = $query->execute()->fetchArray(SQLITE3_ASSOC);

        return (bool)$result;
    }

    /**
     * @param PracticePlayer $player
     * @return bool
     */
    public function isPlayerRegisteredByXuid(PracticePlayer $player): bool
    {
        $query = $this->getDatabase()->prepare("SELECT * FROM `player_data` WHERE `xuid` = :xuid;");
        $query->bindValue(":xuid", $player->getXuid());
        $result = $query->execute()->fetchArray(SQLITE3_ASSOC);

        return (bool)$result;
    }

    /**
     * @param string $nickname
     * @return string[][]
     */
    public function getPlayerDataByNickname(string $nickname): array
    {
        $query = $this->getDatabase()->prepare("SELECT * FROM `player_data` WHERE `nickname` = :nickname;");
        $query->bindValue(":nickname", strtolower($nickname));
        $result = $query->execute()->fetchArray(SQLITE3_ASSOC);

        return !($result) ? ["nickname" => "Steve", "xuid" => "0", "ip" => "0.0.0.0", "deviceid" => "0"] : $result;
    }

    /**
     * @param PracticePlayer $player
     * @return string[][]
     */
    public function getPlayerDataByXuid(PracticePlayer $player): array
    {
        $query = $this->getDatabase()->prepare("SELECT * FROM `player_data` WHERE `xuid` = :xuid;");
        $query->bindValue(":xuid", $player->getXuid());
        $result = $query->execute()->fetchArray(SQLITE3_ASSOC);

        return !($result) ? ["nickname" => "Steve", "xuid" => "0", "ip" => "0.0.0.0", "deviceid" => "0"] : $result;
    }

    /**
     * @param string $nickname
     * @return string
     */
    public function getPlayerXuidByNickname(string $nickname): string
    {
        $query = $this->getDatabase()->prepare("SELECT `xuid` FROM `player_data` WHERE `nickname` = :nickname;");
        $query->bindValue(":nickname", strtolower($nickname));
        $result = $query->execute()->fetchArray(SQLITE3_ASSOC);

        return !($result) ? "0" : $result["xuid"];
    }

    /**
     * @param string $nickname
     * @return string
     */
    public function getPlayerIpByNickname(string $nickname): string
    {
        $query = $this->getDatabase()->prepare("SELECT `ip` FROM `player_data` WHERE `nickname` = :nickname;");
        $query->bindValue(":nickname", strtolower($nickname));
        $result = $query->execute()->fetchArray(SQLITE3_ASSOC);

        return !($result) ? "0" : $result["ip"];
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function setPlayerNickname(PracticePlayer $player): void
    {
        $database = $this->getDatabase();
        $nickname = $player->getLowerCaseName();
        $xuid = $player->getXuid();

        $playerQuery = $database->prepare("UPDATE `player_data` SET `nickname` = :nickname WHERE `xuid` = :xuid;");
        $playerQuery->bindValue(":nickname", $nickname);
        $playerQuery->bindValue(":xuid", $xuid);
        $playerQuery->execute();

        $serverQuery = $database->prepare("UPDATE `server_data` SET `nickname` = :nickname WHERE `xuid` = :xuid;");
        $serverQuery->bindValue(":nickname", $nickname);
        $serverQuery->bindValue(":xuid", $xuid);
        $serverQuery->execute();

        $statisticsQuery = $database->prepare("UPDATE `statistics` SET `nickname` = :nickname WHERE `xuid` = :xuid;");
        $statisticsQuery->bindValue(":nickname", $nickname);
        $statisticsQuery->bindValue(":xuid", $xuid);
        $statisticsQuery->execute();
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function setPlayerIp(PracticePlayer $player): void
    {
        $query = $this->getDatabase()->prepare("UPDATE `player_data` SET `ip` = :ip WHERE `xuid` = :xuid;");
        $query->bindValue(":ip", $player->getNetworkSession()->getIp());
        $query->bindValue(":xuid", $player->getXuid());
        $query->execute();
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function setPlayerDeviceId(PracticePlayer $player): void
    {
        $query = $this->getDatabase()->prepare("UPDATE `player_data` SET `deviceid` = :deviceid WHERE `xuid` = :xuid;");
        $query->bindValue(":deviceid", $player->getPlayerInfo()->getExtraData()["DeviceId"]);
        $query->bindValue(":xuid", $player->getXuid());
        $query->execute();
    }

    /**
     * @param string $nickname
     * @return string[]
     */
    public function getOtherNicknames(string $nickname): array
    {
        $nickname = strtolower($nickname);
        $database = $this->getDatabase();
        $playerData = $this->getPlayerDataByNickname($nickname);
        $nicknames = [];

        $queryIp = $database->prepare("SELECT `nickname` FROM `player_data` WHERE `ip` = :ip;");
        $queryIp->bindValue(":ip", $playerData["ip"]);
        $queryIp = $queryIp->execute();

        if ($queryIp !== false) {
            while (($resultIp = $queryIp->fetchArray(SQLITE3_ASSOC))) {
                $nicknameIp = $resultIp["nickname"];
                if ($nicknameIp !== $nickname && !(in_array($nicknameIp, $nicknames))) {
                    $nicknames[] = $nicknameIp;
                }
            }
        }

        $queryDeviceId = $database->prepare("SELECT `nickname` FROM `player_data` WHERE `deviceid` = :deviceid;");
        $queryDeviceId->bindValue(":deviceid", $playerData["deviceid"]);
        $queryDeviceId = $queryDeviceId->execute();

        if ($queryDeviceId !== false) {
            while (($resultDeviceId = $queryDeviceId->fetchArray(SQLITE3_ASSOC))) {
                $nicknameDeviceId = $resultDeviceId["nickname"];
                if ($nicknameDeviceId !== $nickname && !(in_array($nicknameDeviceId, $nicknames))) {
                    $nicknames[] = $nicknameDeviceId;
                }
            }
        }
        return $nicknames;
    }

    /**
     * Closes actual database.
     */
    public function __destruct()
    {
        $this->getDatabase()->close();
    }
}