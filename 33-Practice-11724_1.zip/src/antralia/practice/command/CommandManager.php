<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\command;

use antralia\practice\ffa\command\ReKitCommand;
use antralia\practice\overall\command\ClearChatCommand;
use antralia\practice\overall\command\CrashCommand;
use antralia\practice\overall\command\EmojiCommand;
use antralia\practice\overall\command\GameModeCommand;
use antralia\practice\overall\command\ListCommand;
use antralia\practice\overall\command\PingCommand;
use antralia\practice\overall\command\PlatformCommand;
use antralia\practice\overall\command\ProfileCommand;
use antralia\practice\overall\command\ReconnectCommand;
use antralia\practice\overall\command\SayCommand;
use antralia\practice\overall\command\SpawnCommand;
use antralia\practice\overall\command\StatusCommand;
use antralia\practice\overall\command\SurrenderCommand;
use antralia\practice\player\chat\command\ReplyCommand;
use antralia\practice\player\chat\command\TellCommand;
use antralia\practice\player\info\InfoCommand;
use antralia\practice\player\punishment\command\BanCommand;
use antralia\practice\player\punishment\command\KickCommand;
use antralia\practice\player\punishment\command\MuteCommand;
use antralia\practice\player\punishment\command\UnbanCommand;
use antralia\practice\player\punishment\command\UnmuteCommand;
use antralia\practice\player\rank\RankCommand;
use antralia\practice\player\report\ReportCommand;
use antralia\practice\player\rules\RulesCommand;
use antralia\practice\player\spectator\SpectateCommand;
use antralia\practice\PracticePlugin;
use antralia\practice\restart\RestartCommand;

final class CommandManager
{

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @return string[]
     */
    public function getCommandsToUnregister(): array
    {
        return [
            "help",
            "me",
            "op",
            "deop",
            "enchant",
            "kill",
            "effect",
            "defaultgamemode",
            "difficulty",
            "spawnpoint",
            "setworldspawn",
            "title",
            "seed",
            "particle",
            "give",
            "plugins",
            "save-on",
            "save-off",
            "save-all",
            "stop",
            "time",
            "whitelist",
            "dumpmemory",
            "clear",
            "banlist",
            "transferserver",
            "version",
            "ban",
            "ban-ip",
            "kick",
            "pardon",
            "pardon-ip",
            "tell",
            "list",
            "say",
            "gamemode",
            "gc",
            "status",
            "timings"
        ];
    }

    /**
     * @return PracticeCommand[]
     */
    public function getCommands(): array
    {
        return [
            new BanCommand($this->plugin),
            new ClearChatCommand($this->plugin),
            new CrashCommand($this->plugin),
            new EmojiCommand($this->plugin),
            new GameModeCommand($this->plugin),
            new InfoCommand($this->plugin),
            new ListCommand($this->plugin),
            new KickCommand($this->plugin),
            new MuteCommand($this->plugin),
            new PingCommand($this->plugin),
            new PlatformCommand($this->plugin),
            new ProfileCommand($this->plugin),
            new RankCommand($this->plugin),
            new ReconnectCommand($this->plugin),
            new ReKitCommand($this->plugin),
            new ReplyCommand($this->plugin),
            new ReportCommand($this->plugin),
            new RestartCommand($this->plugin),
            new RulesCommand($this->plugin),
            new SayCommand($this->plugin),
            new SpawnCommand($this->plugin),
            new SpectateCommand($this->plugin),
            new StatusCommand($this->plugin),
            new SurrenderCommand($this->plugin),
            new TellCommand($this->plugin),
            new UnbanCommand($this->plugin),
            new UnmuteCommand($this->plugin)
        ];
    }
}