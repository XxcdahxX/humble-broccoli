<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\command;

use antralia\core\rcon\RconCommandSender;
use antralia\practice\player\PracticePlayer;
use antralia\practice\PracticePlugin;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\console\ConsoleCommandSender;
use pocketmine\utils\TextFormat;

abstract class PracticeCommand extends Command
{

    /**
     * @var CommandArgs|null
     */
    protected ?CommandArgs $commandArg = null;

    /**
     * @return CommandArgs|null
     */
    public function getCommandArg(): ?CommandArgs
    {
        return $this->commandArg;
    }

    /**
     * @param CommandSender $target
     * @param string|null $permission
     * @return bool
     */
    public function testPermission(CommandSender $target, ?string $permission = null): bool
    {
        if (!($this->testPermissionSilent($target, $permission))) {
            $command = $this->getName();
            if ($target instanceof PracticePlayer) {
                $target->sendMessage(sprintf(PracticePlugin::getInstance()->getTranslationManager()->translate($target, "commandNotFoundOrNoPermission"), $command));
            } else {
                $target->sendMessage(sprintf(TextFormat::RED . "Unknown command: %s. Please check that the command exists and that you have permission to use it.", $command));
            }
            return false;
        } else {
            return true;
        }
    }

    /**
     * @param CommandSender $target
     * @return bool
     */
    public function testConsole(CommandSender $target): bool
    {
        if (!($target instanceof ConsoleCommandSender)) {
            if ($target instanceof PracticePlayer) {
                $target->sendMessage(PracticePlugin::getInstance()->getTranslationManager()->translate($target, "commandOnlyConsole"));
            } else {
                $target->sendMessage(TextFormat::RED . "Command can be executed only from console!");
            }
            return false;
        } else {
            return true;
        }
    }

    /**
     * @param CommandSender $target
     * @return bool
     */
    public function testRcon(CommandSender $target): bool
    {
        if ($target instanceof RconCommandSender) {
            $target->sendMessage(TextFormat::RED . "Command can be executed only from console!");
            return false;
        } else {
            return true;
        }
    }

    /**
     * @param PracticePlayer $player
     * @return string
     */
    abstract public function getDescriptionForPlayer(PracticePlayer $player): string;
}