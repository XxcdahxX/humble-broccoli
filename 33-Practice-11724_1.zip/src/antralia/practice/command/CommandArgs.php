<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\command;

use pocketmine\network\mcpe\protocol\AvailableCommandsPacket;
use pocketmine\network\mcpe\protocol\types\command\CommandEnum;
use pocketmine\network\mcpe\protocol\types\command\CommandParameter;
use pocketmine\network\mcpe\protocol\types\PlayerPermissions;

final class CommandArgs
{

    /**
     * @var int
     */
    public const FLAG_NORMAL = 0;

    /**
     * @var array
     */
    private array $parameters = [];

    /**
     * @var int
     */
    private int $flags;

    /**
     * @var int
     */
    private int $permission;

    /**
     * @param int $flags
     * @param int $permission
     */
    public function __construct(int $flags = self::FLAG_NORMAL, int $permission = PlayerPermissions::MEMBER)
    {
        $this->flags = $flags;
        $this->permission = $permission;
    }

    /**
     * @return int
     */
    public function getFlags(): int
    {
        return $this->flags;
    }

    /**
     * @return int
     */
    public function getPermission(): int
    {
        return $this->permission;
    }

    /**
     * @param int $columnId
     * @param string $name
     * @param int $type
     * @param bool $isOptional
     * @param string|null $enumName
     * @param array $enumValues
     * @param bool $customType
     * @param string|null $postfix
     * @return int
     */
    public function addParameter(int $columnId, string $name, int $type = AvailableCommandsPacket::ARG_TYPE_RAWTEXT, bool $isOptional = false, string $enumName = null, array $enumValues = [], bool $customType = false, string $postfix = null): int
    {
        $param = new CommandParameter();
        $param->paramName = $name;
        $param->paramType = $customType? $type : AvailableCommandsPacket::ARG_FLAG_VALID | $type;
        $param->isOptional = $isOptional;
        $param->postfix = $postfix;

        $this->parameters[$columnId][] = $param;
        $columnKey = count($this->parameters[$columnId]) - 1;

        if ($enumName !== null) {
            $this->setEnum($columnId, $columnKey, $enumName, $enumValues);
        }

        return $columnKey;
    }

    /**
     * @param int $columnId
     * @param int $columnKey
     * @param string|null $name
     * @param array $values
     * @return bool
     */
    public function setEnum(int $columnId, int $columnKey, ?string $name, array $values = []): bool
    {
        $parameter = $this->parameters[$columnId][$columnKey] ?? null;
        if ($parameter === null) {
            return false;
        }

        if ($name !== null) {
            $enum = new CommandEnum($name, $values);
        }

        $parameter->enum = $name === null ? null : $enum;
        return true;
    }

    /**
     * @return array
     */
    public function getOverload(): array
    {
        return $this->parameters;
    }

    /**
     * @return string|null
     */
    public function getCommandName(): ?string
    {
        return $this->getCommandName();
    }
}