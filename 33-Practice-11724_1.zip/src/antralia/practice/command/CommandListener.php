<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\command;

use antralia\practice\player\PracticePlayer;
use antralia\practice\player\rank\RankManager;
use antralia\practice\PracticePlugin;
use pocketmine\event\Listener;
use pocketmine\event\server\CommandEvent;
use pocketmine\event\server\DataPacketSendEvent;
use pocketmine\network\mcpe\protocol\AvailableCommandsPacket;
use pocketmine\utils\TextFormat;

final class CommandListener implements Listener
{

    /**
     * @var int
     */
    public const COMMAND_COOLDOWN = 2;

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @var array<string, int>
     */
    private array $commandCooldown = [];

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @param DataPacketSendEvent $event
     * @return void
     */
    public function handleDataPacketSend(DataPacketSendEvent $event): void
    {
        foreach ($event->getPackets() as $packet) {
            if ($packet instanceof AvailableCommandsPacket) {
                foreach ($event->getTargets() as $target) {
                    $player = $target->getPlayer();
                    if (!($player instanceof PracticePlayer)) {
                        return;
                    }
                    foreach ($this->plugin->getCommandManager()->getCommands() as $command) {
                        $description = $command->getDescriptionForPlayer($player);
                        if (($arg = $command->getCommandArg()) !== null && ($command = $packet->commandData[strtolower($command->getName())] ?? null) !== null) {
                            $command->name = $command->getName();
                            $command->description = $description;
                            $command->flags = $arg->getFlags();
                            $command->overloads = $arg->getOverload();
                        }
                    }
                }
            }
        }
    }

    /**
     * @param CommandEvent $event
     * @return void
     */
    public function handleCommand(CommandEvent $event): void
    {
        $sender = $event->getSender();
        if ($sender instanceof PracticePlayer) {
            if (isset($this->commandCooldown[$sender->getName()])) {
                if (time() - $this->commandCooldown[$sender->getName()] <= self::COMMAND_COOLDOWN) {
                    if ($sender->getRank() !== RankManager::OWNER_RANK) {
                        $event->cancel();
                        $sender->sendMessage($this->plugin->getTranslationManager()->translate($sender, "commandCooldown"));
                        return;
                    }
                }
            }
            $this->commandCooldown[$sender->getName()] = time();
        }

        $command = explode(" ", $event->getCommand())[0];
        if ($this->plugin->getServer()->getCommandMap()->getCommand($command) === null) {
            $event->cancel();
            if ($sender instanceof PracticePlayer) {
                $sender->sendMessage(sprintf($this->plugin->getTranslationManager()->translate($sender, "commandNotFoundOrNoPermission"), $command));
            } else {
                $sender->sendMessage(sprintf(TextFormat::RED . "Unknown command: %s. Please check that the command exists and that you have permission to use it.", $command));
            }
        }
    }
}