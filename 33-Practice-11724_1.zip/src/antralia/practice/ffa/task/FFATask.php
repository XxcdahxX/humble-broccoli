<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\ffa\task;

use antralia\practice\player\PracticePlayer;
use antralia\practice\PracticePlugin;
use pocketmine\scheduler\Task;

final class FFATask extends Task
{

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @return void
     */
    public function onRun(): void
    {
        foreach ($this->plugin->getServer()->getOnlinePlayers() as $player) {
            if (!($player instanceof PracticePlayer)) {
                continue;
            }

            if (!($player->isConnected())) {
                continue;
            }

            $ffaManager = $this->plugin->getFFAManager();
            if ($ffaManager->isInFFA($player)) {
                $ffaManager->updateScoreboard($player);
                if ($ffaManager->isInCombat($player)) {
                    if ($ffaManager->getCombatTime($player) <= 0) {
                        $ffaManager->showPlayers($player);
                        $ffaManager->removeCombatStatus($player);
                        $player->sendActionBarMessage($this->plugin->getTranslationManager()->translate($player, "ffaCombatReduced"));
                    } else {
                        $ffaManager->decreaseCombatTime($player);
                    }
                }
            }
        }
    }
}