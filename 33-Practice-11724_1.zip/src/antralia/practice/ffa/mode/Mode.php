<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\ffa\mode;

use antralia\practice\player\PracticePlayer;
use pocketmine\world\World;

interface Mode
{

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function giveKit(PracticePlayer $player): void;

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function teleportToArena(PracticePlayer $player): void;

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function joinArena(PracticePlayer $player): void;

    /**
     * @param PracticePlayer $player
     * @return bool
     */
    public function isInArena(PracticePlayer $player): bool;

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function removeFromArena(PracticePlayer $player): void;

    /**
     * @param string $nickname
     * @return void
     */
    public function removeFromArenaByName(string $nickname): void;

    /**
     * @return World
     */
    public function getArena(): World;

    /**
     * @return int
     */
    public function getArenaY(): int;

    /**
     * @return array
     */
    public function getPlayers(): array;

    /**
     * @return int
     */
    public function getOnlinePlayers(): int;
}