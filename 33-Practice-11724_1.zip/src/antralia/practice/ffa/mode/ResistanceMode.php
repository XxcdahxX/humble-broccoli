<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\ffa\mode;

use antralia\practice\ffa\FFAManager;
use antralia\practice\player\PracticePlayer;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\enchantment\VanillaEnchantments;
use pocketmine\item\VanillaItems;
use pocketmine\utils\Limits;
use pocketmine\world\sound\EndermanTeleportSound;
use pocketmine\world\World;

final class ResistanceMode implements Mode
{

    /**
     * @var FFAManager
     */
    private FFAManager $ffaManager;

    /**
     * @var string
     */
    private string $arenaName = "ffa_resistance";

    /**
     * @var World
     */
    private World $arena;

    /**
     * @var array
     */
    private array $playing = array();

    /**
     * @param FFAManager $ffaManager
     */
    public function __construct(FFAManager $ffaManager)
    {
        $this->ffaManager = $ffaManager;

        if (!($arena = $this->ffaManager->getPlugin()->getServer()->getWorldManager()->getWorldByName($this->arenaName))) {
            $this->ffaManager->getPlugin()->getServer()->getWorldManager()->loadWorld($this->arenaName);
            $arena = $this->ffaManager->getPlugin()->getServer()->getWorldManager()->getWorldByName($this->arenaName);
            $arena->setTime(World::TIME_DAY);
            $arena->stopTime();
        }
        $arena->setTime(World::TIME_DAY);
        $arena->stopTime();

        $this->arena = $arena;
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function giveKit(PracticePlayer $player): void
    {
        $axe = VanillaItems::DIAMOND_AXE();
        $axe->setUnbreakable();
        $axe->addEnchantment(new EnchantmentInstance(VanillaEnchantments::UNBREAKING(), 10));
        $player->getInventory()->addItem($axe);

        $player->getEffects()->add(new EffectInstance(VanillaEffects::RESISTANCE(), Limits::INT32_MAX, 255, false));
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function teleportToArena(PracticePlayer $player): void
    {
        if (!($arena = $this->ffaManager->getPlugin()->getServer()->getWorldManager()->getWorldByName($this->arenaName))) {
            $this->ffaManager->getPlugin()->getServer()->getWorldManager()->loadWorld($this->arenaName);
            $arena = $this->ffaManager->getPlugin()->getServer()->getWorldManager()->getWorldByName($this->arenaName);
            $arena->setTime(0);
            $arena->stopTime();
        }
        $player->teleport($arena->getSpawnLocation());
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function joinArena(PracticePlayer $player): void
    {
        $this->ffaManager->getPlugin()->getHubManager()->removeFromHub($player);
        $this->ffaManager->setPlayerSettings($player);
        $this->teleportToArena($player);
        $this->giveKit($player);
        $player->getWorld()->addSound($player->getLocation(), new EndermanTeleportSound(), [$player]);
        $this->playing[$player->getName()] = true;

        $this->ffaManager->updateScoreboard($player);
        $this->ffaManager->updateScoreTag($player);
    }

    /**
     * @param PracticePlayer $player
     * @return bool
     */
    public function isInArena(PracticePlayer $player): bool
    {
        return isset($this->playing[$player->getName()]);
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function removeFromArena(PracticePlayer $player): void
    {
        if (isset($this->playing[$player->getName()])) {
            unset($this->playing[$player->getName()]);
        }
    }

    /**
     * @param string $nickname
     * @return void
     */
    public function removeFromArenaByName(string $nickname): void
    {
        if (isset($this->playing[$nickname])) {
            unset($this->playing[$nickname]);
        }
    }

    /**
     * @return World
     */
    public function getArena(): World
    {
        return $this->arena;
    }

    /**
     * @return int
     */
    public function getArenaY(): int
    {
        return 66;
    }

    /**
     * @return array
     */
    public function getPlayers(): array
    {
        return $this->playing;
    }

    /**
     * @return int
     */
    public function getOnlinePlayers(): int
    {
        return count($this->getPlayers());
    }
}