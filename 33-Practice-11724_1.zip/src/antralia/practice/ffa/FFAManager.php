<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\ffa;

use antralia\core\form\SimpleForm;
use antralia\core\scoreboard\Scoreboard;
use antralia\practice\ffa\mode\ComboMode;
use antralia\practice\ffa\mode\FistMode;
use antralia\practice\ffa\mode\GAppleMode;
use antralia\practice\ffa\mode\NoDebuffMode;
use antralia\practice\ffa\mode\ResistanceMode;
use antralia\practice\ffa\mode\SoupMode;
use antralia\practice\ffa\mode\SumoMode;
use antralia\practice\player\PracticePlayer;
use antralia\practice\PracticePlugin;
use pocketmine\entity\Location;
use pocketmine\math\Vector3;
use pocketmine\player\GameMode;
use pocketmine\player\Player;
use pocketmine\world\Position;

final class FFAManager
{

    /**
     * @var int
     */
    public const COMBAT_TIME = 15;

    /**
     * @var int
     */
    public const RESPAWN_DELAY = 2;

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @var NoDebuffMode
     */
    private NoDebuffMode $noDebuffManager;

    /**
     * @var SoupMode
     */
    private SoupMode $soupManager;

    /**
     * @var SumoMode
     */
    private SumoMode $sumoManager;

    /**
     * @var FistMode
     */
    private FistMode $fistManager;

    /**
     * @var GAppleMode
     */
    private GAppleMode $gAppleManager;

    /**
     * @var ResistanceMode
     */
    private ResistanceMode $resistanceManager;

    /**
     * @var ComboMode
     */
    private ComboMode $comboManager;

    /**
     * @var array<string, string>
     */
    private array $combat = [];

    /**
     * @var array<string, int>
     */
    private array $combatTime = [];

    /**
     * @var array<string, int>
     */
    private array $respawnDelay = [];

    /**
     * @return void
     */
    private function registerManagers(): void
    {
        $this->noDebuffManager = new NoDebuffMode($this);
        $this->soupManager = new SoupMode($this);
        $this->sumoManager = new SumoMode($this);
        $this->fistManager = new FistMode($this);
        $this->gAppleManager = new GAppleMode($this);
        $this->resistanceManager = new ResistanceMode($this);
        $this->comboManager = new ComboMode($this);
    }

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;
        $this->registerManagers();
    }

    /**
     * @return NoDebuffMode
     */
    public function getNoDebuffManager(): NoDebuffMode
    {
        return $this->noDebuffManager;
    }

    /**
     * @return SoupMode
     */
    public function getSoupManager(): SoupMode
    {
        return $this->soupManager;
    }

    /**
     * @return SumoMode
     */
    public function getSumoManager(): SumoMode
    {
        return $this->sumoManager;
    }

    /**
     * @return FistMode
     */
    public function getFistManager(): FistMode
    {
        return $this->fistManager;
    }

    /**
     * @return GAppleMode
     */
    public function getGAppleManager(): GAppleMode
    {
        return $this->gAppleManager;
    }

    /**
     * @return ResistanceMode
     */
    public function getResistanceManager(): ResistanceMode
    {
        return $this->resistanceManager;
    }

    /**
     * @return ComboMode
     */
    public function getComboManager(): ComboMode
    {
        return $this->comboManager;
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function setPlayerSettings(PracticePlayer $player): void
    {
        if (!($player->isConnected())) {
            return;
        }

        $player->setGamemode(GameMode::ADVENTURE());
        $player->setFlying(false);
        $player->setAllowFlight(false);

        $player->setMaxHealth(20);
        $player->setHealth(20);
        $player->getHungerManager()->setFood(20);

        $player->getInventory()->clearAll();
        $player->getArmorInventory()->clearAll();
        $player->getCursorInventory()->clearAll();
        $player->getCraftingGrid()->clearAll();

        $player->extinguish();
        $player->getEffects()->clear();
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function toSpawn(PracticePlayer $player): void
    {
        if (!($player->isConnected())) {
            return;
        }

        $this->setPlayerSettings($player);
        $this->removeFromFFA($player);
    }

    /**
     * @param PracticePlayer $player
     * @param Position $position
     * @return void
     */
    public function setSpectator(PracticePlayer $player, Position $position): void
    {
        if (!($player->isConnected())) {
            return;
        }

        $player->setHealth($player->getMaxHealth());
        $player->setGamemode(GameMode::SPECTATOR());

        $player->getInventory()->clearAll();
        $player->getArmorInventory()->clearAll();
        $player->getCursorInventory()->clearAll();
        $player->getCraftingGrid()->clearAll();

        $player->getEffects()->clear();
        $player->getXpManager()->setXpAndProgress(0, 0);

        $player->teleport(new Vector3($position->getX(), $position->getY() + 2, $position->getZ()));

        $this->setRespawnDelay($player);
    }

    /**
     * @param PracticePlayer $player
     * @param PracticePlayer $enemy
     * @return void
     */
    public function updateCombatTime(PracticePlayer $player, PracticePlayer $enemy): void
    {
        $this->combatTime[$player->getName()] = self::COMBAT_TIME;
        $this->combatTime[$enemy->getName()] = self::COMBAT_TIME;
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function decreaseCombatTime(PracticePlayer $player): void
    {
        $this->combatTime[$player->getName()]--;
    }

    /**
     * @param PracticePlayer $player
     * @param PracticePlayer $enemy
     * @return void
     */
    public function setCombatStatus(PracticePlayer $player, PracticePlayer $enemy): void
    {
        $this->combat[$player->getName()] = $enemy->getName();
        $this->combat[$enemy->getName()] = $player->getName();

        $this->updateCombatTime($player, $enemy);
    }

    /**
     * @param PracticePlayer $player
     * @return bool
     */
    public function isInCombat(PracticePlayer $player): bool
    {
        return isset($this->combat[$player->getName()]);
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function removeCombatStatus(PracticePlayer $player): void
    {
        if (isset($this->combat[$player->getName()])) {
            unset($this->combat[$player->getName()]);
        }

        if (isset($this->combatTime[$player->getName()])) {
            unset($this->combatTime[$player->getName()]);
        }
    }

    /**
     * @param string $nickname
     * @return void
     */
    public function removeCombatStatusByName(string $nickname): void
    {
        if (isset($this->combat[$nickname])) {
            unset($this->combat[$nickname]);
        }

        if (isset($this->combatTime[$nickname])) {
            unset($this->combatTime[$nickname]);
        }
    }

    /**
     * @param PracticePlayer $player
     * @return string
     */
    public function getEnemyName(PracticePlayer $player): string
    {
        return $this->combat[$player->getName()] ?? "";
    }

    /**
     * @param PracticePlayer $player
     * @return Player|null
     */
    public function getEnemy(PracticePlayer $player): ?Player
    {
        $enemyName = $this->getEnemyName($player);
        foreach ($this->plugin->getServer()->getOnlinePlayers() as $onlinePlayer) {
            if ($onlinePlayer->getName() === $enemyName) {
                return $onlinePlayer;
            }
        }
        return null;
    }

    /**
     * @param PracticePlayer $player
     * @return int
     */
    public function getEnemyPing(PracticePlayer $player): int
    {
        if ($this->isInCombat($player)) {
            $enemy = $this->plugin->getServer()->getPlayerExact($this->combat[$player->getName()]);
            if (!($enemy)) {
                $this->removeCombatStatus($player);
                return 0;
            } elseif (!($enemy->isConnected())) {
                return 0;
            } else {
                return $enemy->getNetworkSession()->getPing() === null ? 0 : $enemy->getNetworkSession()->getPing();
            }
        } else {
            return 0;
        }
    }

    /**
     * @param PracticePlayer $player
     * @return int
     */
    public function getCombatTime(PracticePlayer $player): int
    {
        return $this->isInCombat($player) ? $this->combatTime[$player->getName()] : 0;
    }

    /**
     * @param PracticePlayer $player
     * @return bool
     */
    public function isInFFA(PracticePlayer $player): bool
    {
        return $this->getNoDebuffManager()->isInArena($player) || $this->getSoupManager()->isInArena($player) || $this->getSumoManager()->isInArena($player) || $this->getFistManager()->isInArena($player) || $this->getGAppleManager()->isInArena($player) || $this->getResistanceManager()->isInArena($player) || $this->getComboManager()->isInArena($player);
    }

    /**
     * @param PracticePlayer $player
     * @return bool
     */
    public function hasRespawnDelay(PracticePlayer $player): bool
    {
        return isset($this->respawnDelay[$player->getName()]);
    }

    /**
     * @param PracticePlayer $player
     * @return int
     */
    public function getRespawnDelay(PracticePlayer $player): int
    {
        return $this->respawnDelay[$player->getName()];
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function setRespawnDelay(PracticePlayer $player): void
    {
        $this->respawnDelay[$player->getName()] = self::RESPAWN_DELAY;
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function decreaseRespawnDelay(PracticePlayer $player): void
    {
        if (isset($this->respawnDelay[$player->getName()])) {
            $this->respawnDelay[$player->getName()]--;
        }
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function removeRespawnDelay(PracticePlayer $player): void
    {
        if (isset($this->respawnDelay[$player->getName()])) {
            unset($this->respawnDelay[$player->getName()]);
        }
    }

    /**
     * @param PracticePlayer $player
     * @param PracticePlayer $target
     * @return void
     */
    public function hidePlayer(PracticePlayer $player, PracticePlayer $target): void
    {
        if ($this->isInCombat($player)) {
            if ($this->plugin->getTogglesManager()->getToggleStatus($player, "hide_players")) {
                if ($target->getName() === $player->getName() || $target->getName() === $this->getEnemyName($player)) {
                    return;
                }
                $player->hidePlayer($target);
            }
        }
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function hidePlayers(PracticePlayer $player): void
    {
        if ($this->isInCombat($player)) {
            if ($this->plugin->getTogglesManager()->getToggleStatus($player, "hide_players")) {
                foreach ($this->plugin->getServer()->getOnlinePlayers() as $onlinePlayer) {
                    if ($onlinePlayer->getName() === $player->getName() || $onlinePlayer->getName() === $this->getEnemyName($player)) {
                        continue;
                    }
                    $player->hidePlayer($onlinePlayer);
                }
            }
        }
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function showPlayers(PracticePlayer $player): void
    {
        if ($this->isInCombat($player)) {
            if ($this->plugin->getTogglesManager()->getToggleStatus($player, "hide_players")) {
                foreach ($this->plugin->getServer()->getOnlinePlayers() as $onlinePlayer) {
                    if ($onlinePlayer->getName() === $player->getName() || $onlinePlayer->getName() === $this->getEnemyName($player)) {
                        continue;
                    }
                    $player->showPlayer($onlinePlayer);
                }
            }
        }
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function removeFromFFA(PracticePlayer $player): void
    {
        if ($this->getNoDebuffManager()->isInArena($player)) {
            $this->getNoDebuffManager()->removeFromArena($player);
        } elseif ($this->getSoupManager()->isInArena($player)) {
            $this->getSoupManager()->removeFromArena($player);
        } elseif ($this->getSumoManager()->isInArena($player)) {
            $this->getSumoManager()->removeFromArena($player);
        } elseif ($this->getFistManager()->isInArena($player)) {
            $this->getFistManager()->removeFromArena($player);
        } elseif ($this->getGAppleManager()->isInArena($player)) {
            $this->getGAppleManager()->removeFromArena($player);
        } elseif ($this->getResistanceManager()->isInArena($player)) {
            $this->getResistanceManager()->removeFromArena($player);
        } elseif ($this->getComboManager()->isInArena($player)) {
            $this->getComboManager()->removeFromArena($player);
        }

        if ($this->isInCombat($player)) {
            $this->removeCombatStatus($player);
            $this->showPlayers($player);
        }

        $hubManager = $this->plugin->getHubManager();
        $hubManager->setPlayerSettings($player);
        $hubManager->sendMenuItems($player);
        $hubManager->updateScoreboard($player);
        $hubManager->updateScoreTag($player);
    }

    /**
     * @param PracticePlayer $dead
     * @param PracticePlayer $killer
     * @return void
     */
    public function processKill(PracticePlayer $dead, PracticePlayer $killer): void
    {
        $noDebuffManager = $this->getNoDebuffManager();
        $soupManager = $this->getSoupManager();
        $sumoManager = $this->getSumoManager();
        $fistManager = $this->getFistManager();
        $gAppleManager = $this->getGAppleManager();
        $resistanceManager = $this->getResistanceManager();
        $comboManager = $this->getComboManager();

        $translationManager = $this->plugin->getTranslationManager();

        $statisticsFlag = true;
        if ($noDebuffManager->isInArena($dead) && $noDebuffManager->isInArena($killer)) {
            foreach ($noDebuffManager->getPlayers() as $arenaPlayerName => $_) {
                if (!($arenaPlayer = $this->plugin->getServer()->getPlayerExact($arenaPlayerName))) {
                    return;
                }

                if (!($arenaPlayer instanceof PracticePlayer)) {
                    return;
                }

                $arenaPlayer->sendMessage(sprintf(
                    $translationManager->translate($arenaPlayer, "ffaNoDebuffKill"),
                    $dead->getName(),
                    $noDebuffManager->countPotions($dead),
                    $killer->getName(),
                    $noDebuffManager->countPotions($killer),
                    round($killer->getHealth())
                ));
            }

            $this->setPlayerSettings($killer);
            $noDebuffManager->giveKit($killer);
        } elseif ($soupManager->isInArena($dead) && $soupManager->isInArena($killer)) {
            foreach ($soupManager->getPlayers() as $arenaPlayerName => $_) {
                if (!($arenaPlayer = $this->plugin->getServer()->getPlayerExact($arenaPlayerName))) {
                    return;
                }

                if (!($arenaPlayer instanceof PracticePlayer)) {
                    return;
                }

                $arenaPlayer->sendMessage(sprintf(
                    $translationManager->translate($arenaPlayer, "ffaSoupKill"),
                    $dead->getName(),
                    $soupManager->countSoups($dead),
                    $killer->getName(),
                    $soupManager->countSoups($killer),
                    round($killer->getHealth())
                ));
            }

            $this->setPlayerSettings($killer);
            $soupManager->giveKit($killer);
        } elseif ($sumoManager->isInArena($dead) && $sumoManager->isInArena($killer)) {
            foreach ($sumoManager->getPlayers() as $arenaPlayerName => $_) {
                if (!($arenaPlayer = $this->plugin->getServer()->getPlayerExact($arenaPlayerName))) {
                    return;
                }

                if (!($arenaPlayer instanceof PracticePlayer)) {
                    return;
                }

                $arenaPlayer->sendMessage(sprintf(
                    $translationManager->translate($arenaPlayer, "ffaSumoKill"),
                    $dead->getName(),
                    $killer->getName(),
                ));
            }

            $this->setPlayerSettings($killer);
            $sumoManager->giveKit($killer);
        } elseif ($fistManager->isInArena($dead) && $fistManager->isInArena($killer)) {
            foreach ($fistManager->getPlayers() as $arenaPlayerName => $_) {
                if (!($arenaPlayer = $this->plugin->getServer()->getPlayerExact($arenaPlayerName))) {
                    return;
                }

                if (!($arenaPlayer instanceof PracticePlayer)) {
                    return;
                }

                $arenaPlayer->sendMessage(sprintf(
                    $translationManager->translate($arenaPlayer, "ffaFistKill"),
                    $dead->getName(),
                    $killer->getName(),
                    round($killer->getHealth())
                ));
            }

            $this->setPlayerSettings($killer);
            $fistManager->giveKit($killer);
        } elseif ($gAppleManager->isInArena($dead) && $gAppleManager->isInArena($killer)) {
            foreach ($gAppleManager->getPlayers() as $arenaPlayerName => $_) {
                if (!($arenaPlayer = $this->plugin->getServer()->getPlayerExact($arenaPlayerName))) {
                    return;
                }

                if (!($arenaPlayer instanceof PracticePlayer)) {
                    return;
                }

                $arenaPlayer->sendMessage(sprintf(
                    $translationManager->translate($arenaPlayer, "ffaGAppleKill"),
                    $dead->getName(),
                    $killer->getName(),
                    round($killer->getHealth())
                ));
            }

            $this->setPlayerSettings($killer);
            $gAppleManager->giveKit($killer);
        } elseif ($resistanceManager->isInArena($dead) && $resistanceManager->isInArena($killer)) {
            foreach ($resistanceManager->getPlayers() as $arenaPlayerName => $_) {
                if (!($arenaPlayer = $this->plugin->getServer()->getPlayerExact($arenaPlayerName))) {
                    return;
                }

                if (!($arenaPlayer instanceof PracticePlayer)) {
                    return;
                }

                $arenaPlayer->sendMessage(sprintf(
                    $translationManager->translate($arenaPlayer, "ffaResistanceKill"),
                    $dead->getName(),
                    $killer->getName()
                ));
            }

            $this->setPlayerSettings($killer);
            $resistanceManager->giveKit($killer);
            $statisticsFlag = false;
        } elseif ($comboManager->isInArena($dead) && $comboManager->isInArena($killer)) {
            foreach ($comboManager->getPlayers() as $arenaPlayerName => $_) {
                if (!($arenaPlayer = $this->plugin->getServer()->getPlayerExact($arenaPlayerName))) {
                    return;
                }

                if (!($arenaPlayer instanceof PracticePlayer)) {
                    return;
                }

                $arenaPlayer->sendMessage(sprintf(
                    $translationManager->translate($arenaPlayer, "ffaComboKill"),
                    $dead->getName(),
                    $killer->getName(),
                    round($killer->getHealth())
                ));
            }

            $this->setPlayerSettings($killer);
            $comboManager->giveKit($killer);
        }

        if ($statisticsFlag) {
            $statisticsManager = $this->plugin->getStatisticsManager();
            $statisticsManager->addKill($killer);
            $statisticsManager->addDeath($dead);
        }

        $this->updateScoreTag($killer);
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function reKit(PracticePlayer $player): void
    {
        if ($this->getNoDebuffManager()->isInArena($player)) {
            if ($this->plugin->getCooldownManager()->hasEnderPearlCooldown($player)) {
                $this->plugin->getCooldownManager()->removeEnderPearlCooldown($player);
            }
            $this->setPlayerSettings($player);
            $this->getNoDebuffManager()->giveKit($player);
        } elseif ($this->getSoupManager()->isInArena($player)) {
            $this->setPlayerSettings($player);
            $this->getSoupManager()->giveKit($player);
        } elseif ($this->getSumoManager()->isInArena($player)) {
            $this->setPlayerSettings($player);
            $this->getSumoManager()->giveKit($player);
        } elseif ($this->getFistManager()->isInArena($player)) {
            $this->setPlayerSettings($player);
            $this->getFistManager()->giveKit($player);
        } elseif ($this->getGAppleManager()->isInArena($player)) {
            $this->setPlayerSettings($player);
            $this->getGAppleManager()->giveKit($player);
        } elseif ($this->getResistanceManager()->isInArena($player)) {
            $this->setPlayerSettings($player);
            $this->getResistanceManager()->giveKit($player);
        } elseif ($this->getComboManager()->isInArena($player)) {
            $this->setPlayerSettings($player);
            $this->getComboManager()->giveKit($player);
        }
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function joinArenaAgain(PracticePlayer $player): void
    {
        $this->setPlayerSettings($player);

        if ($this->isInCombat($player)) {
            $this->removeCombatStatus($player);
            $this->showPlayers($player);
        }

        if ($this->getNoDebuffManager()->isInArena($player)) {
            $this->getNoDebuffManager()->removeFromArena($player);
            $this->getNoDebuffManager()->joinArena($player);
        } elseif ($this->getSoupManager()->isInArena($player)) {
            $this->getSoupManager()->removeFromArena($player);
            $this->getSoupManager()->joinArena($player);
        } elseif ($this->getSumoManager()->isInArena($player)) {
            $this->getSumoManager()->removeFromArena($player);
            $this->getSumoManager()->joinArena($player);
        } elseif ($this->getFistManager()->isInArena($player)) {
            $this->getFistManager()->removeFromArena($player);
            $this->getFistManager()->joinArena($player);
        } elseif ($this->getGAppleManager()->isInArena($player)) {
            $this->getGAppleManager()->removeFromArena($player);
            $this->getGAppleManager()->joinArena($player);
        } elseif ($this->getResistanceManager()->isInArena($player)) {
            $this->getResistanceManager()->removeFromArena($player);
            $this->getResistanceManager()->joinArena($player);
        } elseif ($this->getComboManager()->isInArena($player)) {
            $this->getComboManager()->removeFromArena($player);
            $this->getComboManager()->joinArena($player);
        }
    }

    /**
     * @param PracticePlayer $player
     * @return Location
     */
    public function getArenaPosition(PracticePlayer $player): Position
    {
        if ($this->getNoDebuffManager()->isInArena($player)) {
            return $this->getNoDebuffManager()->getArena()->getSpawnLocation();
        } elseif ($this->getSoupManager()->isInArena($player)) {
            return $this->getSoupManager()->getArena()->getSpawnLocation();
        } elseif ($this->getSumoManager()->isInArena($player)) {
            return $this->getSumoManager()->getArena()->getSpawnLocation();
        } elseif ($this->getFistManager()->isInArena($player)) {
            return $this->getFistManager()->getArena()->getSpawnLocation();
        } elseif ($this->getGAppleManager()->isInArena($player)) {
            return $this->getGAppleManager()->getArena()->getSpawnLocation();
        } elseif ($this->getResistanceManager()->isInArena($player)) {
            return $this->getResistanceManager()->getArena()->getSpawnLocation();
        } elseif ($this->getComboManager()->isInArena($player)) {
            return $this->getComboManager()->getArena()->getSpawnLocation();
        } else {
            return $player->getPosition();
        }
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function updateScoreboard(PracticePlayer $player): void
    {
        if ($this->plugin->getTogglesManager()->getToggleStatus($player, "scoreboard")) {
            $line = $this->plugin->getTranslationManager()->translate($player, "ffaScoreboard");

            Scoreboard::setScore($player, $line[0]);
            Scoreboard::setScoreLine($player, 1, $line[1]);
            Scoreboard::setScoreLine($player, 2, sprintf($line[2], (string)$player->getNetworkSession()->getPing()));
            Scoreboard::setScoreLine($player, 3, sprintf($line[3], (string)$this->getEnemyPing($player)));
            Scoreboard::setScoreLine($player, 4, $line[4]);
            Scoreboard::setScoreLine($player, 5, sprintf($line[5], (string)$this->getCombatTime($player)));
            Scoreboard::setScoreLine($player, 6, $line[6]);
            Scoreboard::setScoreLine($player, 7, $line[7]);
        }
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function updateScoreTag(PracticePlayer $player): void
    {
        if ($this->getSumoManager()->isInArena($player) || $this->getResistanceManager()->isInArena($player)) {
            $player->setScoreTag("");
        } else {
            $player->setScoreTag("§f" . round($player->getHealth()) . "");
        }
    }

    /**
     * @return int
     */
    public function getOnlinePlayersCount(): int
    {
        return $this->getNoDebuffManager()->getOnlinePlayers() + $this->getSoupManager()->getOnlinePlayers() + $this->getSumoManager()->getOnlinePlayers() + $this->getFistManager()->getOnlinePlayers() + $this->getGAppleManager()->getOnlinePlayers() + $this->getResistanceManager()->getOnlinePlayers() + $this->getComboManager()->getOnlinePlayers();
    }

    /**
     * @return PracticePlugin
     */
    public function getPlugin(): PracticePlugin
    {
        return $this->plugin;
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function sendFFAForm(PracticePlayer $player): void
    {
        $form = new SimpleForm(function (PracticePlayer $player, int $data = null): void {
            if ($data === null) {
                return;
            }

            $translationManager = $this->plugin->getTranslationManager();

            switch ($data) {
                case 0:
                    $this->getNoDebuffManager()->joinArena($player);
                    $player->sendMessage(sprintf($translationManager->translate($player, "joinedFFA"), "NoDebuff"));
                    break;
                case 1:
                    $this->getSoupManager()->joinArena($player);
                    $player->sendMessage(sprintf($translationManager->translate($player, "joinedFFA"), "Soup"));
                    break;
                case 2:
                    $this->getSumoManager()->joinArena($player);
                    $player->sendMessage(sprintf($translationManager->translate($player, "joinedFFA"), "Sumo"));
                    break;
                case 3:
                    $this->getFistManager()->joinArena($player);
                    $player->sendMessage(sprintf($translationManager->translate($player, "joinedFFA"), "Fist"));
                    break;
                case 4:
                    $this->getGAppleManager()->joinArena($player);
                    $player->sendMessage(sprintf($translationManager->translate($player, "joinedFFA"), "GApple"));
                    break;
                case 5:
                    $this->getResistanceManager()->joinArena($player);
                    $player->sendMessage(sprintf($translationManager->translate($player, "joinedFFA"), "Resistance"));
                    break;
                case 6:
                    $this->getComboManager()->joinArena($player);
                    $player->sendMessage(sprintf($translationManager->translate($player, "joinedFFA"), "Combo"));
                    break;
                case 7:
                    $this->plugin->getHubManager()->sendGamesForm($player);
                    break;
            }
        });

        $formContents = $this->plugin->getTranslationManager()->translate($player, "ffaForm");

        $form->setTitle($formContents[0]);

        $form->addButton(sprintf($formContents[1], $this->getNoDebuffManager()->getOnlinePlayers()), SimpleForm::IMAGE_TYPE_PATH, "textures/items/potion_bottle_splash_heal");
        $form->addButton(sprintf($formContents[2], $this->getSoupManager()->getOnlinePlayers()), SimpleForm::IMAGE_TYPE_PATH, "textures/items/mushroom_stew");
        $form->addButton(sprintf($formContents[3], $this->getSumoManager()->getOnlinePlayers()), SimpleForm::IMAGE_TYPE_PATH, "textures/items/slimeball");
        $form->addButton(sprintf($formContents[4], $this->getFistManager()->getOnlinePlayers()), SimpleForm::IMAGE_TYPE_PATH, "textures/items/beef_cooked");
        $form->addButton(sprintf($formContents[5], $this->getGAppleManager()->getOnlinePlayers()), SimpleForm::IMAGE_TYPE_PATH, "textures/items/apple_golden");
        $form->addButton(sprintf($formContents[6], $this->getResistanceManager()->getOnlinePlayers()), SimpleForm::IMAGE_TYPE_PATH, "textures/ui/resistance_effect");
        $form->addButton(sprintf($formContents[7], $this->getComboManager()->getOnlinePlayers()), SimpleForm::IMAGE_TYPE_PATH, "textures/items/feather");
        $form->addButton($formContents[8], SimpleForm::IMAGE_TYPE_PATH, "textures/ui/arrow_left");

        $player->sendForm($form);
    }
}