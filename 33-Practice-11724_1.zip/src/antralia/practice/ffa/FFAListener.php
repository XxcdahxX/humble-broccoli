<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\ffa;

use antralia\practice\player\PracticePlayer;
use antralia\practice\PracticePlugin;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerItemUseEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\item\ConsumableItem;
use pocketmine\item\EnderPearl;
use pocketmine\item\SplashPotion;
use pocketmine\player\GameMode;

final class FFAListener implements Listener
{

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @param EntityDamageEvent $event
     * @return void
     */
    public function handleEntityDamage(EntityDamageEvent $event): void
    {
        $entity = $event->getEntity();
        $ffaManager = $this->plugin->getFFAManager();

        if (!($entity instanceof PracticePlayer)) {
            return;
        }

        if ($event instanceof EntityDamageByEntityEvent) {
            $damager = $event->getDamager();

            if (!($damager instanceof PracticePlayer)) {
                return;
            }

            $translationManager = $this->plugin->getTranslationManager();

            if ($ffaManager->isInFFA($entity) && $ffaManager->isInFFA($damager)) {
                if ($entity->getName() === $damager->getName()) {
                    $event->cancel();
                    return;
                }

                if ($ffaManager->getSumoManager()->isInArena($entity) || $ffaManager->getResistanceManager()->isInArena($entity)) {
                    $event->setModifier(0, EntityDamageEvent::MODIFIER_CRITICAL);
                }

                if ($ffaManager->isInCombat($damager) && $ffaManager->getEnemyName($damager) !== $entity->getName()) {
                    $damager->sendActionBarMessage(sprintf($translationManager->translate($damager, "ffaSelfInCombat"), $ffaManager->getEnemyName($damager)));
                    $event->cancel();
                    return;
                }

                if ($ffaManager->isInCombat($entity) && $ffaManager->getEnemyName($entity) !== $damager->getName()) {
                    $damager->sendActionBarMessage(sprintf($translationManager->translate($damager, "ffaPlayerInCombat"), $entity->getName(), $ffaManager->getEnemyName($entity)));
                    $event->cancel();
                    return;
                }

                if (!($ffaManager->isInCombat($damager) && $ffaManager->isInCombat($entity))) {
                    $damager->sendActionBarMessage(sprintf($translationManager->translate($damager, "ffaYouAreNowInCombat"), $entity->getName()));
                    $entity->sendActionBarMessage(sprintf($translationManager->translate($entity, "ffaYouAreNowInCombat"), $damager->getName()));

                    $ffaManager->setCombatStatus($damager, $entity);

                    $ffaManager->hidePlayers($damager);
                    $ffaManager->hidePlayers($entity);
                    return;
                }

                if ($entity->getHealth() - $event->getFinalDamage() <= 0) {
                    $cooldownManager = $this->plugin->getCooldownManager();

                    $ffaManager->showPlayers($entity);
                    $ffaManager->showPlayers($damager);

                    $ffaManager->removeCombatStatus($entity);
                    $ffaManager->removeCombatStatus($damager);

                    $entity->customDeathAnimation($damager->getLocation());

                    $ffaManager->processKill($entity, $damager);
                    $ffaManager->setSpectator($entity, $damager->getPosition());

                    if ($cooldownManager->hasEnderPearlCooldown($entity)) {
                        $cooldownManager->removeEnderPearlCooldown($entity);
                    }

                    if ($cooldownManager->hasEnderPearlCooldown($damager)) {
                        $cooldownManager->removeEnderPearlCooldown($damager);
                    }

                    $deathTitle = $translationManager->translate($entity, "ffaDeathTitle");
                    $entity->sendTitle($deathTitle[0], sprintf($deathTitle[1], $damager->getName()));
                    $damager->sendActionBarMessage($translationManager->translate($damager, "ffaCombatReduced"));

                    $event->cancel();
                    return;
                }

                $ffaManager->updateCombatTime($damager, $entity);
                return;
            }
        }

        if ($event->getCause() === EntityDamageEvent::CAUSE_VOID) {
            if ($ffaManager->isInFFA($entity)) {
                $event->cancel();

                $translationManager = $ffaManager->getPlugin()->getTranslationManager();
                if ($ffaManager->isInCombat($entity)) {
                    $damager = $ffaManager->getEnemy($entity);

                    if (!($damager instanceof PracticePlayer)) {
                        return;
                    }

                    $ffaManager->showPlayers($entity);
                    $ffaManager->showPlayers($damager);

                    $ffaManager->removeCombatStatus($entity);
                    $ffaManager->removeCombatStatus($damager);

                    $ffaManager->processKill($entity, $damager);
                    $ffaManager->setSpectator($entity, $damager->getPosition());

                    $deathTitle = $translationManager->translate($entity, "ffaDeathTitle");
                    $entity->sendTitle($deathTitle[0], sprintf($deathTitle[1], $damager->getName()));
                    $damager->sendActionBarMessage($translationManager->translate($damager, "ffaCombatReduced"));
                } else {
                    $ffaManager->setSpectator($entity, $ffaManager->getArenaPosition($entity));

                    $deathTitle = $translationManager->translate($entity, "ffaDeathTitle");
                    $entity->sendTitle($deathTitle[0], sprintf($deathTitle[1], "..."));
                }
                return;
            }
        }

        if ($event->getCause() !== EntityDamageEvent::CAUSE_ENTITY_ATTACK) {
            if ($ffaManager->isInFFA($entity)) {
                $event->cancel();
            }
        }
    }

    /**
     * @param PlayerRespawnEvent $event
     * @return void
     */
    public function handlePlayerRespawn(PlayerRespawnEvent $event): void
    {
        $player = $event->getPlayer();

        if (!($player instanceof PracticePlayer)) {
            return;
        }

        $ffaManager = $this->plugin->getFFAManager();
        if ($ffaManager->isInFFA($player)) {
            $ffaManager->toSpawn($player);
        }
    }

    /**
     * @param PlayerDeathEvent $event
     * @return void
     */
    public function handlePlayerDeath(PlayerDeathEvent $event): void
    {
        $player = $event->getPlayer();

        if (!($player instanceof PracticePlayer)) {
            return;
        }

        $ffaManager = $this->plugin->getFFAManager();
        $cooldownManager = $this->plugin->getCooldownManager();

        if ($ffaManager->isInFFA($player)) {
            $lastDamageCause = $player->getLastDamageCause();

            $event->setDrops([]);
            $event->setXpDropAmount(0);
            $event->setKeepInventory(true);

            if ($lastDamageCause instanceof EntityDamageByEntityEvent) {
                $damager = $lastDamageCause->getDamager();

                if (!($damager instanceof PracticePlayer)) {
                    return;
                }

                $ffaManager->showPlayers($player);
                $ffaManager->showPlayers($damager);

                $ffaManager->removeCombatStatus($player);
                $ffaManager->removeCombatStatus($damager);

                if ($cooldownManager->hasEnderPearlCooldown($player)) {
                    $cooldownManager->removeEnderPearlCooldown($player);
                }

                if ($cooldownManager->hasEnderPearlCooldown($damager)) {
                    $cooldownManager->removeEnderPearlCooldown($damager);
                }

                $damager->sendActionBarMessage($this->plugin->getTranslationManager()->translate($damager, "ffaCombatReduced"));

                $ffaManager->processKill($player, $damager);
            }
        }
    }

    /**
     * @param PlayerItemUseEvent $event
     * @return void
     */
    public function handlePlayerItemUse(PlayerItemUseEvent $event): void
    {
        $player = $event->getPlayer();

        if (!($player instanceof PracticePlayer)) {
            return;
        }

        if ($this->plugin->getFFAManager()->isInFFA($player)) {
            $item = $event->getItem();
            if (!($item instanceof ConsumableItem || $item instanceof SplashPotion || $item instanceof EnderPearl)) {
                $event->cancel();
            }

            if (!($player->getGamemode()->equals(GameMode::ADVENTURE()))) {
                $event->cancel();
            }
        }
    }

    /**
     * @param PlayerJoinEvent $event
     * @return void
     */
    public function handlePlayerJoin(PlayerJoinEvent $event): void
    {
        $player = $event->getPlayer();

        if (!($player instanceof PracticePlayer)) {
            return;
        }

        foreach ($this->plugin->getServer()->getOnlinePlayers() as $onlinePlayer) {
            if (!($onlinePlayer instanceof PracticePlayer)) {
                continue;
            }

            if (!($onlinePlayer->isConnected())) {
                continue;
            }

            $ffaManager = $this->plugin->getFFAManager();
            if ($ffaManager->isInCombat($onlinePlayer)) {
                $ffaManager->hidePlayer($onlinePlayer, $player);
            }
        }
    }

    /**
     * @param PlayerQuitEvent $event
     * @return void
     */
    public function handlePlayerQuit(PlayerQuitEvent $event): void
    {
        $player = $event->getPlayer();

        if (!($player instanceof PracticePlayer)) {
            return;
        }

        $ffaManager = $this->plugin->getFFAManager();
        if ($ffaManager->isInFFA($player)) {
            $cooldownManager = $this->plugin->getCooldownManager();

            if ($ffaManager->hasRespawnDelay($player)) {
                $ffaManager->removeRespawnDelay($player);
            }

            if ($ffaManager->isInCombat($player)) {
                $enemyName = $ffaManager->getEnemyName($player);
                $enemy = $this->plugin->getServer()->getPlayerExact($enemyName);

                if ($enemy instanceof PracticePlayer) {
                    if ($cooldownManager->hasEnderPearlCooldown($enemy)) {
                        $cooldownManager->removeEnderPearlCooldown($enemy);
                    }

                    $ffaManager->showPlayers($enemy);
                    $ffaManager->removeCombatStatus($enemy);

                    $player->customDeathAnimation($enemy->getLocation());
                    $ffaManager->processKill($player, $enemy);

                    $enemy->sendActionBarMessage($this->plugin->getTranslationManager()->translate($enemy, "ffaCombatReduced"));
                } else {
                    $ffaManager->removeCombatStatusByName($enemyName);
                }

                $ffaManager->showPlayers($player);
                $ffaManager->removeCombatStatus($player);
            }

            $ffaManager->removeFromFFA($player);
        }
    }
}