<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\overall;

use antralia\core\scoreboard\Scoreboard;
use antralia\practice\item\PracticeMushroomStewItem;
use antralia\practice\item\PracticeSplashPotionItem;
use antralia\practice\player\PracticePlayer;
use antralia\practice\PracticePlugin;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockBurnEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\block\BlockUpdateEvent;
use pocketmine\event\block\LeavesDecayEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityExplodeEvent;
use pocketmine\event\inventory\CraftItemEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerBlockPickEvent;
use pocketmine\event\player\PlayerBucketEmptyEvent;
use pocketmine\event\player\PlayerBucketFillEvent;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerDropItemEvent;
use pocketmine\event\player\PlayerExhaustEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\server\DataPacketReceiveEvent;
use pocketmine\event\server\QueryRegenerateEvent;
use pocketmine\network\mcpe\protocol\InteractPacket;
use pocketmine\player\GameMode;

final class PracticeListener implements Listener
{

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @param PlayerQuitEvent $event
     * @return void
     */
    public function handlePlayerQuit(PlayerQuitEvent $event): void
    {
        $player = $event->getPlayer();

        if (Scoreboard::hasScore($player)) {
            Scoreboard::removeScoreFromArray($player);
        }
    }

    /**
     * @param EntityDamageEvent $event
     * @return void
     */
    public function handleEntityDamage(EntityDamageEvent $event): void
    {
        $entity = $event->getEntity();

        if (!($entity instanceof PracticePlayer)) {
            return;
        }

        if ($event instanceof EntityDamageByEntityEvent) {
            $damager = $event->getDamager();
            if (!($damager instanceof PracticePlayer)) {
                return;
            }

            if (!($damager->getGamemode()->equals(GameMode::ADVENTURE()))) {
                $event->cancel();
                return;
            }
        }

        if ($this->plugin->getHubManager()->isInHub($entity)) {
            $this->plugin->getHubManager()->updateScoreTag($entity);
        } elseif ($this->plugin->getFFAManager()->isInFFA($entity)) {
            $this->plugin->getFFAManager()->updateScoreTag($entity);
        } else {
            $entity->setScoreTag("");
        }
    }

    /**
     * @param PlayerInteractEvent $event
     * @return void
     */
    public function handlePlayerInteract(PlayerInteractEvent $event): void
    {
        $player = $event->getPlayer();
        $item = $event->getItem();

        if (!($item instanceof PracticeSplashPotionItem || $item instanceof PracticeMushroomStewItem) || !($player->getGamemode()->equals(GameMode::ADVENTURE()))) {
            $event->cancel();
        }
    }

    /**
     * @param DataPacketReceiveEvent $event
     * @return void
     */
    public function handleDataPacketReceive(DataPacketReceiveEvent $event): void
    {
        $packet = $event->getPacket();
        $player = $event->getOrigin()->getPlayer();

        if ($player !== null) {
            if ($packet instanceof InteractPacket) {
                if ($player->getGamemode()->equals(GameMode::SPECTATOR())) {
                    if ($packet->action === InteractPacket::ACTION_OPEN_INVENTORY) {
                        $event->cancel();
                    }
                }
            }
        }
    }

    /**
     * @param PlayerDropItemEvent $event
     * @return void
     */
    public function handlePlayerDropItem(PlayerDropItemEvent $event): void
    {
        $event->cancel();
    }

    /**
     * @param PlayerDeathEvent $event
     * @return void
     */
    public function handlePlayerDeath(PlayerDeathEvent $event): void
    {
        $event->setDeathMessage("");
    }

    /**
     * @param PlayerExhaustEvent $event
     * @return void
     */
    public function handlePlayerExhaust(PlayerExhaustEvent $event): void
    {
        $event->cancel();
    }

    /**
     * @param PlayerBucketEmptyEvent $event
     * @return void
     */
    public function handlePlayerBucketEmpty(PlayerBucketEmptyEvent $event): void
    {
        $event->cancel();
    }

    /**
     * @param PlayerBucketFillEvent $event
     * @return void
     */
    public function handlePlayerBucketFill(PlayerBucketFillEvent $event): void
    {
        $event->cancel();
    }

    /**
     * @param PlayerBlockPickEvent $event
     * @return void
     */
    public function handlePlayerBlockPick(PlayerBlockPickEvent $event): void
    {
        $event->cancel();
    }

    /**
     * @param EntityExplodeEvent $event
     * @return void
     */
    public function handleEntityExplode(EntityExplodeEvent $event): void
    {
        $event->cancel();
    }

    /**
     * @param BlockBreakEvent $event
     * @return void
     */
    public function handleBlockBreak(BlockBreakEvent $event): void
    {
        $event->cancel();
    }

    /**
     * @param BlockBurnEvent $event
     * @return void
     */
    public function handleBlockBurn(BlockBurnEvent $event): void
    {
        $event->cancel();
    }

    /**
     * @param BlockPlaceEvent $event
     * @return void
     */
    public function handleBlockPlace(BlockPlaceEvent $event): void
    {
        $event->cancel();
    }

    /**
     * @param BlockUpdateEvent $event
     * @return void
     */
    public function handleBlockUpdate(BlockUpdateEvent $event): void
    {
        $event->cancel();
    }

    /**
     * @param CraftItemEvent $event
     * @return void
     */
    public function handleCraftItem(CraftItemEvent $event): void
    {
        $event->cancel();
    }

    /**
     * @param LeavesDecayEvent $event
     * @return void
     */
    public function handleLeavesDecay(LeavesDecayEvent $event): void
    {
        $event->cancel();
    }

    /**
     * @param QueryRegenerateEvent $event
     * @return void
     */
    public function handleQueryRegenerate(QueryRegenerateEvent $event): void
    {
        $query = $event->getQueryInfo();

        $query->setMaxPlayerCount(count($this->plugin->getServer()->getOnlinePlayers()) + 1);
        $query->setServerName("Antralia Network");
        $query->setWorld("antralia.net");
        $query->setPlayerList($this->plugin->getServer()->getOnlinePlayers());
        $query->setListPlugins(false);
        $query->setPlugins([]);
    }
}