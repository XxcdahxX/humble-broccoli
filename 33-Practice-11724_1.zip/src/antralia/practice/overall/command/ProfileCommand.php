<?php

declare(strict_types=1);

namespace antralia\practice\overall\command;

use antralia\core\rcon\RconCommandSender;
use antralia\practice\command\CommandArgs;
use antralia\practice\command\PracticeCommand;
use antralia\practice\player\PracticePlayer;
use antralia\practice\player\rank\RankManager;
use antralia\practice\PracticePlugin;
use antralia\practice\utils\PracticeUtils;
use pocketmine\command\CommandSender;
use pocketmine\network\mcpe\protocol\AvailableCommandsPacket;
use pocketmine\utils\TextFormat;

final class ProfileCommand extends PracticeCommand
{

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;

        $this->setPermission("practice.command.profile");
        $this->commandArg = new CommandArgs();
        $this->commandArg->addParameter(0, "player", AvailableCommandsPacket::ARG_TYPE_TARGET, true);

        parent::__construct("profile", "Check your or another player's profile", "Usage: /profile <player>", ["account"]);
    }

    /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     * @return bool
     */
    public function execute(CommandSender $sender, string $commandLabel, array $args): bool
    {
        if (!($this->testPermission($sender))) {
            return false;
        }

        $provider = $this->plugin->getProvider();
        $punishmentManager = $this->plugin->getPunishmentManager();
        $rankManager = $this->plugin->getRankManager();

        if ($sender instanceof PracticePlayer) {
            $translationManager = $this->plugin->getTranslationManager();
            if (!(isset($args[0]))) {
                $nicknames = implode(", ", $provider->getOtherNicknames($sender->getName()));
                if ($sender->getRank() === RankManager::OWNER_RANK) {
                    $sender->sendMessage(sprintf(
                        $translationManager->translate($sender, "profileSelfOwner"),
                        $sender->getName(),
                        $sender->getRankColored(),
                        $sender->getNetworkSession()->getIp(),
                        $punishmentManager->isMutedFromArray($sender) ? $translationManager->translate($sender, "profileYes") : $translationManager->translate($sender, "profileNo"),
                        $sender->getNetworkSession()->getPing(),
                        $sender->getGameVersion(),
                        $sender->getDeviceOSNameForMessages(),
                        $translationManager->translateInputMode($sender, $sender->getCurrentInputModeName()),
                        $sender->getDeviceModel() === "" ? $translationManager->translate($sender, "profileNo") : $sender->getDeviceModel(),
                        $nicknames === "" ? $translationManager->translate($sender, "profileNo") : $nicknames
                    ));
                } else {
                    $sender->sendMessage(sprintf(
                        $translationManager->translate($sender, "profileSelf"),
                        $sender->getName(),
                        $sender->getRankColored(),
                        $punishmentManager->isMutedFromArray($sender) ? $translationManager->translate($sender, "profileYes") : $translationManager->translate($sender, "profileNo"),
                        $sender->getNetworkSession()->getPing(),
                        $sender->getGameVersion(),
                        $sender->getDeviceOSNameForMessages(),
                        $translationManager->translateInputMode($sender, $sender->getCurrentInputModeName()),
                        $nicknames === "" ? $translationManager->translate($sender, "profileNo") : $nicknames
                    ));
                }
            } else {
                $nickname = PracticeUtils::filterStringForSQL(strtolower($args[0]));
                $player = PracticeUtils::getPlayerByPrefix($nickname);
                if ($player instanceof PracticePlayer) {
                    if ($sender->getRankPriority() <= $player->getRankPriority()) {
                        $sender->sendMessage($translationManager->translate($sender, "profileCannotCheck"));
                        return true;
                    }

                    $nicknames = implode(", ", $provider->getOtherNicknames($player->getName()));

                    if ($sender->getRank() === RankManager::OWNER_RANK) {
                        $sender->sendMessage(sprintf(
                            $translationManager->translate($sender, "profileOnlineOwner"),
                            $player->getName(),
                            $player->getRankColored(),
                            $player->getNetworkSession()->getIp(),
                            $translationManager->translate($sender, "profileYes"),
                            $translationManager->translate($sender, "profileNo"),
                            $punishmentManager->isMutedFromArray($player) ? $translationManager->translate($sender, "profileYes") : $translationManager->translate($sender, "profileNo"),
                            $player->getNetworkSession()->getPing(),
                            $player->getGameVersion(),
                            $player->getDeviceOSNameForMessages(),
                            $translationManager->translateInputMode($sender, $player->getCurrentInputModeName()),
                            $player->getDeviceModel() === "" ? $translationManager->translate($sender, "profileNo") : $player->getDeviceModel(),
                            $nicknames === "" ? $translationManager->translate($sender, "profileNo") : $nicknames
                        ));
                    } else {
                        $sender->sendMessage(sprintf(
                            $translationManager->translate($sender, "profileOnline"),
                            $player->getName(),
                            $player->getRankColored(),
                            $translationManager->translate($sender, "profileYes"),
                            $translationManager->translate($sender, "profileNo"),
                            $punishmentManager->isMutedFromArray($player) ? $translationManager->translate($sender, "profileYes") : $translationManager->translate($sender, "profileNo"),
                            $player->getNetworkSession()->getPing(),
                            $player->getGameVersion(),
                            $player->getDeviceOSNameForMessages(),
                            $translationManager->translateInputMode($sender, $player->getCurrentInputModeName()),
                            $nicknames === "" ? $translationManager->translate($sender, "profileNo") : $nicknames
                        ));
                    }
                } else {
                    if (!($provider->isPlayerRegisteredByNickname($nickname))) {
                        $sender->sendMessage($translationManager->translate($sender, "playerNotRegistered"));
                        return true;
                    }

                    if ($sender->getRankPriority() <= $rankManager->getRankPriorityByNickname($nickname)) {
                        $sender->sendMessage($translationManager->translate($sender, "profileCannotCheck"));
                        return true;
                    }

                    $nicknames = implode(", ", $provider->getOtherNicknames($nickname));

                    if ($sender->getRank() === RankManager::OWNER_RANK) {
                        $sender->sendMessage(sprintf(
                            $translationManager->translate($sender, "profileOfflineOwner"),
                            $nickname,
                            $rankManager->getRankColoredByNickname($nickname),
                            $provider->getPlayerIpByNickname($nickname),
                            $translationManager->translate($sender, "profileNo"),
                            $punishmentManager->isBannedByNickname($nickname) ? $translationManager->translate($sender, "profileYes") : $translationManager->translate($sender, "profileNo"),
                            $punishmentManager->isMutedByNickname($nickname) ? $translationManager->translate($sender, "profileYes") : $translationManager->translate($sender, "profileNo"),
                            $nicknames === "" ? $translationManager->translate($sender, "profileNo") : $nicknames
                        ));
                    } else {
                        $sender->sendMessage(sprintf(
                            $translationManager->translate($sender, "profileOffline"),
                            $nickname,
                            $rankManager->getRankColoredByNickname($nickname),
                            $translationManager->translate($sender, "profileNo"),
                            $punishmentManager->isBannedByNickname($nickname) ? $translationManager->translate($sender, "profileYes") : $translationManager->translate($sender, "profileNo"),
                            $punishmentManager->isMutedByNickname($nickname) ? $translationManager->translate($sender, "profileYes") : $translationManager->translate($sender, "profileNo"),
                            $nicknames === "" ? $translationManager->translate($sender, "profilenNo") : $nicknames
                        ));
                    }
                }
            }
        } else {
            if (!(isset($args[0]))) {
                $sender->sendMessage($this->usageMessage);
                return true;
            }

            $nickname = PracticeUtils::filterStringForSQL(strtolower($args[0]));
            $player = PracticeUtils::getPlayerByPrefix($nickname);

            if ($player instanceof PracticePlayer) {
                $nicknames = implode(", ", $provider->getOtherNicknames($player->getName()));
                if ($sender instanceof RconCommandSender) {
                    if ($player->getRank() === RankManager::OWNER_RANK || $player->getRank() === RankManager::STAFF_RANK) {
                        $sender->sendMessage(TextFormat::RED . "You can't check this player's profile!");
                        return true;
                    }

                    $sender->sendMessage(sprintf(
                        TextFormat::YELLOW . "%s's profile:\nRank: %s\nOnline: %s\nBanned: %s\nMuted: %s\nPing: %sms\nGame version: %s\nOS: %s (%s)\nOther accounts: %s",
                        $player->getName(),
                        $player->getRank(),
                        "yes",
                        "no",
                        $punishmentManager->isMutedFromArray($player) ? "yes" : "no",
                        $player->getNetworkSession()->getPing(),
                        $player->getGameVersion(),
                        $player->getDeviceOSNameForMessages(),
                        $player->getCurrentInputModeName(),
                        $nicknames === "" ? "no" : $nicknames
                    ));
                } else {
                    $sender->sendMessage(sprintf(
                        TextFormat::YELLOW . "%s's profile:\nRank: %s\nIP: %s\nOnline: %s\nBanned: %s\nMuted: %s\nPing: %sms\nGame version: %s\nOS: %s (%s)\nModel: %s\nOther accounts: %s",
                        $player->getName(),
                        $player->getRank(),
                        $player->getNetworkSession()->getIp(),
                        "yes",
                        "no",
                        $punishmentManager->isMutedFromArray($player) ? "yes" : "no",
                        $player->getNetworkSession()->getPing(),
                        $player->getGameVersion(),
                        $player->getDeviceOSNameForMessages(),
                        $player->getCurrentInputModeName(),
                        $player->getDeviceModel() === "" ? "no" : $player->getDeviceModel(),
                        $nicknames === "" ? "no" : $nicknames
                    ));
                }
            } else {
                if (!($provider->isPlayerRegisteredByNickname($nickname))) {
                    $sender->sendMessage(TextFormat::RED . "Player is not registered!");
                    return true;
                }

                $nicknames = implode(", ", $provider->getOtherNicknames($nickname));

                if ($sender instanceof RconCommandSender) {
                    if ($rankManager->getRankByNickname($nickname) === RankManager::OWNER_RANK || $rankManager->getRankByNickname($nickname) === RankManager::STAFF_RANK) {
                        $sender->sendMessage(TextFormat::RED . "You can't check this player's profile!");
                        return true;
                    }

                    $sender->sendMessage(sprintf(
                        TextFormat::YELLOW . "%s's profile:\nRank: %s\nOnline: %s\nBanned: %s\nMuted: %s\nOther accounts: %s",
                        $nickname,
                        $rankManager->getRankByNickname($nickname),
                        "no",
                        $punishmentManager->isBannedByNickname($nickname) ? "yes" : "no",
                        $punishmentManager->isMutedByNickname($nickname) ? "yes" : "no",
                        $nicknames === "" ? "no" : $nicknames
                    ));
                } else {
                    $sender->sendMessage(sprintf(
                        TextFormat::YELLOW . "%s's profile:\nRank: %s\nIP: %s\nOnline: %s\nBanned: %s\nMuted: %s\nOther accounts: %s",
                        $nickname,
                        $rankManager->getRankByNickname($nickname),
                        $provider->getPlayerIpByNickname($nickname),
                        "no",
                        $punishmentManager->isBannedByNickname($nickname) ? "yes" : "no",
                        $punishmentManager->isMutedByNickname($nickname) ? "yes" : "no",
                        $nicknames === "" ? "no" : $nicknames
                    ));
                }
            }
        }
        return true;
    }

    /**
     * @param PracticePlayer $player
     * @return string
     */
    public function getDescriptionForPlayer(PracticePlayer $player): string
    {
        return $this->plugin->getTranslationManager()->translate($player, "profileCommandDescription");
    }
}