<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\overall\command;

use antralia\core\telegram\Telegram;
use antralia\core\vk\VK;
use antralia\practice\command\CommandArgs;
use antralia\practice\command\PracticeCommand;
use antralia\practice\player\PracticePlayer;
use antralia\practice\PracticePlugin;
use pocketmine\command\CommandSender;
use pocketmine\network\mcpe\protocol\AvailableCommandsPacket;
use pocketmine\utils\TextFormat;

final class ClearChatCommand extends PracticeCommand
{

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;

        $this->setPermission("practice.command.clearchat");
        $this->commandArg = new CommandArgs();
        $this->commandArg->addParameter(0, "", AvailableCommandsPacket::ARG_FLAG_VALID | AvailableCommandsPacket::ARG_FLAG_ENUM, false, "", [""]);

        parent::__construct("clearchat", "Clear the chat", "Usage: /clearchat", ["cc"]);
    }

    /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     * @return bool
     */
    public function execute(CommandSender $sender, string $commandLabel, array $args): bool
    {
        if (!($this->testPermission($sender))) {
            return false;
        }

        $translationManager = $this->plugin->getTranslationManager();
        foreach ($this->plugin->getServer()->getOnlinePlayers() as $player) {
            if (!($player->isConnected())) {
                return true;
            }

            if (!($player instanceof PracticePlayer)) {
                return true;
            }

            $times = 0;
            while ($times <= 100) {
                $player->sendMessage("\n");
                $times++;
            }

            $player->sendMessage($translationManager->translate($player, "clearedChat"));

            if ($player->hasPermission("practice.channel.administrative")) {
                $player->sendMessage(sprintf($translationManager->translate($player, "clearedChatNotification"), $sender->getName()));
            }
        }

        if ($sender instanceof PracticePlayer) {
            $sender->sendMessage($translationManager->translate($sender, "clearChatSuccess"));
        } else {
            $sender->sendMessage(TextFormat::GREEN . "You have cleared the chat!");
        }

        $this->plugin->getLogger()->info(sprintf(TextFormat::YELLOW . "%s has cleared the chat", $sender->getName()));
        Telegram::sendMessage(sprintf("[%s] %s has cleared the chat", date("d.m.y"), $sender->getName()));
        VK::sendMessage(sprintf("[%s] %s очистил чат", date("d.m.y"), $sender->getName()));
        return true;
    }

    /**
     * @param PracticePlayer $player
     * @return string
     */
    public function getDescriptionForPlayer(PracticePlayer $player): string
    {
        return $this->plugin->getTranslationManager()->translate($player, "clearChatCommandDescription");
    }
}