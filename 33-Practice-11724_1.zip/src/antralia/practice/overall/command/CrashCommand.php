<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\overall\command;

use antralia\practice\command\CommandArgs;
use antralia\practice\command\PracticeCommand;
use antralia\practice\player\PracticePlayer;
use antralia\practice\player\rank\RankManager;
use antralia\practice\PracticePlugin;
use antralia\practice\utils\PracticeUtils;
use pocketmine\command\CommandSender;
use pocketmine\network\mcpe\protocol\AvailableCommandsPacket;
use pocketmine\utils\TextFormat;

final class CrashCommand extends PracticeCommand
{

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;

        $this->setPermission("practice.command.crash");
        $this->commandArg = new CommandArgs();
        $this->commandArg->addParameter(0, "player", AvailableCommandsPacket::ARG_TYPE_TARGET);
        $key = $this->commandArg->addParameter(0, "crash", AvailableCommandsPacket::ARG_FLAG_ENUM | AvailableCommandsPacket::ARG_TYPE_STRING);
        $this->commandArg->setEnum(0, $key, "crash", ["fast", "slow"]);

        parent::__construct("crash", "Crash player's client", "Usage: /crash <player> <type>");
    }

    /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     * @return bool
     */
    public function execute(CommandSender $sender, string $commandLabel, array $args): bool
    {
        if (!($this->testPermission($sender))) {
            return false;
        }

        if ($sender instanceof PracticePlayer) {
            $translationManager = $this->plugin->getTranslationManager();

            if (empty($args) || !(isset($args[0])) || !(isset($args[1]))) {
                $sender->sendMessage($translationManager->translate($sender, "crashUsage"));
                return true;
            }

            $player = PracticeUtils::getPlayerByPrefix($args[0]);
            if ($player) {
                if (!($player instanceof PracticePlayer)) {
                    return true;
                }

                if ($player->getName() === $sender->getName()) {
                    $sender->sendMessage($translationManager->translate($sender, "crashSelf"));
                    return true;
                }

                if ($sender->getRankPriority() <= $player->getRankPriority()) {
                    $sender->sendMessage($translationManager->translate($sender, "playerCannotBeCrashed"));
                    return true;
                }

                if ($args[1] == "fast") {
                    $sender->sendMessage(sprintf($translationManager->translate($sender, "crashProcessing"), $player->getName()));
                    $this->plugin->getLogger()->info(sprintf(TextFormat::YELLOW . "%s is being crashed by %s", $player->getName(), $sender->getName()));
                    $player->crashClient();
                } elseif ($args[1] == "slow") {
                    $sender->sendMessage(sprintf($translationManager->translate($sender, "crashProcessing"), $player->getName()));
                    $this->plugin->getLogger()->info(sprintf(TextFormat::YELLOW . "%s is being crashed by %s", $player->getName(), $sender->getName()));
                    $player->crashClient(PracticePlayer::CRASH_SLOW_MODE);
                } else {
                    $sender->sendMessage($translationManager->translate($sender, "crashTypeNotFound"));
                    return true;
                }
            } else {
                $sender->sendMessage($translationManager->translate($sender, "playerNotFound"));
            }
        } else {
            if (empty($args) || !(isset($args[0])) || !(isset($args[1]))) {
                $sender->sendMessage($this->usageMessage);
                return true;
            }

            $player = PracticeUtils::getPlayerByPrefix($args[0]);
            if ($player) {
                if (!($player instanceof PracticePlayer)) {
                    return true;
                }

                if ($player->getRank() === RankManager::OWNER_RANK) {
                    $sender->sendMessage(TextFormat::RED . "You can't crash this player!");
                    return true;
                }

                if ($args[1] == "fast") {
                    $sender->sendMessage(sprintf(TextFormat::YELLOW . "Crash is being processed... (%s)", $player->getName()));
                    $this->plugin->getLogger()->info(sprintf(TextFormat::YELLOW . "%s is being crashed by %s", $player->getName(), $sender->getName()));
                    $player->crashClient();
                } elseif ($args[1] == "slow") {
                    $sender->sendMessage(sprintf(TextFormat::YELLOW . "Crash is being processed... (%s)", $player->getName()));
                    $this->plugin->getLogger()->info(sprintf(TextFormat::YELLOW . "%s is being crashed by %s", $player->getName(), $sender->getName()));
                    $player->crashClient(PracticePlayer::CRASH_SLOW_MODE);
                } else {
                    $sender->sendMessage(TextFormat::RED . "Unknown crash type!");
                    return true;
                }
            } else {
                $sender->sendMessage(TextFormat::RED . "Player not found!");
            }
        }
        return true;
    }

    /**
     * @param PracticePlayer $player
     * @return string
     */
    public function getDescriptionForPlayer(PracticePlayer $player): string
    {
        return $this->plugin->getTranslationManager()->translate($player, "crashCommandDescription");
    }
}