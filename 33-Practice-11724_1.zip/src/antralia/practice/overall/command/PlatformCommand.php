<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\overall\command;

use antralia\practice\command\CommandArgs;
use antralia\practice\command\PracticeCommand;
use antralia\practice\player\PracticePlayer;
use antralia\practice\PracticePlugin;
use antralia\practice\utils\PracticeUtils;
use pocketmine\command\CommandSender;
use pocketmine\network\mcpe\protocol\AvailableCommandsPacket;
use pocketmine\utils\TextFormat;

final class PlatformCommand extends PracticeCommand
{

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;

        $this->setPermission("practice.command.platform");
        $this->commandArg = new CommandArgs();
        $this->commandArg->addParameter(0, "player", AvailableCommandsPacket::ARG_TYPE_TARGET, true);

        parent::__construct("platform", "Check your or another player's platform", "Usage: /platform <player>");
    }

    /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     * @return bool
     */
    public function execute(CommandSender $sender, string $commandLabel, array $args): bool
    {
        if (!($this->testPermission($sender))) {
            return false;
        }

        $translationManager = $this->plugin->getTranslationManager();

        if (!(isset($args[0]))) {
            if ($sender instanceof PracticePlayer) {
                $sender->sendMessage(sprintf($translationManager->translate($sender, "platformSelf"), $sender->getDeviceOSNameForMessages(), $translationManager->translateInputMode($sender, $sender->getCurrentInputModeName())));
            } else {
                $sender->sendMessage($this->usageMessage);
            }
        } else {
            $player = PracticeUtils::getPlayerByPrefix($args[0]);

            if ($player) {
                if (!($player instanceof PracticePlayer)) {
                    return false;
                }

                if ($sender instanceof PracticePlayer) {
                    $sender->sendMessage(sprintf($translationManager->translate($sender, "platformAnother"), $player->getName(), $player->getDeviceOSNameForMessages(), $translationManager->translateInputMode($sender, $player->getCurrentInputModeName())));
                } else {
                    $sender->sendMessage(TextFormat::GREEN . $player->getName() . "'s platform: " . $player->getDeviceOSNameForMessages() . " (" . $player->getCurrentInputModeName() . ")");
                }
            } elseif ($sender instanceof PracticePlayer) {
                $sender->sendMessage($translationManager->translate($sender, "playerNotFound"));
            } else {
                $sender->sendMessage(TextFormat::RED . "Player not found!");
            }
        }
        return true;
    }

    /**
     * @param PracticePlayer $player
     * @return string
     */
    public function getDescriptionForPlayer(PracticePlayer $player): string
    {
        return $this->plugin->getTranslationManager()->translate($player, "platformCommandDescription");
    }
}