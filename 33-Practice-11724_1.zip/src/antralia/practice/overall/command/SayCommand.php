<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\overall\command;

use antralia\practice\command\CommandArgs;
use antralia\practice\command\PracticeCommand;
use antralia\practice\player\PracticePlayer;
use antralia\practice\PracticePlugin;
use pocketmine\command\CommandSender;
use pocketmine\utils\TextFormat;

final class SayCommand extends PracticeCommand
{

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;

        $this->setPermission("practice.command.say");
        $this->commandArg = new CommandArgs();
        $this->commandArg->addParameter(0, "message");

        parent::__construct("say", "Broadcast a message", "Usage: /say <message>");
    }

    /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     * @return bool
     */
    public function execute(CommandSender $sender, string $commandLabel, array $args): bool
    {
        if (!($this->testPermission($sender))) {
            return false;
        }

        if (!($this->testConsole($sender))) {
            return false;
        }

        if (!($this->testRcon($sender))) {
            return false;
        }

        if (!(isset($args[0]))) {
            $sender->sendMessage($this->usageMessage);
            return true;
        }

        $this->plugin->getServer()->broadcastMessage(TextFormat::RED . "SERVER: " . TextFormat::YELLOW . implode(" ", $args));
        return true;
    }

    /**
     * @param PracticePlayer $player
     * @return string
     */
    public function getDescriptionForPlayer(PracticePlayer $player): string
    {
        return $this->plugin->getTranslationManager()->translate($player, "sayCommandDescription");
    }
}