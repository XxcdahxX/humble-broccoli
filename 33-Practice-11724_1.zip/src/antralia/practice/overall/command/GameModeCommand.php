<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\overall\command;

use antralia\practice\command\CommandArgs;
use antralia\practice\command\PracticeCommand;
use antralia\practice\player\PracticePlayer;
use antralia\practice\PracticePlugin;
use pocketmine\command\CommandSender;
use pocketmine\network\mcpe\protocol\AvailableCommandsPacket;
use pocketmine\player\GameMode;
use pocketmine\utils\TextFormat;

final class GameModeCommand extends PracticeCommand
{

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;

        $this->setPermission("practice.command.gamemode");
        $this->commandArg = new CommandArgs();
        $key = $this->commandArg->addParameter(0, "gamemode", AvailableCommandsPacket::ARG_FLAG_ENUM | AvailableCommandsPacket::ARG_TYPE_STRING);
        $this->commandArg->setEnum(0, $key, "gamemode", ["survival", "creative", "adventure", "spectator", "0", "1", "2", "3"]);

        parent::__construct("gamemode", "Change your game mode", "Usage: /gamemode <game mode>", ["gm"]);
    }

    /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     * @return bool
     */
    public function execute(CommandSender $sender, string $commandLabel, array $args): bool
    {
        if (!($this->testPermission($sender))) {
            return false;
        }

        if (!($sender instanceof PracticePlayer)) {
            $sender->sendMessage(TextFormat::RED . "Only for players!");
            return true;
        }

        $translationManager = $this->plugin->getTranslationManager();

        if (empty($args) || !(isset($args[0])) || count($args) < 1) {
            $sender->sendMessage($translationManager->translate($sender, "gameModeUsage"));
            return true;
        }

        if ($this->plugin->getFFAManager()->isInCombat($sender)) {
            $sender->sendMessage($translationManager->translate($sender, "noGameModeInCombat"));
            return true;
        }

        if ($this->plugin->getSpectatorManager()->isSpectator($sender)) {
            $sender->sendMessage($translationManager->translate($sender, "noGameModeInSpectator"));
            return true;
        }

        if ($this->plugin->getFFAManager()->hasRespawnDelay($sender)) {
            $sender->sendMessage($translationManager->translate($sender, "noGameModeInRespawnDelay"));
            return true;
        }

        switch ($args[0]) {
            case "survival":
            case "0":
                if ($sender->getGamemode()->equals(GameMode::SURVIVAL())) {
                    $sender->sendMessage($translationManager->translate($sender, "sameGameMode"));
                    return true;
                }
                $sender->setGamemode(GameMode::SURVIVAL());
                $sender->sendMessage($translationManager->translate($sender, "gameModeChangedToSurvival"));
                break;
            case "creative":
            case "1":
                if ($sender->getGamemode()->equals(GameMode::CREATIVE())) {
                    $sender->sendMessage($translationManager->translate($sender, "sameGameMode"));
                    return true;
                }
                $sender->setGamemode(GameMode::CREATIVE());
                $sender->sendMessage($translationManager->translate($sender, "gameModeChangedToCreative"));
                break;
            case "adventure":
            case "2":
                if ($sender->getGamemode()->equals(GameMode::ADVENTURE())) {
                    $sender->sendMessage($translationManager->translate($sender, "sameGameMode"));
                    return true;
                }
                $sender->setGamemode(GameMode::ADVENTURE());
                $sender->sendMessage($translationManager->translate($sender, "gameModeChangedToAdventure"));
                break;
            case "spectator":
            case "3":
                if ($sender->getGamemode()->equals(GameMode::SPECTATOR())) {
                    $sender->sendMessage($translationManager->translate($sender, "sameGameMode"));
                    return true;
                }
                $sender->setGamemode(GameMode::SPECTATOR());
                $sender->sendMessage($translationManager->translate($sender, "gameModeChangedToSpectator"));
                break;
            default:
                $sender->sendMessage($translationManager->translate($sender, "unknownGameMode"));
                return true;
        }
        return true;
    }

    /**
     * @param PracticePlayer $player
     * @return string
     */
    public function getDescriptionForPlayer(PracticePlayer $player): string
    {
        return $this->plugin->getTranslationManager()->translate($player, "gameModeCommandDescription");
    }
}