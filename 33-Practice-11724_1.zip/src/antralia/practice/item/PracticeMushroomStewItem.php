<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\item;

use antralia\practice\player\PracticePlayer;
use pocketmine\item\MushroomStew;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;

final class PracticeMushroomStewItem extends MushroomStew
{

    /**
     * @var int
     */
    public const STEW_HEAL_AMOUNT = 6;

    /**
     * @param PracticePlayer|Player $player
     * @return bool
     */
    public function canStartUsingItem(PracticePlayer|Player $player): bool
    {
        if ($player->getHealth() < $player->getMaxHealth()) {
            $player->setHealth($player->getHealth() + self::STEW_HEAL_AMOUNT);
            $player->getInventory()->setItemInHand(VanillaItems::AIR());
        }
        return false;
    }
}