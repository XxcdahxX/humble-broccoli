<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\item;

use antralia\practice\entity\PracticeEnderPearlEntity;
use antralia\practice\player\PracticePlayer;
use pocketmine\entity\Location;
use pocketmine\item\EnderPearl;
use pocketmine\player\Player;
use pocketmine\entity\projectile\Throwable;

final class PracticeEnderPearlItem extends EnderPearl
{

    /**
     * @return float
     */
    public function getThrowForce(): float
    {
        return 2.3;
    }

    /**
     * @param Location $location
     * @param PracticePlayer|Player $thrower
     * @return Throwable
     */
    protected function createEntity(Location $location, PracticePlayer|Player $thrower): Throwable
    {
        $enderPearl = new PracticeEnderPearlEntity($location, $thrower);
        $enderPearl->setScale(0.4);
        return $enderPearl;
    }
}