<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\item;

use antralia\practice\entity\PracticeSplashPotionEntity;
use pocketmine\entity\Location;
use pocketmine\entity\projectile\Throwable;
use pocketmine\item\ItemIdentifier;
use pocketmine\item\PotionType;
use pocketmine\item\SplashPotion;
use pocketmine\player\Player;

final class PracticeSplashPotionItem extends SplashPotion
{

    /**
     * @var PotionType
     */
    private PotionType $potionType;

    /**
     * @param ItemIdentifier $identifier
     * @param string $name
     * @param PotionType $potionType
     */
    public function __construct(ItemIdentifier $identifier, string $name, PotionType $potionType)
    {
        parent::__construct($identifier, $name, $potionType);
        $this->potionType = $potionType;
    }

    /**
     * @return float
     */
    public function getThrowForce(): float
    {
        return 0.5;
    }

    /**
     * @return PotionType
     */
    public function getPotionType(): PotionType
    {
        return $this->potionType;
    }

    /**
     * @param Location $location
     * @param Player $thrower
     * @return Throwable
     */
    protected function createEntity(Location $location, Player $thrower): Throwable
    {
        return new PracticeSplashPotionEntity($location, $thrower, $this->getPotionType());
    }
}