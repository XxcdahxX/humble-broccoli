<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\world\generator;

use pocketmine\world\ChunkManager;
use pocketmine\world\generator\Generator;

final class VoidGenerator extends Generator
{

    /**
     * @param ChunkManager $world
     * @param int $chunkX
     * @param int $chunkZ
     * @return void
     */
    public function generateChunk(ChunkManager $world, int $chunkX, int $chunkZ): void
    {
    }

    /**
     * @param ChunkManager $world
     * @param int $chunkX
     * @param int $chunkZ
     * @return void
     */
    public function populateChunk(ChunkManager $world, int $chunkX, int $chunkZ): void
    {
    }
}