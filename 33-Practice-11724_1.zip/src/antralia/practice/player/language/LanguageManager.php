<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\player\language;

use antralia\core\form\ModalForm;
use antralia\core\form\SimpleForm;
use antralia\practice\player\PracticePlayer;
use antralia\practice\PracticePlugin;

final class LanguageManager
{

    /**
     * @var string[]
     */
    public const LANGUAGES = [
        "en",
        "ru"
    ];

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @var array
     */
    private array $languages = array();

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @param PracticePlayer $player
     * @return string
     */
    public function getLanguageFromDatabase(PracticePlayer $player): string
    {
        $query = $this->plugin->getProvider()->getDatabase()->prepare("SELECT `locale` FROM `server_data` WHERE `xuid` = :xuid;");
        $query->bindValue(":xuid", $player->getXuid());
        $result = $query->execute()->fetchArray(SQLITE3_ASSOC);

        if (!($result)) {
            return match ($player->getLocale()) {
                "ru_RU" => "ru",
                default => "en"
            };
        } else {
            return $result["locale"];
        }
    }

    /**
     * @param PracticePlayer $player
     * @return string
     */
    public function getLanguage(PracticePlayer $player): string
    {
        return $this->languages[$player->getName()] ?? $this->getLanguageFromDatabase($player);
    }

    /**
     * @param string $xuid
     * @return string
     */
    public function getLanguageByXuid(string $xuid): string
    {
        $query = $this->plugin->getProvider()->getDatabase()->prepare("SELECT `locale` FROM `server_data` WHERE `xuid` = :xuid;");
        $query->bindValue(":xuid", $xuid);
        $result = $query->execute()->fetchArray(SQLITE3_ASSOC);

        return !($result) ? "none" : $result["locale"];
    }

    /**
     * @param PracticePlayer $player
     * @param string $language
     * @return void
     */
    public function setLanguage(PracticePlayer $player, string $language): void
    {
        if (!(in_array($language, self::LANGUAGES))) {
            $this->plugin->getLogger()->alert("Undefined language: " . $language);
            return;
        }

        $this->languages[$player->getName()] = $language;

        $query = $this->plugin->getProvider()->getDatabase()->prepare("UPDATE `server_data` SET `locale` = :locale WHERE `xuid` = :xuid;");
        $query->bindValue(":locale", $language);
        $query->bindValue(":xuid", $player->getXuid());
        $query->execute();
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function removeLanguage(PracticePlayer $player): void
    {
        if (isset($this->languages[$player->getName()])) {
            unset($this->languages[$player->getName()]);
        }
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function sendLanguageForm(PracticePlayer $player): void
    {
        $form = new SimpleForm(function (PracticePlayer $player, int $data = null): void {
            if ($data === null) {
                return;
            }

            $translationManager = $this->plugin->getTranslationManager();

            $language = "";
            switch ($data) {
                case 0:
                    $language = "en";
                    break;
                case 1:
                    $language = "ru";
                    break;
                case 2:
                    $this->plugin->getHubManager()->sendPreferencesForm($player);
                    return;
            }

            if ($language !== "") {
                if ($this->getLanguageFromDatabase($player) === $language) {
                    $player->sendMessage($translationManager->translate($player, "languageAlreadySelected"));
                } else {
                    $this->sendConfirmationForm($player, $language);
                }
            }
        });

        $formContents = $this->plugin->getTranslationManager()->translate($player, "languageForm");

        $form->setTitle($formContents[0]);

        $form->addButton($formContents[1], SimpleForm::IMAGE_TYPE_PATH, "textures/antralia/flags/english_flag");
        $form->addButton($formContents[2], SimpleForm::IMAGE_TYPE_PATH, "textures/antralia/flags/russian_flag");
        $form->addButton($formContents[3], SimpleForm::IMAGE_TYPE_PATH, "textures/ui/arrow_left");

        $player->sendForm($form);
    }

    /**
     * @param PracticePlayer $player
     * @param string $language
     * @return void
     */
    public function sendConfirmationForm(PracticePlayer $player, string $language): void
    {
        $form = new ModalForm(function (PracticePlayer $player, bool $data = null) use ($language): void {
            if ($data === null) {
                return;
            }

            $translationManager = $this->plugin->getTranslationManager();

            if ($data === true) {
                $this->setLanguage($player, $language);
                $player->sendMessage($translationManager->translate($player, "languageSuccessfullySelected"));

                $event = new PlayerLanguageChangeEvent($player);
                $event->call();
            } else {
                $this->sendLanguageForm($player);
            }
        });

        $translationManager = $this->plugin->getTranslationManager();
        $formContents = $translationManager->translate($player, "languageConfirmationForm");

        $form->setTitle($formContents[0]);

        $form->setContent(sprintf($formContents[1], $translationManager->translateLanguage($player, $language)));

        $form->setFirstButton($formContents[2]);
        $form->setSecondButton($formContents[3]);

        $player->sendForm($form);
    }
}