<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\player\rules;

use antralia\core\form\SimpleForm;
use antralia\practice\player\PracticePlayer;
use antralia\practice\PracticePlugin;

final class RulesManager
{

    /**
     * @var int
     */
    public const NO_BACK_BUTTON_MODE = 0;

    /**
     * @var int
     */
    public const BACK_BUTTON_MODE = 1;

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @param PracticePlayer $player
     * @param int $mode
     * @return void
     */
    public function sendRulesForm(PracticePlayer $player, int $mode = self::NO_BACK_BUTTON_MODE): void
    {
        $form = new SimpleForm(function (PracticePlayer $player, int $data = null) use ($mode): void {
            if ($mode === self::BACK_BUTTON_MODE) {
                if ($data === null) {
                    return;
                }

                if ($data === 0) {
                    $this->plugin->getHubManager()->sendMenuForm($player);
                }
            }
        });

        $formContents = $this->plugin->getTranslationManager()->translate($player, "rulesForm");

        $form->setTitle($formContents[0]);

        $form->setContent($formContents[1]);

        if ($mode === self::BACK_BUTTON_MODE) {
            $form->addButton($formContents[2], SimpleForm::IMAGE_TYPE_PATH, "textures/ui/arrow_left");
        }

        $player->sendForm($form);
    }
}