<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\player\rank;

use antralia\practice\player\PracticePlayer;
use antralia\practice\PracticePlugin;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;

final class RankListener implements Listener
{

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @priority LOWEST
     *
     * @param PlayerJoinEvent $event
     * @return void
     */
    public function handlePlayerJoin(PlayerJoinEvent $event): void
    {
        $player = $event->getPlayer();

        if (!($player instanceof PracticePlayer)) {
            return;
        }

        $rankManager = $this->plugin->getRankManager();
        $rank = $rankManager->getRankByXuid($player);

        $rankManager->setRankToArray($player, $rank);
        foreach ($rankManager->getRankPermissions($rank) as $permission) {
            $player->setBasePermission($permission, true);
        }
    }

    /**
     * @priority LOWEST
     *
     * @param PlayerRankChangeEvent $event
     * @return void
     */
    public function handlePlayerRankChange(PlayerRankChangeEvent $event): void
    {
        $player = $event->getPlayer();
        $rankManager = $this->plugin->getRankManager();

        foreach ($rankManager->getRankPermissions($event->getOldRank()) as $permission) {
            $player->unsetBasePermission($permission);
        }

        foreach ($rankManager->getRankPermissions($event->getNewRank()) as $permission) {
            $player->setBasePermission($permission, true);
        }
    }

    /**
     * @param PlayerQuitEvent $event
     * @return void
     */
    public function handlePlayerQuit(PlayerQuitEvent $event): void
    {
        $player = $event->getPlayer();

        if (!($player instanceof PracticePlayer)) {
            return;
        }

        $this->plugin->getRankManager()->removeRankFromArray($player);
    }
}