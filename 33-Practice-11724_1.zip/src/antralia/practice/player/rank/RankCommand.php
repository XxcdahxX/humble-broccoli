<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\player\rank;

use antralia\core\rcon\RconCommandSender;
use antralia\core\telegram\Telegram;
use antralia\practice\command\CommandArgs;
use antralia\practice\command\PracticeCommand;
use antralia\practice\player\PracticePlayer;
use antralia\practice\PracticePlugin;
use antralia\practice\utils\PracticeUtils;
use pocketmine\command\CommandSender;
use pocketmine\network\mcpe\protocol\AvailableCommandsPacket;
use pocketmine\utils\TextFormat;

final class RankCommand extends PracticeCommand
{

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;

        $this->setPermission("practice.command.rank");
        $this->commandArg = new CommandArgs();
        $this->commandArg->addParameter(0, "player", AvailableCommandsPacket::ARG_TYPE_TARGET);
        $key = $this->commandArg->addParameter(0, "rank", AvailableCommandsPacket::ARG_FLAG_ENUM | AvailableCommandsPacket::ARG_TYPE_STRING);
        $this->commandArg->setEnum(0, $key, "rank", ["player", "mystery", "gangster", "immortal", "snowman", "booster", "famous", "moderator", "admin", "builder", "staff", "owner"]);

        parent::__construct("rank", "Change player's rank", "Usage: /rank <player> <rank>");
    }

    /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     * @return bool
     */
    public function execute(CommandSender $sender, string $commandLabel, array $args): bool
    {
        if (!($this->testPermission($sender))) {
            return false;
        }

        if ($sender instanceof PracticePlayer) {
            $translationManager = $this->plugin->getTranslationManager();

            if (empty($args) || !(isset($args[0])) || !(isset($args[1])) || count($args) < 2) {
                $sender->sendMessage($translationManager->translate($sender, "rankUsage"));
                return true;
            }

            $rankManager = $this->plugin->getRankManager();
            $provider = $this->plugin->getProvider();

            $player = $this->plugin->getServer()->getPlayerExact($args[0]);
            $nickname = PracticeUtils::filterStringForSQL(strtolower($args[0]));
            $rank = match (strtolower($args[1])) {
                "player", "default" => RankManager::PLAYER_RANK,
                "mystery" => RankManager::MYSTERY_RANK,
                "gangster" => RankManager::GANGSTER_RANK,
                "immortal" => RankManager::IMMORTAL_RANK,
                "snowman" => RankManager::SNOWMAN_RANK,
                "booster" => RankManager::BOOSTER_RANK,
                "famous" => RankManager::FAMOUS_RANK,
                "moderator" => RankManager::MODERATOR_RANK,
                "admin" => RankManager::ADMIN_RANK,
                "builder" => RankManager::BUILDER_RANK,
                "staff" => RankManager::STAFF_RANK,
                "owner" => RankManager::OWNER_RANK,
                default => "Unknown"
            };

            if (!(in_array($rank, RankManager::RANKS, true))) {
                $sender->sendMessage($translationManager->translate($sender, "rankNotFound"));
                return true;
            }

            if ($player) {
                if (!($player instanceof PracticePlayer)) {
                    return false;
                }

                if (!($provider->isPlayerRegisteredByXuid($player))) {
                    $sender->sendMessage($translationManager->translate($sender, "playerNotRegistered"));
                    return true;
                } else {
                    if ($sender->getName() === $player->getName()) {
                        $sender->sendMessage($translationManager->translate($sender, "rankSelf"));
                        return true;
                    }

                    if ($sender->getRankPriority() <= $player->getRankPriority()) {
                        $sender->sendMessage($translationManager->translate($sender, "rankCannotBeChanged"));
                        return true;
                    }

                    if ($sender->getRankPriority() <= $rankManager->getRankPriorityByRank($rank)) {
                        $sender->sendMessage($translationManager->translate($sender, "rankCannotBeSet"));
                        return true;
                    }

                    if ($player->getRank() === $rank) {
                        $sender->sendMessage($translationManager->translate($sender, "rankAlreadySet"));
                        return true;
                    }

                    $rankManager->setRankByXuid($player, $rank);
                    $sender->sendMessage(sprintf($translationManager->translate($sender, "rankChanged"), $player->getName(), $rank));
                    $player->sendMessage(sprintf($translationManager->translate($player, "rankChangedAnother"), $rank));
                    $this->plugin->getLogger()->info(sprintf(TextFormat::YELLOW . "%s had set %s's rank to %s", $sender->getName(), $player->getName(), $rank));
                    foreach ($this->plugin->getServer()->getOnlinePlayers() as $onlinePlayer) {
                        if (!($onlinePlayer instanceof PracticePlayer)) {
                            continue;
                        }

                        if (!($onlinePlayer->isConnected())) {
                            continue;
                        }

                        if ($onlinePlayer->hasPermission("practice.channel.owners")) {
                            $onlinePlayer->sendMessage(sprintf($translationManager->translate($onlinePlayer, "playerRankChangedNotification"), $sender->getName(), $player->getName(), $rank));
                        }
                    }
                    Telegram::sendMessage(sprintf("[%s] %s had set %s's rank to %s", date("d.m.y"), $sender->getName(), $player->getName(), $rank));
                }
            } elseif (!($provider->isPlayerRegisteredByNickname($nickname))) {
                $sender->sendMessage($translationManager->translate($sender, "playerNotRegistered"));
                return true;
            } else {
                if ($sender->getRankPriority() <= $rankManager->getRankPriorityByNickname($nickname)) {
                    $sender->sendMessage($translationManager->translate($sender, "rankCannotBeChanged"));
                    return true;
                }

                if ($sender->getRankPriority() <= $rankManager->getRankPriorityByRank($rank)) {
                    $sender->sendMessage($translationManager->translate($sender, "rankCannotBeSet"));
                    return true;
                }

                if ($rankManager->getRankByNickname($nickname) === $rank) {
                    $sender->sendMessage($translationManager->translate($sender, "rankAlreadySet"));
                    return true;
                }

                $rankManager->setRankByNickname($nickname, $rank);
                $sender->sendMessage(sprintf($translationManager->translate($sender, "rankChanged"), $nickname, $rank));
                $this->plugin->getLogger()->info(sprintf(TextFormat::YELLOW . "%s had set %s's rank to %s", $sender->getName(), $nickname, $rank));
                foreach ($this->plugin->getServer()->getOnlinePlayers() as $onlinePlayer) {
                    if (!($onlinePlayer instanceof PracticePlayer)) {
                        continue;
                    }

                    if (!($onlinePlayer->isConnected())) {
                        continue;
                    }

                    if ($onlinePlayer->hasPermission("practice.channel.owners")) {
                        $onlinePlayer->sendMessage(sprintf($translationManager->translate($onlinePlayer, "playerRankChangedNotification"), $sender->getName(), $nickname, $rank));
                    }
                }
                Telegram::sendMessage(sprintf("[%s] %s had set %s's rank to %s", date("d.m.y"), $sender->getName(), $nickname, $rank));
            }
        } else {
            if (empty($args) || !(isset($args[0])) || !(isset($args[1])) || count($args) > 3) {
                $sender->sendMessage($this->usageMessage);
                return true;
            }

            $rankManager = $this->plugin->getRankManager();
            $provider = $this->plugin->getProvider();

            $player = $this->plugin->getServer()->getPlayerExact($args[0]);
            $nickname = PracticeUtils::filterStringForSQL(strtolower($args[0]));
            $rank = match (strtolower($args[1])) {
                "player", "default" => RankManager::PLAYER_RANK,
                "mystery" => RankManager::MYSTERY_RANK,
                "gangster" => RankManager::GANGSTER_RANK,
                "immortal" => RankManager::IMMORTAL_RANK,
                "snowman" => RankManager::SNOWMAN_RANK,
                "booster" => RankManager::BOOSTER_RANK,
                "famous" => RankManager::FAMOUS_RANK,
                "moderator" => RankManager::MODERATOR_RANK,
                "admin" => RankManager::ADMIN_RANK,
                "builder" => RankManager::BUILDER_RANK,
                "staff" => RankManager::STAFF_RANK,
                "owner" => RankManager::OWNER_RANK,
                default => "Unknown"
            };

            if (!(in_array($rank, RankManager::RANKS, true))) {
                $sender->sendMessage(TextFormat::RED . "Rank not found!");
                return true;
            }

            if ($player) {
                if (!($player instanceof PracticePlayer)) {
                    return false;
                }

                if (!($provider->isPlayerRegisteredByXuid($player))) {
                    $sender->sendMessage(TextFormat::RED . "Player is not registered!");
                    return true;
                } else {
                    if ($sender instanceof RconCommandSender) {
                        if ($player->getRank() === RankManager::OWNER_RANK || $player->getRank() === RankManager::STAFF_RANK) {
                            $sender->sendMessage(TextFormat::RED . "You can't change this player's rank!");
                            return true;
                        }

                        if ($rank === RankManager::OWNER_RANK || $rank === RankManager::STAFF_RANK) {
                            $sender->sendMessage(TextFormat::RED . "You can't set this rank!");
                            return true;
                        }

                        if (isset($args[2])) {
                            if (strtolower($args[2]) === "store") {
                                if ($rankManager->getRankPriorityByRank($rank) <= $player->getRankPriority()) {
                                    $sender->sendMessage(TextFormat::RED . "You can't change player's rank to this!");
                                    return true;
                                }
                            }
                        }
                    }

                    if ($player->getRank() === $rank) {
                        $sender->sendMessage(TextFormat::RED . "Player already have this rank!");
                        return true;
                    }

                    $rankManager->setRankByXuid($player, $rank);
                    $sender->sendMessage(TextFormat::GREEN . $player->getName() . "'s rank has been changed to " . $rank);
                    $player->sendMessage(sprintf($this->plugin->getTranslationManager()->translate($player, "rankChangedAnother"), $rank));
                    $this->plugin->getLogger()->info(sprintf(TextFormat::YELLOW . "%s had set %s's rank to %s", $sender->getName(), $player->getName(), $rank));
                    foreach ($this->plugin->getServer()->getOnlinePlayers() as $onlinePlayer) {
                        if (!($onlinePlayer instanceof PracticePlayer)) {
                            continue;
                        }

                        if (!($onlinePlayer->isConnected())) {
                            continue;
                        }

                        if ($onlinePlayer->hasPermission("practice.channel.owners")) {
                            $onlinePlayer->sendMessage(sprintf($this->plugin->getTranslationManager()->translate($onlinePlayer, "playerRankChangedNotification"), $sender->getName(), $player->getName(), $rank));
                        }
                    }
                    Telegram::sendMessage(sprintf("[%s] %s had set %s's rank to %s", date("d.m.y"), $sender->getName(), $player->getName(), $rank));
                }
            } elseif (!($provider->isPlayerRegisteredByNickname($nickname))) {
                $sender->sendMessage(TextFormat::RED . "Player is not registered!");
                return true;
            } else {
                if ($sender instanceof RconCommandSender) {
                    if ($rankManager->getRankByNickname($nickname) === RankManager::OWNER_RANK || $rankManager->getRankByNickname($nickname) === RankManager::STAFF_RANK) {
                        $sender->sendMessage(TextFormat::RED . "You can't change this player's rank!");
                        return true;
                    }

                    if ($rank === RankManager::OWNER_RANK || $rank === RankManager::STAFF_RANK) {
                        $sender->sendMessage(TextFormat::RED . "You can't set this rank!");
                        return true;
                    }

                    if (isset($args[2])) {
                        if (strtolower($args[2]) === "store") {
                            if ($rankManager->getRankPriorityByRank($rank) <= $rankManager->getRankPriorityByNickname($nickname)) {
                                $sender->sendMessage(TextFormat::RED . "You can't change player's rank to this!");
                                return true;
                            }
                        }
                    }
                }

                if ($rankManager->getRankByNickname($nickname) === $rank) {
                    $sender->sendMessage(TextFormat::RED . "Player already have this rank!");
                    return true;
                }

                $rankManager->setRankByNickname($nickname, $rank);
                $sender->sendMessage(TextFormat::GREEN . $nickname . "'s rank has been changed to " . $rank);
                $this->plugin->getLogger()->info(sprintf(TextFormat::YELLOW . "%s had set %s's rank to %s", $sender->getName(), $nickname, $rank));
                foreach ($this->plugin->getServer()->getOnlinePlayers() as $onlinePlayer) {
                    if (!($onlinePlayer instanceof PracticePlayer)) {
                        continue;
                    }

                    if (!($onlinePlayer->isConnected())) {
                        continue;
                    }

                    if ($onlinePlayer->hasPermission("practice.channel.owners")) {
                        $onlinePlayer->sendMessage(sprintf($this->plugin->getTranslationManager()->translate($onlinePlayer, "playerRankChangedNotification"), $sender->getName(), $nickname, $rank));
                    }
                }
                Telegram::sendMessage(sprintf("[%s] %s had set %s's rank to %s", date("d.m.y"), $sender->getName(), $nickname, $rank));
            }
        }
        return true;
    }

    /**
     * @param PracticePlayer $player
     * @return string
     */
    public function getDescriptionForPlayer(PracticePlayer $player): string
    {
        return $this->plugin->getTranslationManager()->translate($player, "rankCommandDescription");
    }
}