<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\player\rank;

use antralia\practice\player\PracticePlayer;
use antralia\practice\PracticePlugin;

final class RankManager
{

    /**
     * @var string[]
     */
    public const RANKS = [
        self::PLAYER_RANK,
        self::MYSTERY_RANK,
        self::GANGSTER_RANK,
        self::IMMORTAL_RANK,
        self::SNOWMAN_RANK,
        self::BOOSTER_RANK,
        self::FAMOUS_RANK,
        self::MODERATOR_RANK,
        self::ADMIN_RANK,
        self::BUILDER_RANK,
        self::STAFF_RANK,
        self::OWNER_RANK
    ];

    /**
     * @var string
     */
    public const DEFAULT_RANK = "Player";

    /**
     * @var string
     */
    public const PLAYER_RANK = self::DEFAULT_RANK;

    /**
     * @var string
     */
    public const MYSTERY_RANK = "Mystery";

    /**
     * @var string
     */
    public const GANGSTER_RANK = "Gangster";

    /**
     * @var string
     */
    public const IMMORTAL_RANK = "Immortal";

    /**
     * @var string
     */
    public const SNOWMAN_RANK = "Snowman";

    /**
     * @var string
     */
    public const BOOSTER_RANK = "Booster";

    /**
     * @var string
     */
    public const FAMOUS_RANK = "Famous";

    /**
     * @var string
     */
    public const MODERATOR_RANK = "Moderator";

    /**
     * @var string
     */
    public const ADMIN_RANK = "Admin";

    /**
     * @var string
     */
    public const BUILDER_RANK = "Builder";

    /**
     * @var string
     */
    public const STAFF_RANK = "Staff";

    /**
     * @var string
     */
    public const OWNER_RANK = "Owner";

    /**
     * @var string[]
     */
    public const DEFAULT_PERMISSIONS = [
        "practice.command.emoji",
        "practice.command.info",
        "practice.command.list",
        "practice.command.ping",
        "practice.command.platform",
        "practice.command.reconnect",
        "practice.command.rekit",
        "practice.command.reply",
        "practice.command.report",
        "practice.command.rules",
        "practice.command.spawn",
        "practice.command.surrender",
        "practice.command.tell"
    ];

    /**
     * @var string[]
     */
    public const PLAYER_PERMISSIONS = [
        "practice.command.emoji",
        "practice.command.info",
        "practice.command.list",
        "practice.command.ping",
        "practice.command.platform",
        "practice.command.reconnect",
        "practice.command.rekit",
        "practice.command.reply",
        "practice.command.report",
        "practice.command.rules",
        "practice.command.spawn",
        "practice.command.surrender",
        "practice.command.tell"
    ];

    /**
     * @var string[]
     */
    public const MYSTERY_PERMISSIONS = [
        "practice.command.emoji",
        "practice.command.info",
        "practice.command.list",
        "practice.command.ping",
        "practice.command.platform",
        "practice.command.reconnect",
        "practice.command.rekit",
        "practice.command.reply",
        "practice.command.report",
        "practice.command.rules",
        "practice.command.spawn",
        "practice.command.surrender",
        "practice.command.tell",
        "practice.cosmetics.default",
        "practice.cosmetics.tags.silver"
    ];

    /**
     * @var string[]
     */
    public const GANGSTER_PERMISSIONS = [
        "practice.command.emoji",
        "practice.command.info",
        "practice.command.list",
        "practice.command.ping",
        "practice.command.platform",
        "practice.command.reconnect",
        "practice.command.rekit",
        "practice.command.reply",
        "practice.command.report",
        "practice.command.rules",
        "practice.command.spawn",
        "practice.command.surrender",
        "practice.command.tell",
        "practice.cosmetics.default",
        "practice.cosmetics.capes",
        "practice.cosmetics.tags.silver",
        "practice.cosmetics.tags.golden",
        "practice.cosmetics.fly"
    ];

    /**
     * @var string[]
     */
    public const IMMORTAL_PERMISSIONS = [
        "practice.command.emoji",
        "practice.command.info",
        "practice.command.list",
        "practice.command.ping",
        "practice.command.platform",
        "practice.command.reconnect",
        "practice.command.rekit",
        "practice.command.reply",
        "practice.command.report",
        "practice.command.rules",
        "practice.command.spawn",
        "practice.command.surrender",
        "practice.command.tell",
        "practice.cosmetics.default",
        "practice.cosmetics.capes",
        "practice.cosmetics.tags.silver",
        "practice.cosmetics.tags.golden",
        "practice.cosmetics.tags.platinum",
        "practice.cosmetics.fly",
        "practice.cosmetics.potioncolor"
    ];

    /**
     * @var string[]
     */
    public const SNOWMAN_PERMISSIONS = self::IMMORTAL_PERMISSIONS;

    /**
     * @var string[]
     */
    public const BOOSTER_PERMISSIONS = self::IMMORTAL_PERMISSIONS;

    /**
     * @var string[]
     */
    public const FAMOUS_PERMISSIONS = self::IMMORTAL_PERMISSIONS;

    /**
     * @var string[]
     */
    public const MODERATOR_PERMISSIONS = [
        "practice.channel.administrative",
        "practice.command.ban",
        "practice.command.clearchat",
        "practice.command.emoji",
        "practice.command.info",
        "practice.command.kick",
        "practice.command.list",
        "practice.command.mute",
        "practice.command.ping",
        "practice.command.platform",
        "practice.command.reconnect",
        "practice.command.rekit",
        "practice.command.reply",
        "practice.command.report",
        "practice.command.rules",
        "practice.command.spawn",
        "practice.command.spectate",
        "practice.command.surrender",
        "practice.command.tell",
        "practice.cosmetics.default",
        "practice.cosmetics.capes",
        "practice.cosmetics.tags.silver",
        "practice.cosmetics.tags.golden",
        "practice.cosmetics.tags.platinum",
        "practice.cosmetics.fly",
        "practice.cosmetics.potioncolor"
    ];

    /**
     * @var string[]
     */
    public const ADMIN_PERMISSIONS = [
        "practice.channel.administrative",
        "practice.command.ban",
        "practice.command.clearchat",
        "practice.command.emoji",
        "practice.command.info",
        "practice.command.kick",
        "practice.command.list",
        "practice.command.mute",
        "practice.command.ping",
        "practice.command.platform",
        "practice.command.reconnect",
        "practice.command.rekit",
        "practice.command.reply",
        "practice.command.report",
        "practice.command.rules",
        "practice.command.spawn",
        "practice.command.spectate",
        "practice.command.surrender",
        "practice.command.tell",
        "practice.command.unban",
        "practice.command.unmute",
        "practice.cosmetics.default",
        "practice.cosmetics.capes",
        "practice.cosmetics.tags.silver",
        "practice.cosmetics.tags.golden",
        "practice.cosmetics.tags.platinum",
        "practice.cosmetics.fly",
        "practice.cosmetics.potioncolor"
    ];

    /**
     * @var string[]
     */
    public const BUILDER_PERMISSIONS = [
        "practice.channel.administrative",
        "practice.command.ban",
        "practice.command.clearchat",
        "practice.command.emoji",
        "practice.command.gamemode",
        "practice.command.info",
        "practice.command.kick",
        "practice.command.list",
        "practice.command.mute",
        "practice.command.ping",
        "practice.command.platform",
        "practice.command.reconnect",
        "practice.command.rekit",
        "practice.command.reply",
        "practice.command.report",
        "practice.command.rules",
        "practice.command.spawn",
        "practice.command.spectate",
        "practice.command.surrender",
        "practice.command.tell",
        "practice.command.unban",
        "practice.command.unmute",
        "practice.cosmetics.default",
        "practice.cosmetics.capes",
        "practice.cosmetics.tags.silver",
        "practice.cosmetics.tags.golden",
        "practice.cosmetics.tags.platinum",
        "practice.cosmetics.fly",
        "practice.cosmetics.potioncolor"
    ];

    /**
     * @var string[]
     */
    public const STAFF_PERMISSIONS = [
        "practice.channel.administrative",
        "practice.command.ban",
        "practice.command.clearchat",
        "practice.command.emoji",
        "practice.command.gamemode",
        "practice.command.info",
        "practice.command.kick",
        "practice.command.list",
        "practice.command.mute",
        "practice.command.ping",
        "practice.command.platform",
        "practice.command.profile",
        "practice.command.rank",
        "practice.command.reconnect",
        "practice.command.rekit",
        "practice.command.reply",
        "practice.command.report",
        "practice.command.rules",
        "practice.command.spawn",
        "practice.command.spectate",
        "practice.command.surrender",
        "practice.command.tell",
        "practice.command.unban",
        "practice.command.unmute",
        "practice.cosmetics.default",
        "practice.cosmetics.capes",
        "practice.cosmetics.tags.silver",
        "practice.cosmetics.tags.golden",
        "practice.cosmetics.tags.platinum",
        "practice.cosmetics.fly",
        "practice.cosmetics.potioncolor"
    ];

    /**
     * @var string[]
     */
    public const OWNER_PERMISSIONS = [
        "pocketmine.command.teleport",
        "practice.channel.administrative",
        "practice.channel.owners",
        "practice.command.ban",
        "practice.command.clearchat",
        "practice.command.crash",
        "practice.command.emoji",
        "practice.command.gamemode",
        "practice.command.info",
        "practice.command.kick",
        "practice.command.list",
        "practice.command.mute",
        "practice.command.ping",
        "practice.command.platform",
        "practice.command.profile",
        "practice.command.rank",
        "practice.command.reconnect",
        "practice.command.rekit",
        "practice.command.reply",
        "practice.command.report",
        "practice.command.restart",
        "practice.command.rules",
        "practice.command.say",
        "practice.command.spawn",
        "practice.command.spectate",
        "practice.command.status",
        "practice.command.surrender",
        "practice.command.tell",
        "practice.command.unban",
        "practice.command.unmute",
        "practice.cosmetics.default",
        "practice.cosmetics.capes",
        "practice.cosmetics.tags.silver",
        "practice.cosmetics.tags.golden",
        "practice.cosmetics.tags.platinum",
        "practice.cosmetics.fly",
        "practice.cosmetics.potioncolor"
    ];

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @var array<string, string>
     */
    private array $ranks = [];

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @param string $rank
     * @return string[]
     */
    public function getRankPermissions(string $rank): array
    {
        if (!(in_array($rank, self::RANKS, true))) {
            $this->plugin->getLogger()->alert("Undefined rank: " . $rank);
            return array();
        }

        return match ($rank) {
            self::PLAYER_RANK => self::PLAYER_PERMISSIONS,
            self::MYSTERY_RANK => self::MYSTERY_PERMISSIONS,
            self::GANGSTER_RANK => self::GANGSTER_PERMISSIONS,
            self::IMMORTAL_RANK => self::IMMORTAL_PERMISSIONS,
            self::SNOWMAN_RANK => self::SNOWMAN_PERMISSIONS,
            self::BOOSTER_RANK => self::BOOSTER_PERMISSIONS,
            self::FAMOUS_RANK => self::FAMOUS_PERMISSIONS,
            self::MODERATOR_RANK => self::MODERATOR_PERMISSIONS,
            self::ADMIN_RANK => self::ADMIN_PERMISSIONS,
            self::BUILDER_RANK => self::BUILDER_PERMISSIONS,
            self::STAFF_RANK => self::STAFF_PERMISSIONS,
            self::OWNER_RANK => self::OWNER_PERMISSIONS,
            default => self::DEFAULT_PERMISSIONS
        };
    }

    /**
     * @param PracticePlayer $player
     * @return string
     */
    public function getRankByXuid(PracticePlayer $player): string
    {
        $query = $this->plugin->getProvider()->getDatabase()->prepare("SELECT `rank` FROM `server_data` WHERE `xuid` = :xuid;");
        $query->bindValue(":xuid", $player->getXuid());
        $result = $query->execute()->fetchArray(SQLITE3_ASSOC);

        if (!($result)) {
            return self::DEFAULT_RANK;
        } else {
            return $result["rank"];
        }
    }

    /**
     * @param PracticePlayer $player
     * @return string
     */
    public function getRankFromArray(PracticePlayer $player): string
    {
        return $this->ranks[$player->getName()] ?? self::DEFAULT_RANK;
    }

    /**
     * @param string $nickname
     * @return string
     */
    public function getRankByNickname(string $nickname): string
    {
        $query = $this->plugin->getProvider()->getDatabase()->prepare("SELECT `rank` FROM `server_data` WHERE `nickname` = :nickname;");
        $query->bindValue(":nickname", strtolower($nickname));
        $result = $query->execute()->fetchArray(SQLITE3_ASSOC);

        if (!($result)) {
            return self::DEFAULT_RANK;
        } else {
            return $result["rank"];
        }
    }

    /**
     * @param string $nickname
     * @return string
     */
    public function getRankColoredByNickname(string $nickname): string
    {
        return match ($this->getRankByNickname($nickname)) {
            self::PLAYER_RANK => "§7Player",
            self::MYSTERY_RANK => "§5Mystery",
            self::GANGSTER_RANK => "§aGangster",
            self::IMMORTAL_RANK => "§dImmortal",
            self::SNOWMAN_RANK => "§fSnow§9man",
            self::BOOSTER_RANK => "§gBooster",
            self::FAMOUS_RANK => "§6Famous",
            self::MODERATOR_RANK => "§bModerator",
            self::ADMIN_RANK => "§3Admin",
            self::BUILDER_RANK => "§eBuilder",
            self::STAFF_RANK => "§cStaff",
            self::OWNER_RANK => "§4Owner",
            default => "§0Unknown"
        };
    }

    /**
     * @param PracticePlayer $player
     * @param string $rank
     * @return void
     */
    public function setRankByXuid(PracticePlayer $player, string $rank): void
    {
        if (!(in_array($rank, self::RANKS, true))) {
            $this->plugin->getLogger()->alert("Undefined rank: " . $rank);
            return;
        }

        $query = $this->plugin->getProvider()->getDatabase()->prepare("UPDATE `server_data` SET `rank` = :rank WHERE `xuid` = :xuid;");
        $query->bindValue(":rank", $rank);
        $query->bindValue(":xuid", $player->getXuid());
        $query->execute();

        $oldRank = $this->getRankFromArray($player);
        $this->setRankToArray($player, $rank);

        $event = new PlayerRankChangeEvent($player, $oldRank, $rank);
        $event->call();
    }

    /**
     * @param PracticePlayer $player
     * @param string $rank
     * @return void
     */
    public function setRankToArray(PracticePlayer $player, string $rank): void
    {
        if (!(in_array($rank, self::RANKS, true))) {
            $this->plugin->getLogger()->alert("Undefined rank: " . $rank);
            return;
        }

        $this->ranks[$player->getName()] = $rank;
    }

    /**
     * @param string $nickname
     * @param string $rank
     * @return void
     */
    public function setRankByNickname(string $nickname, string $rank): void
    {
        if (!(in_array($rank, self::RANKS, true))) {
            $this->plugin->getLogger()->alert("Undefined rank: " . $rank);
            return;
        }

        $query = $this->plugin->getProvider()->getDatabase()->prepare("UPDATE `server_data` SET `rank` = :rank WHERE `nickname` = :nickname;");
        $query->bindValue(":rank", $rank);
        $query->bindValue(":nickname", strtolower($nickname));
        $query->execute();
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function removeRankFromArray(PracticePlayer $player): void
    {
        if (isset($this->ranks[$player->getName()])) {
            unset($this->ranks[$player->getName()]);
        }
    }

    /**
     * @param PracticePlayer $player
     * @return int
     */
    public function getRankPriorityFromArray(PracticePlayer $player): int
    {
        return match ($this->getRankFromArray($player)) {
            self::PLAYER_RANK => 1,
            self::MYSTERY_RANK => 2,
            self::GANGSTER_RANK => 3,
            self::IMMORTAL_RANK => 4,
            self::SNOWMAN_RANK, self::BOOSTER_RANK, self::FAMOUS_RANK => 5,
            self::MODERATOR_RANK => 6,
            self::ADMIN_RANK => 7,
            self::BUILDER_RANK => 8,
            self::STAFF_RANK => 9,
            self::OWNER_RANK => 10,
            default => 0
        };
    }

    /**
     * @param string $nickname
     * @return int
     */
    public function getRankPriorityByNickname(string $nickname): int
    {
        return match ($this->getRankByNickname(strtolower($nickname))) {
            self::PLAYER_RANK => 1,
            self::MYSTERY_RANK => 2,
            self::GANGSTER_RANK => 3,
            self::IMMORTAL_RANK => 4,
            self::SNOWMAN_RANK, self::BOOSTER_RANK, self::FAMOUS_RANK => 5,
            self::MODERATOR_RANK => 6,
            self::ADMIN_RANK => 7,
            self::BUILDER_RANK => 8,
            self::STAFF_RANK => 9,
            self::OWNER_RANK => 10,
            default => 0
        };
    }

    /**
     * @param string $rank
     * @return int
     */
    public function getRankPriorityByRank(string $rank): int
    {
        return match ($rank) {
            self::PLAYER_RANK => 1,
            self::MYSTERY_RANK => 2,
            self::GANGSTER_RANK => 3,
            self::IMMORTAL_RANK => 4,
            self::SNOWMAN_RANK, self::BOOSTER_RANK, self::FAMOUS_RANK => 5,
            self::MODERATOR_RANK => 6,
            self::ADMIN_RANK => 7,
            self::BUILDER_RANK => 8,
            self::STAFF_RANK => 9,
            self::OWNER_RANK => 10,
            default => 0
        };
    }
}