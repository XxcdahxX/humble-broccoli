<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\player\rank;

use antralia\practice\player\PracticePlayer;
use pocketmine\event\player\PlayerEvent;

class PlayerRankChangeEvent extends PlayerEvent
{

    /**
     * @var string
     */
    private string $oldRank;

    /**
     * @var string
     */
    private string $newRank;

    /**
     * @param PracticePlayer $player
     * @param string $oldRank
     * @param string $newRank
     */
    public function __construct(PracticePlayer $player, string $oldRank, string $newRank)
    {
        $this->player = $player;
        $this->oldRank = $oldRank;
        $this->newRank = $newRank;
    }

    /**
     * @return PracticePlayer
     */
    public function getPlayer(): PracticePlayer
    {
        return $this->player;
    }

    /**
     * @return string
     */
    public function getOldRank(): string
    {
        return $this->oldRank;
    }

    /**
     * @return string
     */
    public function getNewRank(): string
    {
        return $this->newRank;
    }
}