<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\player\knockback;

use antralia\practice\player\PracticePlayer;
use antralia\practice\PracticePlugin;

final class KnockBack
{

    /**
     * @var PracticePlayer
     */
    private PracticePlayer $player;

    /**
     * @param PracticePlayer $player
     */
    public function __construct(PracticePlayer $player)
    {
        $this->player = $player;
    }

    /**
     * @return array
     */
    public function getData(): array
    {
        $ffaManager = PracticePlugin::getInstance()->getFFAManager();

        if ($ffaManager->isInFFA($this->player)) {
            if ($ffaManager->getNoDebuffManager()->isInArena($this->player)) {
                $x = 0.3855;
                $y = 0.385;
                $isVerticalLimited = false;
            } elseif ($ffaManager->getSoupManager()->isInArena($this->player)) {
                $x = 0.386;
                $y = 0.386;
                $isVerticalLimited = false;
            } elseif ($ffaManager->getSumoManager()->isInArena($this->player)) {
                $x = 0.378;
                $y = 0.382;
                $isVerticalLimited = false;
            } elseif ($ffaManager->getFistManager()->isInArena($this->player)) {
                $x = 0.377;
                $y = 0.382;
                $isVerticalLimited = false;
            } elseif ($ffaManager->getGAppleManager()->isInArena($this->player)) {
                $x = 0.377;
                $y = 0.381;
                $isVerticalLimited = false;
            } elseif ($ffaManager->getResistanceManager()->isInArena($this->player)) {
                $x = 0.377;
                $y = 0.382;
                $isVerticalLimited = false;
            } elseif ($ffaManager->getComboManager()->isInArena($this->player)) {
                $x = 0.245;
                $y = 0.21;
                $isVerticalLimited = abs($ffaManager->getComboManager()->getArenaY() - $this->player->getPosition()->getY()) >= 2.5;
            } else {
                $x = 0.4;
                $y = 0.4;
                $isVerticalLimited = false;
            }
        } else {
            $x = 0.4;
            $y = 0.4;
            $isVerticalLimited = false;
        }
        return ["x" => $x, "y" => $y, "verticalLimit" => $isVerticalLimited];
    }

    /**
     * @return int
     */
    public function getAttackSpeed(): int
    {
        $ffaManager = PracticePlugin::getInstance()->getFFAManager();

        if ($ffaManager->isInFFA($this->player)) {
            if ($ffaManager->getNoDebuffManager()->isInArena($this->player)) {
                return 9;
            } elseif ($ffaManager->getSoupManager()->isInArena($this->player)) {
                return 9;
            } elseif ($ffaManager->getSumoManager()->isInArena($this->player)) {
                return 8;
            } elseif ($ffaManager->getFistManager()->isInArena($this->player)) {
                return 8;
            } elseif ($ffaManager->getGAppleManager()->isInArena($this->player)) {
                return 8;
            } elseif ($ffaManager->getResistanceManager()->isInArena($this->player)) {
                return 8;
            } elseif ($ffaManager->getComboManager()->isInArena($this->player)) {
                return 3;
            } else {
                return 10;
            }
        } else {
            return 10;
        }
    }
}