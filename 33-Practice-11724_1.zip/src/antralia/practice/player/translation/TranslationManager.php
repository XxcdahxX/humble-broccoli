<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\player\translation;

use antralia\practice\player\PracticePlayer;
use antralia\practice\PracticePlugin;

final class TranslationManager
{

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @param PracticePlayer $player
     * @param string $message
     * @return string|array
     */
    public function translate(PracticePlayer $player, string $message): string|array
    {
        if ($this->plugin->getLanguageManager()->getLanguage($player) === "en") {
            return match ($message) {
                "commandNotFoundOrNoPermission" => "§cUnknown command: %s. Please check that the command exists and that you have permission to use it.",
                "commandOnlyConsole" => "§cCommand can be executed only from console!",
                "chatCooldown" => "§cDon't flood or spam!",
                "commandCooldown" => "§cDon't spam commands!",
                "chatLongMessage" => "§cYour message is too long!",
                "joinMessage" => "§fWelcome to the §l§aAntralia Network§r§f!\nCurrent online: §a%s\n§fStore: §aantralia.net",
                "languageAlreadySelected" => "§cYou have already English language selected!",
                "languageSuccessfullySelected" => "§aYou have selected English language!",
                "featureInDevelopment" => "§cThis feature is still in development!",
                "playerNotFound" => "§cPlayer not found!",
                "playerNotRegistered" => "§cPlayer is not registered!",
                "rankUsage" => "§eUsage: /rank <Player> <Rank>",
                "rankNotFound" => "§cRank not found!",
                "rankCannotBeSet" => "§cYou can't set this rank!",
                "rankSelf" => "§cYou can't change your own rank!",
                "rankCannotBeChanged" => "§cYou can't change this player's rank!",
                "rankAlreadySet" => "§cPlayer already have this rank!",
                "rankChanged" => "§a%s's rank has been changed to %s!",
                "rankChangedAnother" => "§aYour rank has been changed to %s!",
                "pingSelf" => "§aYour ping: §e%sms",
                "pingAnother" => "§e%s§a's ping: §e%sms",
                "platformSelf" => "§aYour platform: §e%s (%s)",
                "platformAnother" => "§e%s§a's platform: §e%s (%s)",
                "tellUsage" => "§eUsage: /tell <Player> <Message>",
                "tellSelfError" => "§cYou can't send a message to yourself!",
                "tellSelf" => "§eYour message to §a%s§e: %s",
                "tellAnother" => "§eMessage from §a%s§e: %s",
                "replyUsage" => "§eUsage: /reply <Message>",
                "replyNoOneTo" => "§cYou have no one to reply!",
                "replySelf" => "§eYour reply to §a%s§e: %s",
                "replyAnother" => "§eReply from §a%s§e: %s",
                "scoreboardEnabled" => "§aYou have successfully enabled scoreboard!",
                "scoreboardDisabled" => "§cYou have successfully disabled scoreboard!",
                "cpsEnabled" => "§aYou have successfully enabled clicks per second counter!",
                "cpsDisabled" => "§cYou have successfully disabled clicks per second counter!",
                "autosprintEnabled" => "§aYou have successfully enabled auto-sprint!",
                "autosprintDisabled" => "§cYou have successfully disabled auto-sprint!",
                "lightningEnabled" => "§aYou have successfully enabled lightning kill!",
                "lightningDisabled" => "§cYou have successfully disabled lightning kill!",
                "hidePlayersEnabled" => "§aYou have successfully enabled hiding players in combat!",
                "hidePlayersDisabled" => "§cYou have successfully disabled hiding players in combat!",
                "arenaRespawnEnabled" => "§aYou have successfully enabled arena respawn!",
                "arenaRespawnDisabled" => "§cYou have successfully disabled arena respawn!",
                "enderPearlCooldownStarted" => "§cCooldown started",
                "enderPearlCooldownEnded" => "§aCooldown ended",
                "enderPearlCooldownOngoing" => "§cYou're on cooldown for %s seconds",
                "muteExpiry" => "%s days, %s hours, %s minutes",
                "muteNeverExpires" => "never",
                "muteMessage" => "§cYou have been muted! §7(%s, %s)\n§fReason: §c%s §7| §fUnmute: §c%s",
                "banUsage" => "§eUsage: /ban <Player> <Time §7(in days, 0 - forever)§e> <Reason>",
                "invalidBanTime" => "§cInvalid ban time format!",
                "playerCannotBeBanned" => "§cYou can't ban this player!",
                "playerAlreadyBanned" => "§cPlayer is already banned!",
                "successfulBan" => "§aYou have successfully banned %s for %s days with reason: %s",
                "successfulForeverBan" => "§aYou have permanently banned %s with reason: %s",
                "muteUsage" => "§eUsage: /mute <Player> <Time §7(in days, 0 - forever)§e> <Reason>",
                "invalidMuteTime" => "§cInvalid mute time format!",
                "playerCannotBeMuted" => "§cYou can't mute this player!",
                "playerAlreadyMuted" => "§cPlayer is already muted!",
                "successfulMute" => "§aYou have successfully muted %s for %s days with reason: %s",
                "successfulForeverMute" => "§aYou have permanently muted %s with reason: %s",
                "kickUsage" => "§eUsage: /kick <Player> <Reason>",
                "playerCannotBeKicked" => "§cYou can't kick this player!",
                "successfulKick" => "§aYou have successfully kicked %s with reason: %s",
                "kickMessage" => "§cYou have been kicked! §7(%s, %s)\n\n§fReason: §c%s",
                "selfBan" => "§cYou can't ban yourself!",
                "selfMute" => "§cYou can't mute yourself!",
                "selfKick" => "§cYou can't kick yourself!",
                "unbanUsage" => "§eUsage: /unban <Player>",
                "unmuteUsage" => "§eUsage: /unmute <Player>",
                "unmuteSelf" => "§cYou can't unmute yourself!",
                "playerNotBanned" => "§cPlayer is not banned!",
                "playerNotMuted" => "§cPlayer is not muted!",
                "successfulUnban" => "§aYou have successfully unbanned: %s",
                "successfulUnmute" => "§aYou have successfully unmuted: %s",
                "reportUsage" => "§eUsage: /report <Player> <Reason>",
                "reportSelf" => "§cYou can't report yourself!",
                "playerCannotBeReported" => "§cYou can't report this player!",
                "successfulReport" => "§aYou have successfully reported §e%s §awith reason: §e%s",
                "clearedChat" => "§eChat have been cleared!",
                "clearChatSuccess" => "§aYou have successfully cleared the chat!",
                "emojiSuccess" => "§eAvailable emoji: §a (:skull:),  (:fire:),  (:eyes:),  (:clown:),  (:100:),  (:laugh:)",
                "crashUsage" => "§eUsage: /crash <Player> <Type>",
                "crashSelf" => "§cYou can't crash yourself!",
                "playerCannotBeCrashed" => "§cYou can't crash this player!",
                "crashProcessing" => "§eCrash is being processed... §7(%s)",
                "crashTypeNotFound" => "§cUnknown crash type!",
                "listSuccess" => "§eThere are §a%s §eplayers online:\n§a%s",
                "cosmeticsNoPermission" => "§cCosmetics are available from rank §l§5Mystery §r§cand above!",
                "tagsNoPermission" => "§cTags are available from rank §l§5Mystery §r§cand above!",
                "goldenTagsNoPermission" => "§cGolden tags are available from rank §l§aGangster §r§cand above!",
                "platinumTagsNoPermission" => "§cPlatinum tags are available from rank §l§dImmortal §r§cand above!",
                "tagAlreadySelected" => "§cYou have already selected this tag!",
                "tagEnabled" => "§aSelected tag: %s",
                "tagDisabled" => "§cYou have successfully disabled tag!",
                "tagDoesNotSet" => "§cYou don't have tag enabled!",
                "capesNoPermission" => "§cCapes are available from rank §l§aGangster §r§cand above!",
                "capeAlreadySelected" => "§cYou have already selected this cape!",
                "capeEnabled" => "§aSelected cape: %s",
                "capeDisabled" => "§cYou have successfully disabled cape!",
                "capeDoesNotSet" => "§cYou don't have cape enabled!",
                "flyNoPermission" => "§cFly is available from rank §l§aGangster §r§cand above!",
                "flyAlreadyEnabled" => "§cYou have already fly enabled!",
                "flyAlreadyDisabled" => "§cYou don't have fly enabled!",
                "flyEnabled" => "§aYou have successfully enabled fly!",
                "flyDisabled" => "§cYou have successfully disabled fly!",
                "flyEnabledForForm" => "§aenabled",
                "flyDisabledForForm" => "§cdisabled",
                "potionColorNoPermission" => "§cPotion color is available from rank §l§dImmortal §r§cand above!",
                "potionColorAlreadySelected" => "§cYou have already selected this potion color!",
                "potionColorAlreadyDisabled" => "§cYou don't have potion color enabled!",
                "potionColorEnabled" => "§aSelected potion color: %s",
                "potionColorDisabled" => "§cYou have successfully disabled potion color!",
                "spectateUsage" => "§eUsage: /spectate <Player|quit>",
                "notSpectator" => "§cYou are not in spectator mode!",
                "spectateSelf" => "§cYou can't spectate yourself!",
                "playerCannotBeSpectated" => "§cYou can't spectate this player!",
                "spectateAnotherSpectator" => "§cYou can't spectate another spectator!",
                "alreadySpectator" => "§cYou are already spectating another player!",
                "spectateInFFA" => "§cYou can't spectate while playing on FFA!",
                "spectateSuccess" => "§eYou are spectating over §a%s §e(%sms)",
                "spectatorSuccessfulTeleport" => "§aYou have teleported to your suspect!",
                "spectatorSuccessfulFreeze" => "§aYou have froze your suspect!",
                "frozenBySpectator" => "§eYou have been frozen by spectator!",
                "spectatorSuccessfulUnfreeze" => "§cYou have unfroze your suspect!",
                "spectatorSuccessfulQuit" => "§aYou have successfully quit from spectator mode!",
                "spectatorSuspectHadQuit" => "§cYour suspect have left the server!",
                "spectatorActionBar" => "§fSuspect: §e%s §7| §fPing: §e%sms\n§fOS: §e%s (%s)",
                "teleportedToSpawn" => "§aTeleporting to spawn!",
                "noSpawnInCombat" => "§cYou can't teleport to spawn in combat!",
                "noSpawnInRespawnDelay" => "§cYou can't teleport to spawn while respawning!",
                "noSpawnInSpectator" => "§cYou can't teleport to spawn in spectator mode!",
                "noReKitInCombat" => "§cYou can't re-kit in combat!",
                "noReKitInRespawnDelay" => "§cYou can't re-kit while respawning!",
                "successfulReKit" => "§aYou have been successfully re-kitted!",
                "notInFFA" => "§cYou are not in FFA!",
                "joinedFFA" => "§aYou have joined %s FFA!",
                "ffaSelfInCombat" => "§cYou are in combat with %s",
                "ffaPlayerInCombat" => "§c%s is in combat with %s",
                "ffaYouAreNowInCombat" => "§cYou are now in combat with %s!",
                "ffaCombatReduced" => "§aYou are no longer in combat!",
                "ffaNoDebuffKill" => "§e%s §7[§c%s POTS§7] §fwas killed by §e%s §7[§c%s POTS§7] §7[§4%s HP§7]",
                "ffaSoupKill" => "§e%s §7[§c%s SOUPS§7] §fwas killed by §e%s §7[§c%s SOUPS§7] §7[§4%s HP§7]",
                "ffaSumoKill", "ffaResistanceKill" => "§e%s §fwas killed by §e%s",
                "ffaFistKill", "ffaGAppleKill", "ffaComboKill" => "§e%s §fwas killed by §e%s §7[§4%s HP§7]",
                "playerRankChangedNotification" => "§e%s had set %s's rank to %s",
                "playerBanNotification" => "§e%s was banned by %s %s with reason: %s",
                "playerMuteNotification" => "§e%s was muted by %s %s with reason: %s",
                "playerUnbanNotification" => "§e%s was unbanned by %s",
                "playerUnmuteNotification" => "§e%s was unmuted by %s",
                "playerKickNotification" => "§e%s was kicked by %s with reason: %s",
                "playerReportNotification" => "§e%s was reported by %s with reason: %s",
                "clearedChatNotification" => "§e%s has cleared the chat",
                "serverRestartNotificationInMinutes" => "§aServer will restart in §e%s §aminutes!",
                "serverRestartNotificationInSeconds" => "§aServer will restart in §e%s §aseconds!",
                "gameModeUsage" => "§eUsage: /gamemode <Game mode>",
                "noGameModeInCombat" => "§cYou can't change your game mode in combat!",
                "noGameModeInSpectator" => "§cYou can't change your game mode in spectator mode!",
                "noGameModeInRespawnDelay" => "§cYou can't change your game mode while respawning!",
                "sameGameMode" => "§cYou are already in this game mode!",
                "unknownGameMode" => "§cUnknown game mode!",
                "gameModeChangedToSurvival" => "§aYour game mode has been changed to survival!",
                "gameModeChangedToCreative" => "§aYour game mode has been changed to creative!",
                "gameModeChangedToAdventure" => "§aYour game mode has been changed to adventure!",
                "gameModeChangedToSpectator" => "§aYour game mode has been changed to spectator!",
                "successfulReconnect" => "§eReconnecting...",
                "statusSuccess" => "§eServer status:\n§fOnline: §e%s\n§fUptime: §e%s\n§fCurrent TPS: §e%s §g(%s)\n§fAverage TPS: §e%s §g(%s)\n§fMemory used: §e%s MB",
                "profileCannotCheck" => "§cYou can't check this player's profile!",
                "profileYes" => "§ayes",
                "profileNo" => "§cno",
                "profileSelfOwner" => "§eYour profile (§a%s§e):\n§fRank: %s\n§fIP: §e%s\n§fMuted: %s\n§fPing: §e%sms\n§fGame version: §e%s\n§fOS: §e%s (%s)\n§fModel: §e%s\n§fOther accounts: §e%s",
                "profileSelf" => "§eYour profile (§a%s§e):\n§fRank: %s\n§fMuted: %s\n§fPing: §e%sms\n§fGame version: §e%s\n§fOS: §e%s (%s)\n§fOther accounts: §e%s",
                "profileOnlineOwner" => "§a%s§e's profile:\n§fRank: %s\n§fIP: §e%s\n§fOnline: %s\n§fBanned: %s\n§fMuted: %s\n§fPing: §e%sms\n§fGame version: §e%s\n§fOS: §e%s (%s)\n§fModel: §e%s\n§fOther accounts: §e%s",
                "profileOnline" => "§a%s§e's profile:\n§fRank: %s\n§fOnline: %s\n§fBanned: %s\n§fMuted: %s\n§fPing: §e%sms\n§fGame version: §e%s\n§fOS: §e%s (%s)\n§fOther accounts: §e%s",
                "profileOfflineOwner" => "§a%s§e's profile:\n§fRank: %s\n§fIP: §e%s\n§fOnline: %s\n§fBanned: %s\n§fMuted: %s\n§fOther accounts: §e%s",
                "profileOffline" => "§a%s§e's profile:\n§fRank: %s\n§fOnline: %s\n§fBanned: %s\n§fMuted: %s\n§fOther accounts: §e%s",
                "successfulSurrender" => "§aYou have successfully surrendered!",
                "notInCombat" => "§cYou are not in combat!",
                "banCommandDescription" => "Ban a player",
                "clearChatCommandDescription" => "Clear the chat",
                "crashCommandDescription" => "Crash player's client",
                "emojiCommandDescription" => "Emoji list",
                "gameModeCommandDescription" => "Change your game mode",
                "infoCommandDescription" => "Information about the server",
                "listCommandDescription" => "Online players list",
                "kickCommandDescription" => "Kick a player",
                "muteCommandDescription" => "Mute a player",
                "pingCommandDescription" => "Check your or another player's ping",
                "platformCommandDescription" => "Check your or another player's platform",
                "profileCommandDescription" => "Check your or another player's profile",
                "rankCommandDescription" => "Change player's rank",
                "reconnectCommandDescription" => "Reconnect to the server",
                "reKitCommandDescription" => "Get a new kit",
                "replyCommandDescription" => "Reply to player's message",
                "reportCommandDescription" => "Report a player",
                "restartCommandDescription" => "Restart the server",
                "rulesCommandDescription" => "Server's rules",
                "sayCommandDescription" => "Broadcast a message",
                "spawnCommandDescription" => "Teleport to spawn",
                "spectateCommandDescription" => "Spectate over player",
                "statusCommandDescription" => "Check the server status",
                "surrenderCommandDescription" => "Leave from a fight",
                "tellCommandDescription" => "Send a message to player",
                "unbanCommandDescription" => "Unban a player",
                "unmuteCommandDescription" => "Unmute a player",
                "broadcastNotification" => [
                    0 => "§aCheck out our store: §eantralia.net",
                    1 => "§aJoin our VK group: §evk.com/antralia",
                    2 => "§aJoin our Discord server: §ediscord.gg/antralia",
                    3 => "§aVisit our Telegram channel: §et.me/antralia",
                ],
                "joinTitle" => [
                    0 => "§l§aAntralia",
                    1 => "§fHave a good game!"
                ],
                "ffaDeathTitle" => [
                    0 => "§l§cYOU DIED",
                    1 => "§e%s"
                ],
                "serverRestartTitle" => [
                    0 => "§l§aRestart",
                    1 => "%s"
                ],
                "gamesForm" => [
                    0 => "Games",
                    1 => "§fYou can §aselect §fone of our games to play!",
                    2 => "§2Free For All\n§8Playing: §e%s"
                ],
                "ffaForm" => [
                    0 => "Free For All",
                    1 => "§cNoDebuff\n§8Playing: §e%s",
                    2 => "§7Soup\n§8Playing: §e%s",
                    3 => "§aSumo\n§8Playing: §e%s",
                    4 => "§6Fist\n§8Playing: §e%s",
                    5 => "§eGApple\n§8Playing: §e%s",
                    6 => "§4Resistance\n§8Playing: §e%s",
                    7 => "§bCombo\n§8Playing: §e%s",
                    8 => "§8Go back\n§7Click to return"
                ],
                "preferencesForm" => [
                    0 => "Preferences",
                    1 => "Language\n§7Select a language",
                    2 => "Toggles\n§7Enable or disable feature",
                    3 => "Cosmetics\n§7Change your appearance",
                ],
                "languageForm" => [
                    0 => "Select a language",
                    1 => "English\n§aSelected",
                    2 => "Russian\n§7Click to select",
                    3 => "Go back\n§7Click to return"
                ],
                "languageConfirmationForm" => [
                    0 => "Confirm language selection",
                    1 => "§fDo you want to select §e%s §flanguage?",
                    2 => "Yes",
                    3 => "No"
                ],
                "togglesForm" => [
                    0 => "Toggles",
                    1 => "General\n§7Change your general settings",
                    2 => "Free For All\n§7Change your FFA settings",
                    3 => "Go back\n§7Click to return",
                ],
                "generalTogglesForm" => [
                    0 => "General settings",
                    1 => "Scoreboard",
                    2 => "Clicks per second counter",
                    3 => "Auto-sprint",
                    4 => "Lightning kill"
                ],
                "ffaTogglesForm" => [
                    0 => "Free For All settings",
                    1 => "Hide players in combat",
                    2 => "Arena respawn"
                ],
                "cosmeticsForm" => [
                    0 => "Cosmetics",
                    1 => "Capes\n§7Select your cape",
                    2 => "Tags\n§7Select your tag",
                    3 => "Fly\n§7Enable fly mode",
                    4 => "Potion color\n§7Select your potion color",
                    5 => "Go back\n§7Click to return"
                ],
                "capesForm" => [
                    0 => "Capes",
                    1 => "§fYour cape: §e%s",
                    2 => "§8All capes\n§7Select a cape",
                    3 => "§cRemove cape\n§7Remove your cape",
                    4 => "§8Go back\n§7Click to return"
                ],
                "capesSelectionForm" => [
                    0 => "All capes",
                    1 => "§aAntralia\n§7Click to select",
                    2 => "§4Lunarelly\n§7Click to select",
                    3 => "§dBirthday\n§7Click to select",
                    4 => "§bCake\n§7Click to select",
                    5 => "§5Enderman\n§7Click to select",
                    6 => "§6Firework\n§7Click to select",
                    7 => "§8Iron Golem\n§7Click to select",
                    8 => "§9Pickaxe\n§7Click to select",
                    9  => "§2Green Creeper\n§7Click to select",
                    10 => "§cRed Creeper\n§7Click to select",
                    11 => "§2Turtle\n§7Click to select",
                    12 => "§cMigrator\n§7Click to select",
                    13 => "§8Go back\n§7Click to return"
                ],
                "tagsForm" => [
                    0 => "Tags",
                    1 => "Your tag: %s",
                    2 => "§fSilver tags\n§7Select a silver tag",
                    3 => "§6Golden tags\n§7Select a golden tag",
                    4 => "§bPlatinum tags\n§7Select a platinum tag",
                    5 => "§cRemove tag\n§7Remove your tag",
                    6 => "§8Go back\n§7Click to return"
                ],
                "silverTagsForm" => [
                    0 => "Silver tags",
                    1 => "§dE-GIRL\n§7Click to select",
                    2 => "§cBESTWW\n§7Click to select",
                    3 => "§6GOD\n§7Click to select",
                    4 => "§eLIT\n§7Click to select",
                    5 => "§dLUNAR\n§7Click to select",
                    6 => "§7STARDUST\n§7Click to select",
                    7 => "§8CHOPPA\n§7Click to select",
                    8 => "§fCLOUTLORD\n§7Click to select",
                    9 => "§8Go back\n§7Click to return"
                ],
                "goldenTagsForm" => [
                    0 => "Golden tags",
                    1 => "§aANTRALIA\n§7Click to select",
                    2 => "§bFINESSE\n§7Click to select",
                    3 => "§cMEMPHIS\n§7Click to select",
                    4 => "§5LEANDOER\n§7Click to select",
                    5 => "§2JUGG\n§7Click to select",
                    6 => "§gCAPYBARA\n§7Click to select",
                    7 => "§3SHOOTA\n§7Click to select",
                    8 => "§6L\n§7Click to select",
                    9 => "§4W\n§7Click to select",
                    10 => "§8Go back\n§7Click to return"
                ],
                "platinumTagsForm" => [
                    0 => "Platinum tags",
                    1 => "§cSANTA\n§7Click to select",
                    2 => "§dTRIPPY\n§7Click to select",
                    3 => "§4MAFIA\n§7Click to select",
                    4 => "§3ALCOHOLIC\n§7Click to select",
                    5 => "§bBLATANT\n§7Click to select",
                    6 => "§eJUICY\n§7Click to select",
                    7 => "§6OG\n§7Click to select",
                    8 => "§gBROKE\n§7Click to select",
                    9 => "§2INDIAN\n§7Click to select",
                    10 => "§5GOAT\n§7Click to select",
                    11 => "§8Go back\n§7Click to return"
                ],
                "flyForm" => [
                    0 => "Fly",
                    1 => "Fly: %s",
                    2 => "§aEnable fly\n§7Enable fly mode",
                    3 => "§cDisable fly\n§7Disable fly mode",
                    4 => "§8Go back\n§7Click to return"
                ],
                "potionColorForm" => [
                    0 => "Potion color",
                    1 => "Potion color: %s",
                    2 => "§8Potion colors\n§7Select a potion color",
                    3 => "§cDisable potion color\n§7Disable your potion color",
                    4 => "§8Go back\n§7Click to return"
                ],
                "potionColorSelectionForm" => [
                    0 => "Potion colors",
                    1 => "§cRed\n§7Click to select",
                    2 => "§4Dark Red\n§7Click to select",
                    3 => "§9Blue\n§7Click to select",
                    4 => "§bLight Blue\n§7Click to select",
                    5 => "§aGreen\n§7Click to select",
                    6 => "§dPurple\n§7Click to select",
                    7 => "§eYellow\n§7Click to select",
                    8 => "§fWhite\n§7Click to select",
                    9 => "§0Black\n§7Click to select",
                    10 => "§8Go back\n§7Click to return"
                ],
                "statisticsForm" => [
                    0 => "Statistics",
                    1 => "§aYour statistics:\n\n§fDivision: %s\n\n§fKills: §e%s\n§fDeaths: §e%s\n\n§fKDR: §e%s\n\n§fTime played: §e%s hours",
                    2 => "Top killers\n§7See who have the most kills"
                ],
                "topKillersForm" => [
                    0 => "Top killers",
                    1 => "%s%s. §f%s §7(§a%s kills§7)",
                    2 => "Go back\n§7Click to return"
                ],
                "menuForm" => [
                    0 => "Menu",
                    1 => "Info\n§7See server's information",
                    2 => "Rules\n§7See server's rules"
                ],
                "hubItems" => [
                    0 => "§r§aGames\n§7Click to use",
                    1 => "§r§aPreferences\n§7Click to use",
                    2 => "§r§aStatistics\n§7Click to use"
                ],
                "spectatorItems" => [
                    0 => "§r§aTeleport to suspect\n§7Click to use",
                    1 => "§r§aFreeze suspect\n§7Click to use",
                    2 => "§r§cUnfreeze suspect\n§7Click to use",
                    3 => "§r§aQuit from spectating\n§7Click to use"
                ],
                "infoForm" => [
                    0 => "Info",
                    1 => "§aSocials:\n§fVK: §evk.com/antralia\n§fDiscord: §ediscord.gg/antralia (antralia.net/discord)\n§fTelegram: §et.me/antralia\n\n§aDonate:\n§fStore: §eantralia.net (store.antralia.net)\n\n§7If you can't pay in the store, or you want to pay crypto, contact the Owners.\n\n§cMade by Lunarelly for Antralia with love. <3",
                    2 => "§8Go back\n§7Click to return"
                ],
                "rulesForm" => [
                    0 => "Rules",
                    1 => "§a1. In-Game process:\n§e1.1 §fCheating or using software, that gives you unfair advantage is forbidden - lifetime ban.\n§e1.2 §fVPN/Proxy is forbidden - lifetime ban. §7(contact us if you can't play without it)\n§e1.3 §fCheat Check/Screen Share refuse is forbidden - lifetime ban.\n§e1.4 §fUsage of server/client bugs is forbidden - kick, after - ban for 1 day.\n§e1.5 §fTeaming is forbidden - kick §7(1/3)§f, after - ban for 1 day.\n§e1.6 §fGiving or selling your account to someone is forbidden - lifetime ban and rank removal.\n§e1.7 §fInterrupting is forbidden - kick §7(1/3)§f, after - ban for 1 day.\n§e1.8 §fCustom 4D models/large, small, invisible skins §7(not from marketplace) §fis forbidden - kick, after - ban for 1 day.\n§e1.9 §fIncorrect/false reports is forbidden - kick, after - ban for 1 day.\n§e1.10 §fIncorrect §7(insulting) §fnicknames is forbidden - lifetime ban.\n§e1.11 §fHitting a player then running from him around the map is forbidden - kick §7(1/3)§f, after - ban for 1 day.\n\n§a2. In-Game chat:\n§e2.1 §fInsulting players is forbidden §7(L, ez and similar doesn't count) §f- kick §7(1/3)§f, after - mute for 1 day.\n§e2.2 §fInsulting staff is forbidden §7(L, ez and similar doesn't count) §f- mute for 2 days.\n§e2.3 §fRacism or insults because of nationality is forbidden - mute for 1 day.\n§e2.4 §fSpamming/flooding is forbidden - mute for 1 day.\n§e2.5 §fAdvertising other servers is forbidden - lifetime mute.\n§e2.6 §fInsulting this server is forbidden - mute for 1 week.\n\n§eBuy unban/unmute: §aantralia.net",
                    2 => "§8Go back\n§7Click to return"
                ],
                "hubFloatingText" => [
                    0 => "§0 \n§l§aAntralia Network",
                    1 => "\n§1\n§eEnjoy our new games!\n§2\n§aantralia.net\n§3 "
                ],
                "hubScoreboard" => [
                    0 => "§l§aAntralia§r",
                    1 => "§0",
                    2 => " §fRank: %s",
                    3 => " §fDivision: %s",
                    4 => "§1",
                    5 => " §fOnline: §a%s",
                    6 => " §fPlaying: §a%s",
                    7 => "§2",
                    8 => " §7antralia.net"
                ],
                "ffaScoreboard" => [
                    0 => "§l§aAntralia§r",
                    1 => "§0",
                    2 => " §fYour ping: §a%sms",
                    3 => " §fTheir ping: §a%sms",
                    4 => "§1",
                    5 => " §fCombat: §a%ss",
                    6 => "§2",
                    7 => " §7antralia.net"
                ],
                default => "Unknown message"
            };
        } elseif ($this->plugin->getLanguageManager()->getLanguage($player) === "ru") {
            return match ($message) {
                "commandNotFoundOrNoPermission" => "§cНеизвестная команда: %s. Убедитесь, что такая команда существует и у вас есть право ее использовать.",
                "commandOnlyConsole" => "§cКоманда может быть выполнена только от консоли!",
                "chatCooldown" => "§cНе спамьте!",
                "commandCooldown" => "§cНе спамьте командами!",
                "chatLongMessage" => "§cВаше сообщение слишком длинное!",
                "joinMessage" => "§fДобро пожаловать на §l§aAntralia Network§r§f!\nТекущий онлайн: §a%s\n§fСайт: §aantralia.net",
                "languageAlreadySelected" => "§cУ Вас уже выбран Русский язык!",
                "languageSuccessfullySelected" => "§aВы выбрали Русский язык в качестве основного языка!",
                "featureInDevelopment" => "§cДанная функция находится в разработке!",
                "playerNotFound" => "§cИгрок не найден!",
                "playerNotRegistered" => "§cИгрок не зарегистрирован!",
                "rankUsage" => "§eИспользование: /rank <Игрок> <Ранг>",
                "rankNotFound" => "§cРанг не найден!",
                "rankCannotBeSet" => "§cВы не можете поставить этот ранг!",
                "rankSelf" => "§cВы не можете поменять свой ранг!",
                "rankCannotBeChanged" => "§cВы не можете поменять ранг этого игрока!",
                "rankAlreadySet" => "§cУ этого игрока и так установлен этот ранг!",
                "rankChanged" => "§aРанг игрока %s был изменён на %s!",
                "rankChangedAnother" => "§aВаш ранг был изменён на %s!",
                "pingSelf" => "§aВаш пинг: §e%sмс",
                "pingAnother" => "§aПинг игрока §e%s§a: §e%sмс",
                "platformSelf" => "§aВаша платформа: §e%s (%s)",
                "platformAnother" => "§aПлатформа игрока §e%s§a: §e%s (%s)",
                "tellUsage" => "§eИспользование: /tell <Игрок> <Сообщение>",
                "tellSelfError" => "§cВы не можете отправить сообщение самому себе!",
                "tellSelf" => "§eВаше сообщение игроку §a%s§e: %s",
                "tellAnother" => "§eСообщение от §a%s§e: %s",
                "replyUsage" => "§eИспользование: /reply <Сообщение>",
                "replyNoOneTo" => "§cВам некому отвечать!",
                "replySelf" => "§eВаш ответ игроку §a%s§e: %s",
                "replyAnother" => "§eОтвет от игрока §a%s§e: %s",
                "scoreboardEnabled" => "§aВы успешно включили scoreboard!",
                "scoreboardDisabled" => "§cВы успешно отключили scoreboard!",
                "cpsEnabled" => "§aВы успешно включили счётчик кликов в секунду!",
                "cpsDisabled" => "§cВы успешно отключили счётчик кликов в секунду!",
                "autosprintEnabled" => "§aВы успешно включили авто-бег!",
                "autosprintDisabled" => "§cВы успешно отключили авто-бег!",
                "lightningEnabled" => "§aВы успешно включили молнию после убийства!",
                "lightningDisabled" => "§cВы успешно отключили молнию после убийства!",
                "hidePlayersEnabled" => "§aВы успешно включили скрытие игроков в бою!",
                "hidePlayersDisabled" => "§cВы успешно отключили скрытие игроков в бою!",
                "arenaRespawnEnabled" => "§aВы успешно включили возрождение на арене!",
                "arenaRespawnDisabled" => "§cВы успешно отключили возрождение на арене!",
                "enderPearlCooldownStarted" => "§cКулдаун начался",
                "enderPearlCooldownEnded" => "§aКулдаун закончился",
                "enderPearlCooldownOngoing" => "§cВы сможете использовать этот предмет через %s секунд",
                "muteExpiry" => "%s дней, %s часов, %s минут",
                "muteNeverExpires" => "никогда",
                "muteMessage" => "§cВам был заблокирован чат! §7(%s, %s)\n§fПричина: §c%s §7| §fРазмут: §c%s",
                "banUsage" => "§eИспользование: /ban <Игрок> <Время §7(в днях, 0 - навсегда)§e> <Причина>",
                "invalidBanTime" => "§cНеверный формат времени для бана!",
                "playerCannotBeBanned" => "§cВы не можете забанить этого игрока!",
                "playerAlreadyBanned" => "§cИгрок уже забанен!",
                "successfulBan" => "§aВы успешно забанили игрока %s на %s дней с причиной: %s",
                "successfulForeverBan" => "§aВы успешно забанили игрока %s навсегда с причиной: %s",
                "muteUsage" => "§eИспользование: /mute <Игрок> <Время §7(в днях, 0 - навсегда)§e> <Причина>",
                "invalidMuteTime" => "§cНеверный формат времени для мута!",
                "playerCannotBeMuted" => "§cВы не можете замутить этого игрока!",
                "playerAlreadyMuted" => "§cИгрок уже находится в муте!",
                "successfulMute" => "§aВы успешно замутили игрока %s на %s дней с причиной: %s",
                "successfulForeverMute" => "§aВы успешно замутили игрока %s навсегда с причиной: %s",
                "kickUsage" => "§eИспользование: /kick <Игрок> <Причина>",
                "playerCannotBeKicked" => "§cВы не можете кикнуть этого игрока!",
                "successfulKick" => "§aВы успешно кикнули игрока %s с причиной: %s",
                "kickMessage" => "§cВы были кикнуты! §7(%s, %s)\n\n§fПричина: §c%s",
                "selfBan" => "§cВы не можете забанить самого себя!",
                "selfMute" => "§cВы не можете замутить самого себя!",
                "selfKick" => "§cВы не можете кикнуть самого себя!",
                "unbanUsage" => "§eИспользование: /unban <Player>",
                "unmuteUsage" => "§eИспользование: /unmute <Player>",
                "unmuteSelf" => "§cВы не можете размутить самого себя!",
                "playerNotBanned" => "§cИгрок не забанен!",
                "playerNotMuted" => "§cИгрок не находится в муте!",
                "successfulUnban" => "§aВы успешно разбанили игрока: %s",
                "successfulUnmute" => "§aВы успешно размутили игрока: %s",
                "reportUsage" => "§eИспользование: /report <Игрок> <Причина>",
                "reportSelf" => "§cВы не можете пожаловаться на самого себя!",
                "playerCannotBeReported" => "§cВы не можете пожаловаться на этого игрока!",
                "successfulReport" => "§aВы успешно пожаловались на игрока §e%s §aс причиной: §e%s",
                "clearedChat" => "§eЧат был очищен!",
                "clearChatSuccess" => "§aВы успешно очистили чат!",
                "emojiSuccess" => "§eДоступные эмодзи: §a (:skull:),  (:fire:),  (:eyes:),  (:clown:),  (:100:),  (:laugh:)",
                "crashUsage" => "§eИспользование: /crash <Игрок> <Тип>",
                "crashSelf" => "§cВы не можете крашнуть самого себя!",
                "playerCannotBeCrashed" => "§cВы не можете крашнуть этого игрока!",
                "crashProcessing" => "§eКраш в процессе... §7(%s)",
                "crashTypeNotFound" => "§cНеизвестный тип краша!",
                "listSuccess" => "§eСейчас §a%s §eигроков онлайн:\n§a%s",
                "cosmeticsNoPermission" => "§cКосметика доступна с привилегии §l§5Mystery §r§cи выше!",
                "tagsNoPermission" => "§cТеги доступны с привилегии §l§5Mystery §r§cи выше!",
                "goldenTagsNoPermission" => "§cЗолотые теги доступны с привилегии §l§aGangster §r§cи выше!",
                "platinumTagsNoPermission" => "§cПлатиновые теги доступны с привилегии §l§dImmortal §r§cи выше!",
                "tagAlreadySelected" => "§cВы уже выбрали этот тег!",
                "tagEnabled" => "§aВыбран тег: %s",
                "tagDisabled" => "§cВы успешно отключили тег!",
                "tagDoesNotSet" => "§cУ Вас не включён тег!",
                "capesNoPermission" => "§cПлащи доступны с привилегии §l§aGangster §r§cи выше!",
                "capeAlreadySelected" => "§cВы уже выбрали этот плащ!",
                "capeEnabled" => "§aВыбран плащ: %s",
                "capeDisabled" => "§cВы успешно отключили плащ!",
                "capeDoesNotSet" => "§cУ Вас не включён плащ!",
                "flyNoPermission" => "§cПолёт доступен с привилегии §l§aGangster §r§cи выше!",
                "flyAlreadyEnabled" => "§cУ Вас уже включён полёт!",
                "flyAlreadyDisabled" => "§cУ Вас не включён полёт!",
                "flyEnabled" => "§aВы успешно включили полёт!",
                "flyDisabled" => "§cВы успешно отключили полёт!",
                "flyEnabledForForm" => "§aвключён",
                "flyDisabledForForm" => "§cотключён",
                "potionColorNoPermission" => "§cЦвет зелий доступен с привилегии §l§dImmortal §r§cи выше!",
                "potionColorAlreadySelected" => "§cУ вас уже выбран этот цвет зелий!",
                "potionColorAlreadyDisabled" => "§cУ вас не включён цвет зелий!",
                "potionColorEnabled" => "§aВыбран цвет зелий: %s",
                "potionColorDisabled" => "§cВы успешно отключили цвет зелий!",
                "spectateUsage" => "§eИспользование: /spectate <Игрок|quit>",
                "notSpectator" => "§cВы не в режиме наблюдения!",
                "spectateSelf" => "§cВы не можете наблюдать за самим собой!",
                "playerCannotBeSpectated" => "§cВы не можете наблюдать за этим игроком!",
                "spectateAnotherSpectator" => "§cВы не можете наблюдать за другим наблюдателем!",
                "alreadySpectator" => "§cВы и так наблюдаете за другим игроком!",
                "spectateInFFA" => "§cВы не можете наблюдать, пока играете на открытой арене!",
                "spectateSuccess" => "§eВы наблюдаете за §a%s §e(%sмс)",
                "spectatorSuccessfulTeleport" => "§aВы успешно телепортировались к подозреваемому!",
                "spectatorSuccessfulFreeze" => "§aВы успешно заморозили своего подозреваемого!",
                "frozenBySpectator" => "§eВы были заморожены наблюдателем!",
                "spectatorSuccessfulUnfreeze" => "§cВы успешно разморозили своего подозреваемого!",
                "spectatorSuccessfulQuit" => "§aВы успешно покинули режим наблюдения!",
                "spectatorSuspectHadQuit" => "§cВаш подозреваемый покинул сервер!",
                "spectatorActionBar" => "§fПодозреваемый: §e%s §7| §fПинг: §e%sмс\n§fОС: §e%s (%s)",
                "teleportedToSpawn" => "§aТелепортируемся на спавн!",
                "noSpawnInCombat" => "§cВы не можете выйти на спавн, пока вы в бою!",
                "noSpawnInRespawnDelay" => "§cВы не можете выйти на спавн, пока вы возрождаетесь!",
                "noSpawnInSpectator" => "§cВы не можете выйти на спавн в режиме наблюдения!",
                "noReKitInCombat" => "§cВы не можете повторно получить набор, пока вы в бою!",
                "noReKitInRespawnDelay" => "§cВы не можете повторно получить набор, пока вы возрождаетесь!",
                "successfulReKit" => "§aВы успешно получили новый набор!",
                "notInFFA" => "§cВы не находитесь на открытой арене!",
                "joinedFFA" => "§aВы вошли на открытую арену %s!",
                "ffaSelfInCombat" => "§cВы находитесь в бою с %s",
                "ffaPlayerInCombat" => "§c%s в бою с %s",
                "ffaYouAreNowInCombat" => "§cВы теперь в бою с %s!",
                "ffaCombatReduced" => "§aВы больше не в бою!",
                "ffaNoDebuffKill" => "§e%s §7[§c%s POTS§7] §fбыл убит §e%s §7[§c%s POTS§7] §7[§4%s HP§7]",
                "ffaSoupKill" => "§e%s §7[§c%s SOUPS§7] §fбыл убит §e%s §7[§c%s SOUPS§7] §7[§4%s HP§7]",
                "ffaSumoKill", "ffaResistanceKill" => "§e%s §fбыл убит §e%s",
                "ffaFistKill", "ffaGAppleKill", "ffaComboKill" => "§e%s §fбыл убит §e%s §7[§4%s HP§7]",
                "playerRankChangedNotification" => "§e%s изменил ранг игрока %s на %s",
                "playerBanNotification" => "§eИгрок %s был забанен от руки %s %s с причиной: %s",
                "playerMuteNotification" => "§eИгроку %s был заблокирован чат от руки %s %s с причиной: %s",
                "playerUnbanNotification" => "§eИгрок %s был разбанен от руки %s",
                "playerUnmuteNotification" => "§eИгроку %s был разблокирован чат от руки %s",
                "playerKickNotification" => "§eИгрок %s был кикнут от руки %s с причиной: %s",
                "playerReportNotification" => "§eНа игрока %s пожаловался %s с причиной: %s",
                "clearedChatNotification" => "§e%s очистил чат",
                "serverRestartNotificationInMinutes" => "§aСервер перезагрузится через §e%s §aминут!",
                "serverRestartNotificationInSeconds" => "§aСервер перезагрузится через §e%s §aсекунд!",
                "gameModeUsage" => "§eИспользование: /gamemode <Режим игры>",
                "noGameModeInCombat" => "§cВы не можете сменить режим игры, пока вы в бою!",
                "noGameModeInSpectator" => "§cВы не можете сменить режим игры в режиме наблюдения!",
                "noGameModeInRespawnDelay" => "§cВы не можете сменить режим игры, пока вы возрождаетесь!",
                "sameGameMode" => "§cВы и так находитесь в этом режиме игры!",
                "unknownGameMode" => "§cНеизвестный режим игры!",
                "gameModeChangedToSurvival" => "§aВаш режим игры был изменён на выживание!",
                "gameModeChangedToCreative" => "§aВаш режим игры был изменён на творческий!",
                "gameModeChangedToAdventure" => "§aВаш режим игры был изменён на приключение!",
                "gameModeChangedToSpectator" => "§aВаш режим игры был изменён на наблюдателя!",
                "successfulReconnect" => "§eПереподключение...",
                "statusSuccess" => "§eСостояние сервера:\n§fОнлайн: §e%s\n§fАптайм: §e%s\n§fТекущий TPS: §e%s §g(%s)\n§fСредний TPS: §e%s §g(%s)\n§fИспользовано памяти: §e%s МБ",
                "profileCannotCheck" => "§cВы не можете посмотреть профиль этого игрока!",
                "profileYes" => "§aда",
                "profileNo" => "§cнет",
                "profileSelfOwner" => "§eВаш профиль (§a%s§e):\n§fРанг: %s\n§fАйпи: §e%s\n§fМут: %s\n§fПинг: §e%sмс\n§fВерсия игры: §e%s\n§fОС: §e%s (%s)\n§fМодель: §e%s\n§fДругие аккаунты: §e%s",
                "profileSelf" => "§eВаш профиль (§a%s§e):\n§fРанг: %s\n§fМут: %s\n§fПинг: §e%sмс\n§fВерсия игры: §e%s\n§fОС: §e%s (%s)\n§fДругие аккаунты: §e%s",
                "profileOnlineOwner" => "§eПрофиль игрока §a%s§e:\n§fРанг: %s\n§fАйпи: §e%s\n§fОнлайн: %s\n§fБан: %s\n§fМут: %s\n§fПинг: §e%sмс\n§fВерсия игры: §e%s\n§fОС: §e%s (%s)\n§fМодель: §e%s\n§fДругие аккаунты: §e%s",
                "profileOnline" => "§eПрофиль игрока §a%s§e:\n§fРанг: %s\n§fОнлайн: %s\n§fБан: %s\n§fМут: %s\n§fПинг: §e%sмс\n§fВерсия игры: §e%s\n§fОС: §e%s (%s)\n§fДругие аккаунты: §e%s",
                "profileOfflineOwner" => "§eПрофиль игрока §a%s§e:\n§fРанг: %s\n§fАйпи: §e%s\n§fОнлайн: %s\n§fБан: %s\n§fМут: %s\n§fДругие аккаунты: §e%s",
                "profileOffline" => "§eПрофиль игрока §a%s§e:\n§fРанг: %s\n§fОнлайн: %s\n§fБан: %s\n§fМут: %s\n§fДругие аккаунты: §e%s",
                "successfulSurrender" => "§aВы успешно сдались!",
                "notInCombat" => "§cВы не находитесь в бою!",
                "banCommandDescription" => "Забанить игрока",
                "clearChatCommandDescription" => "Очистить чат",
                "crashCommandDescription" => "Крашнуть клиент игрока",
                "emojiCommandDescription" => "Список эмодзи",
                "gameModeCommandDescription" => "Сменить свой режим игры",
                "infoCommandDescription" => "Информация о сервере",
                "listCommandDescription" => "Список онлайн игроков",
                "kickCommandDescription" => "Кикнуть игрока",
                "muteCommandDescription" => "Замутить игрока",
                "pingCommandDescription" => "Посмотреть свой пинг или же у другого игрока",
                "platformCommandDescription" => "Посмотреть свою платформу или же у другого игрока",
                "profileCommandDescription" => "Посмотреть свой профиль или же у другого игрока",
                "rankCommandDescription" => "Сменить ранг игрока",
                "reconnectCommandDescription" => "Переподключиться к серверу",
                "reKitCommandDescription" => "Получить новый набор",
                "replyCommandDescription" => "Ответить на сообщение игрока",
                "reportCommandDescription" => "Пожаловаться на игрока",
                "restartCommandDescription" => "Перезагрузить сервер",
                "rulesCommandDescription" => "Правила сервера",
                "sayCommandDescription" => "Объявить сообщение",
                "spawnCommandDescription" => "Телепортироваться на спавн",
                "spectateCommandDescription" => "Наблюдать за игроком",
                "statusCommandDescription" => "Посмотреть состояние сервера",
                "surrenderCommandDescription" => "Покинуть бой",
                "tellCommandDescription" => "Отправить сообщение игроку",
                "unbanCommandDescription" => "Разбанить игрока",
                "unmuteCommandDescription" => "Размутить игрока",
                "broadcastNotification" => [
                    0 => "§aЗаходите в наш магазин: §eantralia.net",
                    1 => "§aВступите в нашу группу VK: §evk.com/antralia",
                    2 => "§aЗаходите на наш Discord сервер: §ediscord.gg/antralia",
                    3 => "§aПосетите наш Telegram канал: §et.me/antralia",
                ],
                "joinTitle" => [
                    0 => "§l§aAntralia",
                    1 => "§fПриятной игры!"
                ],
                "ffaDeathTitle" => [
                    0 => "§l§cВАС УБИЛИ",
                    1 => "§e%s"
                ],
                "serverRestartTitle" => [
                    0 => "§l§aПерезагрузка",
                    1 => "%s"
                ],
                "gamesForm" => [
                    0 => "Выбор режима",
                    1 => "§fВыберите один из наших §aрежимов §fдля игры!",
                    2 => "§2Открытые арены\n§8Играют: §e%s"
                ],
                "ffaForm" => [
                    0 => "Открытые арены",
                    1 => "§cNoDebuff\n§8Играют: §e%s",
                    2 => "§7Soup\n§8Играют: §e%s",
                    3 => "§aSumo\n§8Играют: §e%s",
                    4 => "§6Fist\n§8Играют: §e%s",
                    5 => "§eGApple\n§8Играют: §e%s",
                    6 => "§4Resistance\n§8Играют: §e%s",
                    7 => "§bCombo\n§8Играют: §e%s",
                    8 => "§8Вернуться назад\n§7Нажмите, чтобы вернуться назад"
                ],
                "preferencesForm" => [
                    0 => "Настройки",
                    1 => "Язык\n§7Выберите язык",
                    2 => "Утилиты\n§7Включите или отключите функцию",
                    3 => "Косметика\n§7Измените свой внешний вид"
                ],
                "languageForm" => [
                    0 => "Выбор языка",
                    1 => "Английский\n§7Нажмите, чтобы выбрать",
                    2 => "Русский\n§aВыбран",
                    3 => "Вернуться назад\n§7Нажмите, чтобы вернуться назад"
                ],
                "languageConfirmationForm" => [
                    0 => "Подтвердите выбор языка",
                    1 => "§fВы хотите выбрать §e%s §fязык?",
                    2 => "Да",
                    3 => "Нет"
                ],
                "togglesForm" => [
                    0 => "Утилиты",
                    1 => "Основные\n§7Измените свои основные настройки",
                    2 => "Открытые арены\n§7Измените свои настройки открытых арен",
                    3 => "Вернуться назад\n§7Нажмите, чтобы вернуться назад",
                ],
                "generalTogglesForm" => [
                    0 => "Основные настройки",
                    1 => "Scoreboard (Статус-бар справа)",
                    2 => "Счётчик кликов в секунду",
                    3 => "Авто-бег",
                    4 => "Молния после убийства"
                ],
                "ffaTogglesForm" => [
                    0 => "Настройки открытых арен",
                    1 => "Скрывать игроков в бою",
                    2 => "Возрождение на арене"
                ],
                "cosmeticsForm" => [
                    0 => "Косметика",
                    1 => "Плащи\n§7Выберите свой плащ",
                    2 => "Теги\n§7Выберите свой тег",
                    3 => "Полёт\n§7Включите режим полёта",
                    4 => "Цвет зелий\n§7Выберите свой цвет зелий",
                    5 => "Вернуться назад\n§7Нажмите, чтобы вернуться назад"
                ],
                "capesForm" => [
                    0 => "Плащи",
                    1 => "§fВаш плащ: §e%s",
                    2 => "§8Все плащи\n§7Выберите плащ",
                    3 => "§cУбрать плащ\n§7Нажмите, чтобы убрать плащ",
                    4 => "§8Вернуться назад\n§7Нажмите, чтобы вернуться назад"
                ],
                "capesSelectionForm" => [
                    0 => "Все плащи",
                    1 => "§aAntralia\n§7Нажмите, чтобы выбрать",
                    2 => "§4Lunarelly\n§7Нажмите, чтобы выбрать",
                    3 => "§dДень рождения\n§7Нажмите, чтобы выбрать",
                    4 => "§bТорт\n§7Нажмите, чтобы выбрать",
                    5 => "§5Странник края\n§7Нажмите, чтобы выбрать",
                    6 => "§6Феерверк\n§7Нажмите, чтобы выбрать",
                    7 => "§8Железный голем\n§7Нажмите, чтобы выбрать",
                    8 => "§9Кирка\n§7Нажмите, чтобы выбрать",
                    9 => "§2Зелёный крипер\n§7Нажмите, чтобы выбрать",
                    10 => "§cКрасный крипер\n§7Нажмите, чтобы выбрать",
                    11 => "§2Черепаха\n§7Нажмите, чтобы выбрать",
                    12 => "§cМигратор\n§7Нажмите, чтобы выбрать",
                    13 => "§8Вернуться назад\n§7Нажмите, чтобы вернуться назад"
                ],
                "tagsForm" => [
                    0 => "Теги",
                    1 => "Ваш тег: %s",
                    2 => "§fСеребряные теги\n§7Выберите серебряный тег",
                    3 => "§6Золотые теги\n§7Выберите золотой тег",
                    4 => "§bПлатиновые теги\n§7Выберите платиновый тег",
                    5 => "§cУбрать тег\n§7Нажмите, чтобы убрать тег",
                    6 => "§8Вернуться назад\n§7Нажмите, чтобы вернуться назад"
                ],
                "silverTagsForm" => [
                    0 => "Серебряные теги",
                    1 => "§dE-GIRL\n§7Нажмите, чтобы выбрать",
                    2 => "§cBESTWW\n§7Нажмите, чтобы выбрать",
                    3 => "§6GOD\n§7Нажмите, чтобы выбрать",
                    4 => "§eLIT\n§7Нажмите, чтобы выбрать",
                    5 => "§dLUNAR\n§7Нажмите, чтобы выбрать",
                    6 => "§7STARDUST\n§7Нажмите, чтобы выбрать",
                    7 => "§8CHOPPA\n§7Нажмите, чтобы выбрать",
                    8 => "§fCLOUTLORD\n§7Нажмите, чтобы выбрать",
                    9 => "§8Вернуться назад\n§7Нажмите, чтобы вернуться назад"
                ],
                "goldenTagsForm" => [
                    0 => "Золотые теги",
                    1 => "§aANTRALIA\n§7Нажмите, чтобы выбрать",
                    2 => "§bFINESSE\n§7Нажмите, чтобы выбрать",
                    3 => "§cMEMPHIS\n§7Нажмите, чтобы выбрать",
                    4 => "§5LEANDOER\n§7Нажмите, чтобы выбрать",
                    5 => "§2JUGG\n§7Нажмите, чтобы выбрать",
                    6 => "§gCAPYBARA\n§7Нажмите, чтобы выбрать",
                    7 => "§3SHOOTA\n§7Нажмите, чтобы выбрать",
                    8 => "§6L\n§7Нажмите, чтобы выбрать",
                    9 => "§4W\n§7Нажмите, чтобы выбрать",
                    10 => "§8Вернуться назад\n§7Нажмите, чтобы вернуться назад"
                ],
                "platinumTagsForm" => [
                    0 => "Платиновые теги",
                    1 => "§cSANTA\n§7Нажмите, чтобы выбрать",
                    2 => "§dTRIPPY\n§7Нажмите, чтобы выбрать",
                    3 => "§4MAFIA\n§7Нажмите, чтобы выбрать",
                    4 => "§3ALCOHOLIC\n§7Нажмите, чтобы выбрать",
                    5 => "§bBLATANT\n§7Нажмите, чтобы выбрать",
                    6 => "§eJUICY\n§7Нажмите, чтобы выбрать",
                    7 => "§6OG\n§7Нажмите, чтобы выбрать",
                    8 => "§gBROKE\n§7Нажмите, чтобы выбрать",
                    9 => "§2INDIAN\n§7Нажмите, чтобы выбрать",
                    10 => "§5GOAT\n§7Нажмите, чтобы выбрать",
                    11 => "§8Вернуться назад\n§7Нажмите, чтобы вернуться назад"
                ],
                "flyForm" => [
                    0 => "Полёт",
                    1 => "Полёт: %s",
                    2 => "§aВключить полёт\n§7Включить режим полёта",
                    3 => "§cВыключить полёт\n§7Выключить режим полёта",
                    4 => "§8Вернуться назад\n§7Нажмите, чтобы вернуться назад"
                ],
                "potionColorForm" => [
                    0 => "Цвет зелий",
                    1 => "Цвет зелий: %s",
                    2 => "§8Цвета зелий\n§7Выберите цвет зелий",
                    3 => "§cОтключить цвет зелий\n§7Отключите свой цвет зелий",
                    4 => "§8Вернуться назад\n§7Нажмите, чтобы вернуться назад"
                ],
                "potionColorSelectionForm" => [
                    0 => "Цвета зелий",
                    1 => "§cКрасный\n§7Нажмите, чтобы выбрать",
                    2 => "§4Тёмно-красный\n§7Нажмите, чтобы выбрать",
                    3 => "§9Синий\n§7Нажмите, чтобы выбрать",
                    4 => "§bГолубой\n§7Нажмите, чтобы выбрать",
                    5 => "§aЗелёный\n§7Нажмите, чтобы выбрать",
                    6 => "§dФиолетовый\n§7Нажмите, чтобы выбрать",
                    7 => "§eЖёлтый\n§7Нажмите, чтобы выбрать",
                    8 => "§fБелый\n§7Нажмите, чтобы выбрать",
                    9 => "§0Чёрный\n§7Нажмите, чтобы выбрать",
                    10 => "§8Вернуться назад\n§7Нажмите, чтобы вернуться назад"
                ],
                "statisticsForm" => [
                    0 => "Статистика",
                    1 => "§aВаша статистика:\n\n§fДивизия: %s\n\n§fУбийств: §e%s\n§fСмертей: §e%s\n\n§fУ/С: §e%s\n\n§fВремя в игре: §e%s часов",
                    2 => "Топ по убийствам\n§7Посмотрите, кто убил больше всех"
                ],
                "topKillersForm" => [
                    0 => "Топ по убийствам",
                    1 => "%s%s. §f%s §7(§a%s убийств§7)",
                    2 => "Вернуться назад\n§7Нажмите, чтобы вернуться назад"
                ],
                "menuForm" => [
                    0 => "Меню",
                    1 => "Информация\n§7Посмотреть информацию о сервере",
                    2 => "Правила\n§7Посмотреть правила сервера"
                ],
                "infoForm" => [
                    0 => "Информация",
                    1 => "§aСоциальные сети:\n§fVK: §evk.com/antralia\n§fDiscord: §ediscord.gg/antralia (antralia.net/discord)\n§fTelegram: §et.me/antralia\n\n§aПокупка доната (привилегий):\n§fМагазин: §eantralia.net (store.antralia.net)\n\n§7Если вы не можете оплатить в магазине или хотите оплатить криптовалютой, свяжитесь с владельцами.\n\n§cСделал Lunarelly для Antralia с любовью. <3",
                    2 => "§8Вернуться назад\n§7Нажмите, чтобы вернуться назад"
                ],
                "rulesForm" => [
                    0 => "Правила",
                    1 => "§a1. Игровой процесс:\n§e1.1 §fЗапрещено использовать любые виды программного обеспечения, дающие вам преимущество - блокировка навсегда.\n§e1.2 §fЗапрещено использование любых прокси, VPN - блокировка навсегда. §7(могут быть исключения)\n§e1.3 §fОтказ от проверки на использование запрещённого программного обеспечения приводит к блокировке навсегда.\n§e1.4 §fЗапрещено использовать баги сервера/клиента, дающие вам преимущество перед другими игроками - блокировка на 1 день.\n§e1.5 §fЗапрещён тим на аренах - кик §7(1/3)§f, далее - блокировка на 1 день.\n§e1.6 §fЗапрещено передавать/продавать свой аккаунт третьим лицам - блокировка навсегда и снятие привилегии.\n§e1.7 §fЗапрещено вмешиваться в чужую игру - кик §7(1/3)§f, далее - блокировка на 1 день.\n§e1.8 §fПользовательские 4D модели §7(не из магазина)§f, которые больше/меньше стандартной - кик, далее - блокировка на 1 день.\n§e1.9 §fНекорректные или заведомо ложные жалобы запрещены - кик, далее - блокировка на 1 день.\n§e1.10 §fЗапрещены некорректные (оскорбительные) ники — блокировка навсегда.\n§e1.11 §fЗапрещено ударять игрока и намеренно бегать от него по всей карте - кик §7(1/3)§f, далее - бан на 1 день.\n\n§a2. Игровой чат:\n§e2.1 §fЗапрещено оскорблять других игроков §7(L, ez и подобные не учитываются) §f- кик §7(1/3)§f, далее - блокировка чата на 1 день.\n§e2.2 §fЗапрещено оскорблять администрацию сервера §7(L, ez и подобные не учитываются) §f- блокировка чата на 2 дня.\n§e2.3 §fЗапрещено угнетение по национальности человека - блокировка чата на 1 день.\n§e2.4 §fЗапрещено спамить/флудить - блокировка чата на 1 день.\n§e2.5 §fЗапрещено рекламировать сторонние сервера - блокировка чата навсегда.\n§e2.6 §fЗапрещено оскорблять проект - блокировка чата на 1 неделю.\n\n§eПокупка разблокировки: §aantralia.net",
                    2 => "§8Вернуться назад\n§7Нажмите, чтобы вернуться назад"
                ],
                "hubItems" => [
                    0 => "§r§aРежимы\n§7Зажмите предмет",
                    1 => "§r§aНастройки\n§7Зажмите предмет",
                    2 => "§r§aСтатистика\n§7Зажмите предмет"
                ],
                "spectatorItems" => [
                    0 => "§r§aТелепортироваться к подозреваемому\n§7Зажмите предмет",
                    1 => "§r§aЗаморозить подозреваемого\n§7Зажмите предмет",
                    2 => "§r§cРазморозить подозреваемого\n§7Зажмите предмет",
                    3 => "§r§aВыйти из наблюдения\n§7Зажмите предмет"
                ],
                "hubFloatingText" => [
                    0 => "§0 \n§l§aAntralia Network",
                    1 => "\n§1\n§eНовые режимы уже здесь!\n§2\n§aantralia.net\n§3 "
                ],
                "hubScoreboard" => [
                    0 => "§l§aAntralia§r",
                    1 => "§0",
                    2 => " §fРанг: %s",
                    3 => " §fДивизия: %s",
                    4 => "§1",
                    5 => " §fОнлайн: §a%s",
                    6 => " §fИграют: §a%s",
                    7 => "§2",
                    8 => " §7antralia.net"
                ],
                "ffaScoreboard" => [
                    0 => "§l§aAntralia§r",
                    1 => "§0",
                    2 => " §fВаш пинг: §a%sмс",
                    3 => " §fПинг противника: §a%sмс",
                    4 => "§1",
                    5 => " §fБой: §a%sс",
                    6 => "§2",
                    7 => " §7antralia.net"
                ],
                default => "Неизвестное сообщение"
            };
        } else {
            return "Unknown language";
        }
    }

    /**
     * @param string $locale
     * @param string $message
     * @return string
     */
    public function translateBan(string $locale, string $message): string
    {
        if ($locale === "en") {
            return match ($message) {
                "banExpiry" => "%s days, %s hours, %s minutes",
                "banNeverExpires" => "never",
                "banKick" => "§cYou have been banned! §7(%s, %s)\n\n§fReason: §c%s §7| §fUnban: §c%s\n§fAppeal: §adiscord.gg/antralia",
                default => "Unknown message"
            };
        } elseif ($locale === "ru") {
            return match ($message) {
                "banExpiry" => "%s дней, %s часов, %s минут",
                "banNeverExpires" => "никогда",
                "banKick" => "§cВы были забанены! §7(%s, %s)\n\n§fПричина: §c%s §7| §fРазбан: §c%s\n§fОспорить: §avk.me/antralia",
                default => "Неизвестное сообщение"
            };
        } else {
            return "Unknown language";
        }
    }

    /**
     * @param PracticePlayer $player
     * @param string $message
     * @param bool $colored
     * @return string
     */
    public function translateCape(PracticePlayer $player, string $message, bool $colored = false): string
    {
        if ($this->plugin->getLanguageManager()->getLanguage($player) === "en") {
            if ($colored) {
                return match ($message) {
                    "Antralia" => "§aAntralia",
                    "Lunarelly" => "§4Lunarelly",
                    "Birthday" => "§dBirthday",
                    "Cake" => "§bCake",
                    "Enderman" => "§5Enderman",
                    "Firework" => "§6Firework",
                    "Iron_Golem" => "§8Iron Golem",
                    "Pickaxe" => "§9Pickaxe",
                    "Green_Creeper" => "§2Green Creeper",
                    "Red_Creeper" => "§cRed Creeper",
                    "Turtle" => "§2Turtle",
                    "Migrator" => "§cMigrator",
                    default => "-"
                };
            } else {
                return match ($message) {
                    "Antralia" => "Antralia",
                    "Lunarelly" => "Lunarelly",
                    "Birthday" => "Birthday",
                    "Cake" => "Cake",
                    "Enderman" => "Enderman",
                    "Firework" => "Firework",
                    "Iron_Golem" => "Iron Golem",
                    "Pickaxe" => "Pickaxe",
                    "Green_Creeper" => "Green Creeper",
                    "Red_Creeper" => "Red Creeper",
                    "Turtle" => "Turtle",
                    "Migrator" => "Migrator",
                    default => "-"
                };
            }
        } elseif ($this->plugin->getLanguageManager()->getLanguage($player) === "ru") {
            if ($colored) {
                return match ($message) {
                    "Antralia" => "§aAntralia",
                    "Lunarelly" => "§4Lunarelly",
                    "Birthday" => "§dДень рождения",
                    "Cake" => "§bТорт",
                    "Enderman" => "§5Странник края",
                    "Firework" => "§6Феерверк",
                    "Iron_Golem" => "§8Железный голем",
                    "Pickaxe" => "§9Кирка",
                    "Green_Creeper" => "§2Зелёный крипер",
                    "Red_Creeper" => "§cКрасный крипер",
                    "Turtle" => "§2Черепаха",
                    "Migrator" => "§cМигратор",
                    default => "-"
                };
            } else {
                return match ($message) {
                    "Antralia" => "Antralia",
                    "Lunarelly" => "Lunarelly",
                    "Birthday" => "День рождения",
                    "Cake" => "Торт",
                    "Enderman" => "Странник края",
                    "Firework" => "Феерверк",
                    "Iron_Golem" => "Железный голем",
                    "Pickaxe" => "Кирка",
                    "Green_Creeper" => "Зелёный крипер",
                    "Red_Creeper" => "Красный крипер",
                    "Turtle" => "Черепаха",
                    "Migrator" => "Мигратор",
                    default => "-"
                };
            }
        } else {
            return "Unknown language";
        }
    }

    /**
     * @param PracticePlayer $player
     * @param string $message
     * @return string
     */
    public function translateLanguage(PracticePlayer $player, string $message): string
    {
        if ($this->plugin->getLanguageManager()->getLanguage($player) === "en") {
            return match ($message) {
                "en" => "English",
                "ru" => "Russian",
                default => "Unknown message"
            };
        } elseif ($this->plugin->getLanguageManager()->getLanguage($player) === "ru") {
            return match ($message) {
                "en" => "Английский",
                "ru" => "Русский",
                default => "Неизвестное сообщение"
            };
        } else {
            return "Unknown language";
        }
    }

    /**
     * @param PracticePlayer $player
     * @param string $message
     * @return string
     */
    public function translateInputMode(PracticePlayer $player, string $message): string
    {
        if ($this->plugin->getLanguageManager()->getLanguage($player) === "en") {
            return match ($message) {
                "Keyboard & Mouse" => "Keyboard & Mouse",
                "Gamepad" => "Gamepad",
                "Touch" => "Touch",
                "Motion" => "Motion",
                default => "Unknown message"
            };
        } elseif ($this->plugin->getLanguageManager()->getLanguage($player) === "ru") {
            return match ($message) {
                "Keyboard & Mouse" => "Клавиатура и Мышь",
                "Gamepad" => "Геймпад",
                "Touch" => "Тач-скрин",
                "Motion" => "Движения",
                default => "Неизвестное сообщение"
            };
        } else {
            return "Unknown language";
        }
    }

    /**
     * @param string $locale
     * @param string $message
     * @return string
     */
    public function translateAntiCheat(string $locale, string $message): string
    {
        if ($locale === "en") {
            return match ($message) {
                "loginError" => "Login error (%s)\nCode: %s",
                "inGameError" => "In-game error (%s)\nCode: %s",
                default => "Unknown message"
            };
        } elseif ($locale === "ru") {
            return match ($message) {
                "loginError" => "Ошибка входа (%s)\nКод: %s",
                "inGameError" => "Игровая ошибка (%s)\nКод: %s",
                default => "Неизвестное сообщение"
            };
        } else {
            return "Unknown language";
        }
    }

    /**
     * @param PracticePlayer $player
     * @param string $message
     * @param bool $colored
     * @return string
     */
    public function translatePotionColor(PracticePlayer $player, string $message, bool $colored = false): string
    {
        if ($this->plugin->getLanguageManager()->getLanguage($player) === "en") {
            if ($colored) {
                return match ($message) {
                    "Red" => "§cRed",
                    "Dark_Red" => "§4Dark Red",
                    "Blue" => "§9Blue",
                    "Light_Blue" => "§bLight Blue",
                    "Green" => "§aGreen",
                    "Purple" => "§dPurple",
                    "Yellow" => "§eYellow",
                    "White" => "§fWhite",
                    "Black" => "§0Black",
                    default => "§7-"
                };
            } else {
                return match ($message) {
                    "Red" => "Red",
                    "Dark_Red" => "Dark Red",
                    "Blue" => "Blue",
                    "Light_Blue" => "Light Blue",
                    "Green" => "Green",
                    "Purple" => "Purple",
                    "Yellow" => "Yellow",
                    "White" => "White",
                    "Black" => "Black",
                    default => "-"
                };
            }
        } elseif ($this->plugin->getLanguageManager()->getLanguage($player) === "ru") {
            if ($colored) {
                return match ($message) {
                    "Red" => "§cКрасный",
                    "Dark_Red" => "§4Тёмно-красный",
                    "Blue" => "§9Синий",
                    "Light_Blue" => "§bГолубой",
                    "Green" => "§aЗелёный",
                    "Purple" => "§dФиолетовый",
                    "Yellow" => "§eЖёлтый",
                    "White" => "§fБелый",
                    "Black" => "§0Чёрный",
                    default => "§7-"
                };
            } else {
                return match ($message) {
                    "Red" => "Красный",
                    "Dark_Red" => "Тёмно-красный",
                    "Blue" => "Синий",
                    "Light_Blue" => "Голубой",
                    "Green" => "Зелёный",
                    "Purple" => "Фиолетовый",
                    "Yellow" => "Жёлтый",
                    "White" => "Белый",
                    "Black" => "Чёрный",
                    default => "-"
                };
            }
        } else {
            return "Unknown language";
        }
    }
}