<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\player\cooldown;

use antralia\practice\player\PracticePlayer;
use antralia\practice\PracticePlugin;
use pocketmine\scheduler\Task;

final class CooldownTask extends Task
{

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @return void
     */
    public function onRun(): void
    {
        $cooldownManager = $this->plugin->getCooldownManager();
        foreach ($cooldownManager->getEnderPearlCooldowns() as $nickname => $time) {
            $player = $this->plugin->getServer()->getPlayerExact($nickname);

            if (!($player instanceof PracticePlayer)) {
                continue;
            }

            if (!($player->isConnected())) {
                continue;
            }

            if ($time <= 0) {
                if ($cooldownManager->hasEnderPearlCooldown($player)) {
                    $cooldownManager->removeEnderPearlCooldown($player);
                    $player->sendActionBarMessage($this->plugin->getTranslationManager()->translate($player, "enderPearlCooldownEnded"));
                }
                $player->getXpManager()->setXpAndProgress(0, 0);
            } else {
                $player->getXpManager()->setXpAndProgress(intval(($time / 20) + 0.9), floatval($time / CooldownManager::ENDER_PEARL_COOLDOWN));
                $cooldownManager->decreaseEnderPearlCooldown($player);
            }
        }
    }
}
