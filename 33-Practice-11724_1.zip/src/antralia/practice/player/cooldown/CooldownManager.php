<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\player\cooldown;

use antralia\practice\player\PracticePlayer;
use antralia\practice\PracticePlugin;

final class CooldownManager
{

    /**
     * In ticks.
     *
     * @var int
     */
    public const ENDER_PEARL_COOLDOWN = 300;

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @var array
     */
    private array $enderPearlCooldowns = array();

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @param PracticePlayer $player
     * @return int
     */
    public function getEnderPearlCooldown(PracticePlayer $player): int
    {
        return $this->enderPearlCooldowns[$player->getName()] ?? 0;
    }

    /**
     * @return array
     */
    public function getEnderPearlCooldowns(): array
    {
        return $this->enderPearlCooldowns;
    }

    /**
     * @param PracticePlayer $player
     * @return bool
     */
    public function hasEnderPearlCooldown(PracticePlayer $player): bool
    {
        return isset($this->enderPearlCooldowns[$player->getName()]);
    }

    /**
     * @param PracticePlayer $player
     * @param int $time
     * @return void
     */
    public function setEnderPearlCooldown(PracticePlayer $player, int $time = self::ENDER_PEARL_COOLDOWN): void
    {
        $this->enderPearlCooldowns[$player->getName()] = $time;
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function decreaseEnderPearlCooldown(PracticePlayer $player): void
    {
        $this->enderPearlCooldowns[$player->getName()]--;
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function removeEnderPearlCooldown(PracticePlayer $player): void
    {
        if (isset($this->enderPearlCooldowns[$player->getName()])) {
            $player->getXpManager()->setXpAndProgress(0, 0);
            unset($this->enderPearlCooldowns[$player->getName()]);
        }
    }
}