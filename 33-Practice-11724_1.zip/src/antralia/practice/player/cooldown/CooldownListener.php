<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\player\cooldown;

use antralia\practice\item\PracticeEnderPearlItem;
use antralia\practice\player\PracticePlayer;
use antralia\practice\PracticePlugin;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerItemUseEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\player\GameMode;

final class CooldownListener implements Listener
{

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @param PlayerItemUseEvent $event
     * @return void
     */
    public function handlePlayerItemUse(PlayerItemUseEvent $event): void
    {
        $player = $event->getPlayer();

        if (!($player instanceof PracticePlayer)) {
            return;
        }

        if ($event->getItem() instanceof PracticeEnderPearlItem) {
            $cooldownManager = $this->plugin->getCooldownManager();

            if ($cooldownManager->hasEnderPearlCooldown($player)) {
                $event->cancel();
                $player->sendActionBarMessage(sprintf($this->plugin->getTranslationManager()->translate($player, "enderPearlCooldownOngoing"), intval(($cooldownManager->getEnderPearlCooldown($player) / 20) + 0.9)));
            } else {
                if (!($player->getGamemode()->equals(GameMode::ADVENTURE()))) {
                    return;
                }
                $cooldownManager->setEnderPearlCooldown($player);
                $player->sendActionBarMessage($this->plugin->getTranslationManager()->translate($player, "enderPearlCooldownStarted"));
            }
        }
    }

    /**
     * @param PlayerQuitEvent $event
     * @return void
     */
    public function handlePlayerQuit(PlayerQuitEvent $event): void
    {
        $player = $event->getPlayer();

        if (!($player instanceof PracticePlayer)) {
            return;
        }

        if ($this->plugin->getCooldownManager()->hasEnderPearlCooldown($player)) {
            $this->plugin->getCooldownManager()->removeEnderPearlCooldown($player);
        }
    }
}