<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\player;

use antralia\practice\exception\PracticeException;
use antralia\practice\PracticePlugin;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerCreationEvent;
use pocketmine\event\player\PlayerLoginEvent;

final class PlayerListener implements Listener
{

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @priority LOWEST
     *
     * @param PlayerCreationEvent $event
     * @return void
     */
    public function handlePlayerCreation(PlayerCreationEvent $event): void
    {
        $event->setPlayerClass(PracticePlayer::class);
    }

    /**
     * @priority LOWEST
     *
     * @param PlayerLoginEvent $event
     * @return void
     */
    public function handlePlayerLogin(PlayerLoginEvent $event): void
    {
        $player = $event->getPlayer();

        if (!($player instanceof PracticePlayer)) {
            throw new PracticeException(sprintf("Player class should be instance of %s, %s given", PracticePlayer::class, $player::class));
        }

        $provider = $this->plugin->getProvider();
        $provider->processNewPlayerData($player);
        $playerData = $provider->getPlayerDataByXuid($player);

        if ($playerData["nickname"] !== $player->getLowerCaseName()) {
            $provider->setPlayerNickname($player);
        }

        if ($playerData["ip"] !== $player->getNetworkSession()->getIp()) {
            $provider->setPlayerIp($player);
        }

        if ($playerData["deviceid"] !== $player->getPlayerInfo()->getExtraData()["DeviceId"]) {
            $provider->setPlayerDeviceId($player);
        }
    }
}