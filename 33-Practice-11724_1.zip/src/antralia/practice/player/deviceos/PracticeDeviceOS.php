<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\player\deviceos;

use pocketmine\network\mcpe\protocol\types\DeviceOS;

final class PracticeDeviceOS
{

    /**
     * @var array
     */
    public const DEVICE_OS_LIST = [
        DeviceOS::ANDROID,
        DeviceOS::IOS,
        DeviceOS::AMAZON,
        DeviceOS::WINDOWS_10,
        DeviceOS::WIN32,
        DeviceOS::PLAYSTATION,
        DeviceOS::NINTENDO,
        DeviceOS::XBOX
    ];
}