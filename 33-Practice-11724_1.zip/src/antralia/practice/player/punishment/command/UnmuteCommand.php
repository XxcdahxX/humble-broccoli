<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\player\punishment\command;

use antralia\core\rcon\RconCommandSender;
use antralia\practice\command\CommandArgs;
use antralia\practice\command\PracticeCommand;
use antralia\practice\player\PracticePlayer;
use antralia\practice\PracticePlugin;
use antralia\practice\utils\PracticeUtils;
use pocketmine\command\CommandSender;
use pocketmine\network\mcpe\protocol\AvailableCommandsPacket;
use pocketmine\utils\TextFormat;

final class UnmuteCommand extends PracticeCommand
{

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;

        $this->setPermission("practice.command.unmute");
        $this->commandArg = new CommandArgs();
        $this->commandArg->addParameter(0, "player", AvailableCommandsPacket::ARG_TYPE_TARGET);

        parent::__construct("unmute", "Unmute a player", "Usage: /unmute <player>");
    }

    /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     * @return bool
     */
    public function execute(CommandSender $sender, string $commandLabel, array $args): bool
    {
        if (!($this->testPermission($sender))) {
            return false;
        }

        if ($sender instanceof PracticePlayer) {
            $translationManager = $this->plugin->getTranslationManager();

            if (empty($args) || !(isset($args[0]))) {
                $sender->sendMessage($translationManager->translate($sender, "unmuteUsage"));
                return true;
            }

            $nickname = PracticeUtils::filterStringForSQL(strtolower($args[0]));

            if ($player = PracticeUtils::getPlayerByPrefix($nickname)) {
                $nickname = $player->getName();
            }

            $punishmentManager = $this->plugin->getPunishmentManager();
            $translationManager = $this->plugin->getTranslationManager();

            if (!($this->plugin->getProvider()->isPlayerRegisteredByNickname($nickname))) {
                $sender->sendMessage($translationManager->translate($sender, "playerNotRegistered"));
                return true;
            }

            if (!($punishmentManager->isMutedByNickname($nickname))) {
                $sender->sendMessage($translationManager->translate($sender, "playerNotMuted"));
                return true;
            }

            if ($sender->getLowerCaseName() === $nickname) {
                $sender->sendMessage($translationManager->translate($sender, "unmuteSelf"));
                return true;
            }

            $punishmentManager->removeMuteByNickname($nickname, $sender->getName());
            $sender->sendMessage(sprintf($translationManager->translate($sender, "successfulUnmute"), $nickname));
        } else {
            if (empty($args) || !(isset($args[0]))) {
                $sender->sendMessage($this->usageMessage);
                return true;
            }

            $nickname = PracticeUtils::filterStringForSQL(strtolower($args[0]));
            $punishmentManager = $this->plugin->getPunishmentManager();

            if (!($sender instanceof RconCommandSender)) {
                if ($player = PracticeUtils::getPlayerByPrefix($nickname)) {
                    $nickname = $player->getName();
                }
            }

            if (!($this->plugin->getProvider()->isPlayerRegisteredByNickname($nickname))) {
                $sender->sendMessage(TextFormat::RED . "Player is not registered!");
                return true;
            }

            if (!($punishmentManager->isMutedByNickname($nickname))) {
                $sender->sendMessage(TextFormat::RED . "Player is not muted!");
                return true;
            }

            $punishmentManager->removeMuteByNickname($nickname, $sender->getName());
            $sender->sendMessage(sprintf(TextFormat::GREEN . "You have successfully unmuted: %s", $nickname));
        }
        return true;
    }

    /**
     * @param PracticePlayer $player
     * @return string
     */
    public function getDescriptionForPlayer(PracticePlayer $player): string
    {
        return $this->plugin->getTranslationManager()->translate($player, "unmuteCommandDescription");
    }
}