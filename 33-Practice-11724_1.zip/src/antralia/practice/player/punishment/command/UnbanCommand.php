<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\player\punishment\command;

use antralia\practice\command\CommandArgs;
use antralia\practice\command\PracticeCommand;
use antralia\practice\player\PracticePlayer;
use antralia\practice\PracticePlugin;
use antralia\practice\utils\PracticeUtils;
use pocketmine\command\CommandSender;
use pocketmine\network\mcpe\protocol\AvailableCommandsPacket;
use pocketmine\utils\TextFormat;

final class UnbanCommand extends PracticeCommand
{

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;

        $this->setPermission("practice.command.unban");
        $this->commandArg = new CommandArgs();
        $this->commandArg->addParameter(0, "player", AvailableCommandsPacket::ARG_TYPE_STRING);

        parent::__construct("unban", "Unban a player", "Usage: /unban <player>");
    }

    /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     * @return bool
     */
    public function execute(CommandSender $sender, string $commandLabel, array $args): bool
    {
        if (!($this->testPermission($sender))) {
            return false;
        }

        if ($sender instanceof PracticePlayer) {
            $translationManager = $this->plugin->getTranslationManager();

            if (empty($args) || !(isset($args[0]))) {
                $sender->sendMessage($translationManager->translate($sender, "unbanUsage"));
                return true;
            }

            $nickname = PracticeUtils::filterStringForSQL(strtolower($args[0]));

            $punishmentManager = $this->plugin->getPunishmentManager();
            $translationManager = $this->plugin->getTranslationManager();

            if (!($punishmentManager->isBannedByNickname($nickname))) {
                $sender->sendMessage($translationManager->translate($sender, "playerNotBanned"));
                return true;
            }

            $punishmentManager->removeBanByNickname($nickname, $sender->getName());
            $sender->sendMessage(sprintf($translationManager->translate($sender, "successfulUnban"), $nickname));
        } else {
            if (empty($args) || !(isset($args[0]))) {
                $sender->sendMessage($this->usageMessage);
                return true;
            }

            $nickname = PracticeUtils::filterStringForSQL(strtolower($args[0]));
            $punishmentManager = $this->plugin->getPunishmentManager();

            if (!($punishmentManager->isBannedByNickname($nickname))) {
                $sender->sendMessage(TextFormat::RED . "Player is not banned!");
                return true;
            }

            $punishmentManager->removeBanByNickname($nickname, $sender->getName());
            $sender->sendMessage(sprintf(TextFormat::GREEN . "You have successfully unbanned: %s", $nickname));
        }
        return true;
    }

    /**
     * @param PracticePlayer $player
     * @return string
     */
    public function getDescriptionForPlayer(PracticePlayer $player): string
    {
        return $this->plugin->getTranslationManager()->translate($player, "unbanCommandDescription");
    }
}