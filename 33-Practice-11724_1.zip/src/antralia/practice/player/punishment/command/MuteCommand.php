<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\player\punishment\command;

use antralia\core\rcon\RconCommandSender;
use antralia\practice\command\CommandArgs;
use antralia\practice\command\PracticeCommand;
use antralia\practice\player\PracticePlayer;
use antralia\practice\player\punishment\PunishmentManager;
use antralia\practice\player\rank\RankManager;
use antralia\practice\PracticePlugin;
use antralia\practice\utils\PracticeUtils;
use pocketmine\command\CommandSender;
use pocketmine\network\mcpe\protocol\AvailableCommandsPacket;
use pocketmine\utils\TextFormat;

final class MuteCommand extends PracticeCommand
{

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;

        $this->setPermission("practice.command.mute");
        $this->commandArg = new CommandArgs();
        $this->commandArg->addParameter(0, "player", AvailableCommandsPacket::ARG_TYPE_TARGET);
        $this->commandArg->addParameter(0, "time", AvailableCommandsPacket::ARG_TYPE_INT);
        $this->commandArg->addParameter(0, "reason");

        parent::__construct("mute", "Mute a player", "Usage: /mute <player> <time (0 - forever)> <reason>");
    }

    /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     * @return bool
     */
    public function execute(CommandSender $sender, string $commandLabel, array $args): bool
    {
        if (!($this->testPermission($sender))) {
            return false;
        }

        if ($sender instanceof PracticePlayer) {
            $translationManager = $this->plugin->getTranslationManager();
            $punishmentManager = $this->plugin->getPunishmentManager();

            if (empty($args) || !(isset($args[0])) || !(isset($args[1])) || !(isset($args[2]))) {
                $sender->sendMessage($translationManager->translate($sender, "muteUsage"));
                return true;
            }

            $nickname = PracticeUtils::filterStringForSQL(strtolower($args[0]));
            $time = (int) $args[1];

            if (!(is_numeric($args[1])) || $time < 0 || $time > PunishmentManager::MAX_MUTE_TIME) {
                $sender->sendMessage($translationManager->translate($sender, "invalidMuteTime"));
                return true;
            }

            $target = PracticeUtils::getPlayerByPrefix($args[0]);

            unset($args[0], $args[1]);
            $reason = PracticeUtils::filterStringForSQL(implode(" ", $args));

            if ($target) {
                if (!($target instanceof PracticePlayer)) {
                    return true;
                }

                if ($target->getName() === $sender->getName()) {
                    $sender->sendMessage($translationManager->translate($sender, "selfMute"));
                    return true;
                }

                if ($punishmentManager->isMutedByNickname($target->getName()) || $punishmentManager->isMutedByXuid($target)) {
                    $sender->sendMessage($translationManager->translate($sender, "playerAlreadyMuted"));
                    return true;
                }

                if ($sender->getRankPriority() <= $target->getRankPriority()) {
                    $sender->sendMessage($translationManager->translate($sender, "playerCannotBeMuted"));
                    return true;
                }

                $punishmentManager->addMute($target, $sender->getName(), $time, $reason);

                if ($time === 0) {
                    $sender->sendMessage(sprintf($translationManager->translate($sender, "successfulForeverMute"), $target->getName(), $reason));
                } else {
                    $sender->sendMessage(sprintf($translationManager->translate($sender, "successfulMute"), $target->getName(), $time, $reason));
                }
            } else {
                if (!($this->plugin->getProvider()->isPlayerRegisteredByNickname($nickname))) {
                    $sender->sendMessage($translationManager->translate($sender, "playerNotRegistered"));
                    return true;
                }

                if ($punishmentManager->isMutedByNickname($nickname)) {
                    $sender->sendMessage($translationManager->translate($sender, "playerAlreadyMuted"));
                    return true;
                }

                if ($sender->getRankPriority() <= $this->plugin->getRankManager()->getRankPriorityByNickname($nickname)) {
                    $sender->sendMessage($translationManager->translate($sender, "playerCannotBeMuted"));
                    return true;
                }

                $punishmentManager->addMuteOffline($nickname, $sender->getName(), $time, $reason);

                if ($time === 0) {
                    $sender->sendMessage(sprintf($translationManager->translate($sender, "successfulForeverMute"), $nickname, $reason));
                } else {
                    $sender->sendMessage(sprintf($translationManager->translate($sender, "successfulMute"), $nickname, $time, $reason));
                }
            }
            return true;
        } else {
            if (empty($args) || !(isset($args[0])) || !(isset($args[1])) || !(isset($args[2]))) {
                $sender->sendMessage($this->usageMessage);
                return true;
            }

            $nickname = PracticeUtils::filterStringForSQL(strtolower($args[0]));
            $time = (int) $args[1];

            if (!(is_numeric($args[1])) || $time < 0 || $time > PunishmentManager::MAX_MUTE_TIME) {
                $sender->sendMessage(TextFormat::RED . "Invalid time format!");
                return true;
            }

            $target = PracticeUtils::getPlayerByPrefix($args[0]);
            $punishmentManager = $this->plugin->getPunishmentManager();
            $rankManager = $this->plugin->getRankManager();

            unset($args[0], $args[1]);
            $reason = PracticeUtils::filterStringForSQL(implode(" ", $args));

            if ($target) {
                if (!($target instanceof PracticePlayer)) {
                    return false;
                }

                if ($punishmentManager->isMutedByNickname($target->getName()) || $punishmentManager->isMutedByXuid($target)) {
                    $sender->sendMessage(TextFormat::RED . "Player is already muted!");
                    return true;
                }

                if ($sender instanceof RconCommandSender) {
                    if ($target->getRank() === RankManager::OWNER_RANK || $target->getRank() === RankManager::STAFF_RANK) {
                        $sender->sendMessage(TextFormat::RED . "You can't mute this player!");
                        return true;
                    }
                }

                $punishmentManager->addMute($target, $sender->getName(), $time, $reason);

                if ($time === 0) {
                    $sender->sendMessage(sprintf(TextFormat::GREEN . "You have permanently muted %s with reason: %s", $target->getName(), $reason));
                } else {
                    $sender->sendMessage(sprintf(TextFormat::GREEN . "You have muted %s for %s days with reason: %s", $target->getName(), $time, $reason));
                }
            } else {
                if (!($this->plugin->getProvider()->isPlayerRegisteredByNickname($nickname))) {
                    $sender->sendMessage(TextFormat::RED . "Player is not registered!");
                    return true;
                }

                if ($punishmentManager->isMutedByNickname($nickname)) {
                    $sender->sendMessage(TextFormat::RED . "Player is already muted!");
                    return true;
                }

                if ($sender instanceof RconCommandSender) {
                    if ($rankManager->getRankByNickname($nickname) === RankManager::OWNER_RANK || $rankManager->getRankByNickname($nickname) === RankManager::STAFF_RANK) {
                        $sender->sendMessage(TextFormat::RED . "You can't mute this player!");
                        return true;
                    }
                }

                $punishmentManager->addMuteOffline($nickname, $sender->getName(), $time, $reason);

                if ($time === 0) {
                    $sender->sendMessage(sprintf(TextFormat::GREEN . "You have permanently muted %s with reason: %s", $nickname, $reason));
                } else {
                    $sender->sendMessage(sprintf(TextFormat::GREEN . "You have muted %s for %s days with reason: %s", $nickname, $time, $reason));
                }
            }
        }
        return true;
    }

    /**
     * @param PracticePlayer $player
     * @return string
     */
    public function getDescriptionForPlayer(PracticePlayer $player): string
    {
        return $this->plugin->getTranslationManager()->translate($player, "muteCommandDescription");
    }
}