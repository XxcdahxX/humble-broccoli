<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\player\punishment\command;

use antralia\core\rcon\RconCommandSender;
use antralia\practice\command\CommandArgs;
use antralia\practice\command\PracticeCommand;
use antralia\practice\player\PracticePlayer;
use antralia\practice\player\punishment\PunishmentManager;
use antralia\practice\player\rank\RankManager;
use antralia\practice\PracticePlugin;
use antralia\practice\utils\PracticeUtils;
use pocketmine\command\CommandSender;
use pocketmine\network\mcpe\protocol\AvailableCommandsPacket;
use pocketmine\utils\TextFormat;

final class BanCommand extends PracticeCommand
{

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;

        $this->setPermission("practice.command.ban");
        $this->commandArg = new CommandArgs();
        $this->commandArg->addParameter(0, "player", AvailableCommandsPacket::ARG_TYPE_TARGET);
        $this->commandArg->addParameter(0, "time", AvailableCommandsPacket::ARG_TYPE_INT);
        $this->commandArg->addParameter(0, "reason");

        parent::__construct("ban", "Ban a player", "Usage: /ban <player> <time (0 - forever)> <reason>");
    }

    /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     * @return bool
     */
    public function execute(CommandSender $sender, string $commandLabel, array $args): bool
    {
        if (!($this->testPermission($sender))) {
            return false;
        }

        if ($sender instanceof PracticePlayer) {
            $translationManager = $this->plugin->getTranslationManager();
            $punishmentManager = $this->plugin->getPunishmentManager();
            $rankManager = $this->plugin->getRankManager();

            if (empty($args) || !(isset($args[0])) || !(isset($args[1])) || !(isset($args[2]))) {
                $sender->sendMessage($translationManager->translate($sender, "banUsage"));
                return true;
            }

            $nickname = PracticeUtils::filterStringForSQL(strtolower($args[0]));
            $time = (int) $args[1];

            if (!(is_numeric($args[1])) || $time < 0 || $time > PunishmentManager::MAX_BAN_TIME) {
                $sender->sendMessage($translationManager->translate($sender, "invalidBanTime"));
                return true;
            }

            $target = PracticeUtils::getPlayerByPrefix($args[0]);

            unset($args[0], $args[1]);
            $reason = PracticeUtils::filterStringForSQL(implode(" ", $args));

            if ($target) {
                if (!($target instanceof PracticePlayer)) {
                    return true;
                }

                if ($target->getName() === $sender->getName()) {
                    $sender->sendMessage($translationManager->translate($sender, "selfBan"));
                    return true;
                }

                if ($punishmentManager->isBannedByNickname($target->getName())) {
                    $sender->sendMessage($translationManager->translate($sender, "playerAlreadyBanned"));
                    return true;
                }

                if ($sender->getRankPriority() <= $target->getRankPriority()) {
                    $sender->sendMessage($translationManager->translate($sender, "playerCannotBeBanned"));
                    return true;
                }

                $punishmentManager->addBan($target, $sender->getName(), $time, $reason);

                if ($time === 0) {
                    $sender->sendMessage(sprintf($translationManager->translate($sender, "successfulForeverBan"), $target->getName(), $reason));
                } else {
                    $sender->sendMessage(sprintf($translationManager->translate($sender, "successfulBan"), $target->getName(), $time, $reason));
                }
            } else {
                if (!($this->plugin->getProvider()->isPlayerRegisteredByNickname($nickname))) {
                    $sender->sendMessage($translationManager->translate($sender, "playerNotRegistered"));
                    return true;
                }

                if ($punishmentManager->isBannedByNickname($nickname)) {
                    $sender->sendMessage($translationManager->translate($sender, "playerAlreadyBanned"));
                    return true;
                }

                if ($sender->getRankPriority() <= $rankManager->getRankPriorityByNickname($nickname)) {
                    $sender->sendMessage($translationManager->translate($sender, "playerCannotBeBanned"));
                    return true;
                }

                $punishmentManager->addBanOffline($nickname, $sender->getName(), $time, $reason);

                if ($time === 0) {
                    $sender->sendMessage(sprintf($translationManager->translate($sender, "successfulForeverBan"), $nickname, $reason));
                } else {
                    $sender->sendMessage(sprintf($translationManager->translate($sender, "successfulBan"), $nickname, $time, $reason));
                }
            }
            return true;
        } else {
            if (empty($args) || !(isset($args[0])) || !(isset($args[1])) || !(isset($args[2]))) {
                $sender->sendMessage($this->usageMessage);
                return true;
            }

            $nickname = PracticeUtils::filterStringForSQL(strtolower($args[0]));
            $time = (int) $args[1];

            if (!(is_numeric($args[1])) || $time < 0 || $time > PunishmentManager::MAX_BAN_TIME) {
                $sender->sendMessage(TextFormat::RED . "Invalid time format!");
                return true;
            }

            $target = PracticeUtils::getPlayerByPrefix($args[0]);
            $punishmentManager = $this->plugin->getPunishmentManager();
            $rankManager = $this->plugin->getRankManager();

            unset($args[0], $args[1]);
            $reason = PracticeUtils::filterStringForSQL(implode(" ", $args));

            if ($target) {
                if (!($target instanceof PracticePlayer)) {
                    return false;
                }

                if ($punishmentManager->isBannedByNickname($target->getName())) {
                    $sender->sendMessage(TextFormat::RED . "Player is already banned!");
                    return true;
                }

                if ($sender instanceof RconCommandSender) {
                    if ($target->getRank() === RankManager::OWNER_RANK || $target->getRank() === RankManager::STAFF_RANK) {
                        $sender->sendMessage(TextFormat::RED . "You can't ban this player!");
                        return true;
                    }
                }

                $punishmentManager->addBan($target, $sender->getName(), $time, $reason);

                if ($time === 0) {
                    $sender->sendMessage(sprintf(TextFormat::GREEN . "You have permanently banned %s with reason: %s", $target->getName(), $reason));
                } else {
                    $sender->sendMessage(sprintf(TextFormat::GREEN . "You have banned %s for %s days with reason: %s", $target->getName(), $time, $reason));
                }
            } else {
                if (!($this->plugin->getProvider()->isPlayerRegisteredByNickname($nickname))) {
                    $sender->sendMessage(TextFormat::RED . "Player is not registered!");
                    return true;
                }

                if ($punishmentManager->isBannedByNickname($nickname)) {
                    $sender->sendMessage(TextFormat::RED . "Player is already banned!");
                    return true;
                }

                if ($sender instanceof RconCommandSender) {
                    if ($rankManager->getRankByNickname($nickname) === RankManager::OWNER_RANK || $rankManager->getRankByNickname($nickname) === RankManager::STAFF_RANK) {
                        $sender->sendMessage(TextFormat::RED . "You can't ban this player!");
                        return true;
                    }
                }

                $punishmentManager->addBanOffline($nickname, $sender->getName(), $time, $reason);

                if ($time === 0) {
                    $sender->sendMessage(sprintf(TextFormat::GREEN . "You have permanently banned %s with reason: %s", $nickname, $reason));
                } else {
                    $sender->sendMessage(sprintf(TextFormat::GREEN . "You have banned %s for %s days with reason: %s", $nickname, $time, $reason));
                }
            }
        }
        return true;
    }

    /**
     * @param PracticePlayer $player
     * @return string
     */
    public function getDescriptionForPlayer(PracticePlayer $player): string
    {
        return $this->plugin->getTranslationManager()->translate($player, "banCommandDescription");
    }
}