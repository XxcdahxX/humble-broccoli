<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\player\punishment\command;

use antralia\core\rcon\RconCommandSender;
use antralia\practice\command\CommandArgs;
use antralia\practice\command\PracticeCommand;
use antralia\practice\player\PracticePlayer;
use antralia\practice\player\rank\RankManager;
use antralia\practice\PracticePlugin;
use antralia\practice\utils\PracticeUtils;
use pocketmine\command\CommandSender;
use pocketmine\network\mcpe\protocol\AvailableCommandsPacket;
use pocketmine\utils\TextFormat;

final class KickCommand extends PracticeCommand
{

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;

        $this->setPermission("practice.command.kick");
        $this->commandArg = new CommandArgs();
        $this->commandArg->addParameter(0, "player", AvailableCommandsPacket::ARG_TYPE_TARGET);
        $this->commandArg->addParameter(0, "reason");

        parent::__construct("kick", "Kick a player", "Usage: /kick <player> <reason>");
    }

    /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     * @return bool
     */
    public function execute(CommandSender $sender, string $commandLabel, array $args): bool
    {
        if (!($this->testPermission($sender))) {
            return false;
        }

        if ($sender instanceof PracticePlayer) {
            $translationManager = $this->plugin->getTranslationManager();

            if (empty($args) || !(isset($args[0])) || !(isset($args[1]))) {
                $sender->sendMessage($translationManager->translate($sender, "kickUsage"));
                return true;
            }

            $nickname = array_shift($args);
            $reason = implode(" ", $args);
            $target = PracticeUtils::getPlayerByPrefix($nickname);
            $punishmentManager = $this->plugin->getPunishmentManager();

            if ($target) {
                if (!($target instanceof PracticePlayer)) {
                    return false;
                }

                if ($target->getName() === $sender->getName()) {
                    $sender->sendMessage($translationManager->translate($sender, "selfKick"));
                    return true;
                }

                if ($sender->getRankPriority() <= $target->getRankPriority()) {
                    $sender->sendMessage($translationManager->translate($sender, "playerCannotBeKicked"));
                    return true;
                }

                $punishmentManager->kick($target, $sender->getName(), $reason);
                $sender->sendMessage(sprintf($translationManager->translate($sender, "successfulKick"), $target->getName(), $reason));
            } else {
                $sender->sendMessage($translationManager->translate($sender, "playerNotFound"));
            }
        } else {
            if (empty($args) || !(isset($args[0])) || !(isset($args[1]))) {
                $sender->sendMessage($this->usageMessage);
                return true;
            }

            $nickname = array_shift($args);
            $reason = implode(" ", $args);
            $target = PracticeUtils::getPlayerByPrefix($nickname);
            $punishmentManager = $this->plugin->getPunishmentManager();

            if ($target) {
                if (!($target instanceof PracticePlayer)) {
                    return false;
                }

                if ($sender instanceof RconCommandSender) {
                    if ($target->getRank() === RankManager::OWNER_RANK || $target->getRank() === RankManager::STAFF_RANK) {
                        $sender->sendMessage(TextFormat::RED . "You can't kick this player!");
                        return true;
                    }
                }

                $punishmentManager->kick($target, $sender->getName(), $reason);
                $sender->sendMessage(sprintf(TextFormat::GREEN . "You have successfully kicked %s with reason: %s", $target->getName(), $reason));
            } else {
                $sender->sendMessage(TextFormat::RED . "Player not found!");
            }
        }
        return true;
    }

    /**
     * @param PracticePlayer $player
     * @return string
     */
    public function getDescriptionForPlayer(PracticePlayer $player): string
    {
        return $this->plugin->getTranslationManager()->translate($player, "kickCommandDescription");
    }
}