<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\player\punishment;

use antralia\core\telegram\Telegram;
use antralia\core\vk\VK;
use antralia\practice\player\PracticePlayer;
use antralia\practice\PracticePlugin;
use antralia\practice\utils\PracticeUtils;
use pocketmine\utils\TextFormat;

use SQLite3;

final class PunishmentManager
{

    /**
     * @var int
     */
    public const MAX_BAN_TIME = 30;

    /**
     * @var int
     */
    public const MAX_MUTE_TIME = 30;

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @var SQLite3
     */
    private SQLite3 $punishmentDatabase;

    /**
     * @var array
     */
    private array $mutedPlayers = array();

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;

        $punishmentDatabase = new SQLite3($plugin->getDataFolder() . "data/punishments.db");
        $punishmentDatabase->exec("CREATE TABLE IF NOT EXISTS `bans` (`nickname` TEXT NOT NULL, `xuid` TEXT NOT NULL, `deviceid` TEXT NOT NULL, `banned_by` TEXT NOT NULL, `ban_expiry` INTEGER NOT NULL, `banned_when` INTEGER NOT NULL, `ban_reason` TEXT NOT NULL);");
        $punishmentDatabase->exec("CREATE TABLE IF NOT EXISTS `mutes` (`nickname` TEXT NOT NULL, `xuid` TEXT NOT NULL, `muted_by` TEXT NOT NULL, `mute_expiry` INTEGER NOT NULL, `muted_when` INTEGER NOT NULL, `mute_reason` TEXT NOT NULL);");
        $this->punishmentDatabase = $punishmentDatabase;
    }

    /**
     * @return SQLite3
     */
    public function getPunishmentDatabase(): SQLite3
    {
        return $this->punishmentDatabase;
    }

    /**
     * @param int $time
     * @return int
     */
    public function convertDaysToExpiryDate(int $time): int
    {
        return $time > 0 ? time() + ($time * 86400) : 0;
    }

    /**
     * @param string $nickname
     * @return bool
     */
    public function isBannedByNickname(string $nickname): bool
    {
        $query = $this->getPunishmentDatabase()->prepare("SELECT * FROM `bans` WHERE `nickname` = :nickname;");
        $query->bindValue(":nickname", strtolower($nickname));
        $result = $query->execute()->fetchArray(SQLITE3_ASSOC);

        return (bool)$result;
    }

    /**
     * @param string $xuid
     * @return bool
     */
    public function isBannedByXuid(string $xuid): bool
    {
        $query = $this->getPunishmentDatabase()->prepare("SELECT * FROM `bans` WHERE `xuid` = :xuid;");
        $query->bindValue(":xuid", $xuid);
        $result = $query->execute()->fetchArray(SQLITE3_ASSOC);

        return (bool)$result;
    }

    /**
     * @param string $deviceId
     * @return bool
     */
    public function isBannedByDeviceId(string $deviceId): bool
    {
        $query = $this->getPunishmentDatabase()->prepare("SELECT * FROM `bans` WHERE `deviceid` = :deviceid;");
        $query->bindValue(":deviceid", $deviceId);
        $result = $query->execute()->fetchArray(SQLITE3_ASSOC);

        return (bool)$result;
    }

    /**
     * @param PracticePlayer $player
     * @param string $bannedBy
     * @param int $time
     * @param string $banReason
     * @return void
     */
    public function addBan(PracticePlayer $player, string $bannedBy, int $time, string $banReason = "-"): void
    {
        $nickname = $player->getLowerCaseName();
        $xuid = $player->getXuid();
        $deviceId = $player->getPlayerInfo()->getExtraData()["DeviceId"];
        $locale = $this->plugin->getLanguageManager()->getLanguageFromDatabase($player);

        $banExpiry = $this->convertDaysToExpiryDate($time);
        $bannedWhen = time();

        $query = $this->getPunishmentDatabase()->prepare("INSERT INTO `bans` VALUES (:nickname, :xuid, :deviceid, :banned_by, :ban_expiry, :banned_when, :ban_reason);");
        $query->bindValue(":nickname", $nickname);
        $query->bindValue(":xuid", $xuid);
        $query->bindValue(":deviceid", $deviceId);
        $query->bindValue(":banned_by", $bannedBy);
        $query->bindValue(":ban_expiry", $banExpiry, SQLITE3_INTEGER);
        $query->bindValue(":banned_when", $bannedWhen, SQLITE3_INTEGER);
        $query->bindValue(":ban_reason", $banReason);
        $query->execute();

        $player->kick(sprintf(
            $this->plugin->getTranslationManager()->translateBan($locale, "banKick"),
            $player->getName(),
            $this->getBanDate($nickname, $xuid, $deviceId),
            $banReason,
            $this->getBanExpiry($nickname, $xuid, $deviceId, $locale)
        ));

        $this->plugin->getLogger()->info(sprintf(
            TextFormat::YELLOW . "%s was banned by %s %s with reason: %s",
            $player->getName(),
            $bannedBy,
            $time === 0 ? "permanently" : "for " . $time . " days",
            $banReason
        ));

        foreach ($this->plugin->getServer()->getOnlinePlayers() as $onlinePlayer) {
            if (!($onlinePlayer->isConnected())) {
                return;
            }

            if (!($onlinePlayer instanceof PracticePlayer)) {
                return;
            }

            if ($onlinePlayer->hasPermission("practice.channel.administrative")) {
                if ($this->plugin->getLanguageManager()->getLanguage($onlinePlayer) === "ru") {
                    $banTime = $time === 0 ? "навсегда" : "на " . $time . " дней";
                } else {
                    $banTime = $time === 0 ? "permanently" : "for " . $time . " days";
                }

                $onlinePlayer->sendMessage(sprintf(
                    $this->plugin->getTranslationManager()->translate($onlinePlayer, "playerBanNotification"),
                    $player->getName(),
                    $bannedBy,
                    $banTime,
                    $banReason
                ));
            }
        }

        Telegram::sendMessage(sprintf(
            "[%s] %s was banned by %s %s with reason: %s",
            date("d.m.y"),
            $player->getName(),
            $bannedBy,
            $time === 0 ? "permanently" : "for " . $time . " days",
            $banReason
        ));
        VK::sendMessage(sprintf(
            "[%s] Игрок %s был забанен от руки %s %s с причиной: %s",
            date("d.m.y"),
            $player->getName(),
            $bannedBy,
            $time === 0 ? "навсегда" : "на " . $time . " дней",
            $banReason
        ));
    }

    /**
     * @param string $nickname
     * @param string $bannedBy
     * @param int $time
     * @param string $banReason
     * @return void
     */
    public function addBanOffline(string $nickname, string $bannedBy, int $time, string $banReason = "-"): void
    {
        $provider = $this->plugin->getProvider();

        if (!($provider->isPlayerRegisteredByNickname($nickname))) {
            return;
        }

        $playerData = $provider->getPlayerDataByNickname($nickname);

        if (!($playerData)) {
            return;
        }

        $banExpiry = $this->convertDaysToExpiryDate($time);
        $bannedWhen = time();
        $banReason = str_replace(["'", "`", '"'], ["", "", ""], $banReason);

        $query = $this->getPunishmentDatabase()->prepare("INSERT INTO `bans` VALUES (:nickname, :xuid, :deviceid, :banned_by, :ban_expiry, :banned_when, :ban_reason);");
        $query->bindValue(":nickname", strtolower($nickname));
        $query->bindValue(":xuid", $playerData["xuid"]);
        $query->bindValue(":deviceid", $playerData["deviceid"]);
        $query->bindValue(":banned_by", $bannedBy);
        $query->bindValue(":ban_expiry", $banExpiry, SQLITE3_INTEGER);
        $query->bindValue(":banned_when", $bannedWhen, SQLITE3_INTEGER);
        $query->bindValue(":ban_reason", $banReason);
        $query->execute();

        $this->plugin->getLogger()->info(sprintf(
            TextFormat::YELLOW . "%s was banned by %s %s with reason: %s",
            $nickname,
            $bannedBy,
            $time === 0 ? "permanently" : "for " . $time . " days",
            $banReason
        ));

        foreach ($this->plugin->getServer()->getOnlinePlayers() as $onlinePlayer) {
            if (!($onlinePlayer->isConnected())) {
                return;
            }

            if (!($onlinePlayer instanceof PracticePlayer)) {
                return;
            }

            if ($onlinePlayer->hasPermission("practice.channel.administrative")) {
                if ($this->plugin->getLanguageManager()->getLanguage($onlinePlayer) === "ru") {
                    $banTime = $time === 0 ? "навсегда" : "на " . $time . " дней";
                } else {
                    $banTime = $time === 0 ? "permanently" : "for " . $time . " days";
                }

                $onlinePlayer->sendMessage(sprintf(
                    $this->plugin->getTranslationManager()->translate($onlinePlayer, "playerBanNotification"),
                    $nickname,
                    $bannedBy,
                    $banTime,
                    $banReason
                ));
            }
        }

        Telegram::sendMessage(sprintf(
            "[%s] %s was banned by %s %s with reason: %s",
            date("d.m.y"),
            $nickname,
            $bannedBy,
            $time === 0 ? "permanently" : "for " . $time . " days",
            $banReason
        ));
        VK::sendMessage(sprintf(
            "[%s] Игрок %s был забанен от руки %s %s с причиной: %s",
            date("d.m.y"),
            $nickname,
            $bannedBy,
            $time === 0 ? "навсегда" : "на " . $time . " дней",
            $banReason
        ));
    }

    /**
     * @param string $xuid
     * @param string $nickname
     * @return void
     */
    public function setBannedNickname(string $xuid, string $nickname): void
    {
        if (!($this->isBannedByXuid($xuid))) {
            return;
        }

        $query = $this->getPunishmentDatabase()->prepare("UPDATE `bans` SET `nickname` = :nickname WHERE `xuid` = :xuid;");
        $query->bindValue(":nickname", strtolower($nickname));
        $query->bindValue(":xuid", $xuid);
        $query->execute();
    }

    /**
     * @param string $xuid
     * @return string
     */
    public function getBannedNickname(string $xuid): string
    {
        if (!($this->isBannedByXuid($xuid))) {
            return "Steve";
        }

        $query = $this->getPunishmentDatabase()->prepare("SELECT `nickname` FROM `bans` WHERE `xuid` = :xuid;");
        $query->bindValue(":xuid", $xuid);
        $result = $query->execute()->fetchArray(SQLITE3_ASSOC);

        return !($result) ? "Steve" : $result["nickname"];
    }

    /**
     * @param string $deviceId
     * @return string
     */
    public function getBannedXuid(string $deviceId): string
    {
        if (!($this->isBannedByDeviceId($deviceId))) {
            return "0";
        }

        $query = $this->getPunishmentDatabase()->prepare("SELECT `xuid` FROM `bans` WHERE `deviceid` = :deviceid;");
        $query->bindValue(":deviceid", $deviceId);
        $result = $query->execute()->fetchArray(SQLITE3_ASSOC);

        return !($result) ? "0" : $result["xuid"];
    }

    /**
     * @param string $nickname
     * @param string $xuid
     * @param string $deviceId
     * @return string
     */
    public function getBannedNicknameForKick(string $nickname, string $xuid, string $deviceId): string
    {
        $punishmentDatabase = $this->getPunishmentDatabase();
        $nickname = strtolower($nickname);

        if ($this->isBannedByNickname($nickname)) {
            $query = $punishmentDatabase->prepare("SELECT `nickname` FROM `bans` WHERE `nickname` = :nickname;");
            $query->bindValue(":nickname", $nickname);
        } elseif ($this->isBannedByXuid($xuid)) {
            $query = $punishmentDatabase->prepare("SELECT `nickname` FROM `bans` WHERE `xuid` = :xuid;");
            $query->bindValue(":xuid", $xuid);
        } elseif ($this->isBannedByDeviceId($deviceId)) {
            $query = $punishmentDatabase->prepare("SELECT `nickname` FROM `bans` WHERE `deviceid` = :deviceid;");
            $query->bindValue(":deviceid", $deviceId);
        } else {
            $query = $punishmentDatabase->prepare("SELECT `nickname` FROM `bans` WHERE `nickname` = :nickname;");
            $query->bindValue(":nickname", $nickname);
        }

        $result = $query->execute()->fetchArray(SQLITE3_ASSOC);
        return !($result) ? "Unknown" : $result["nickname"];
    }

    /**
     * @param string $nickname
     * @param string $xuid
     * @param string $deviceId
     * @param string $locale
     * @return string
     */
    public function getBanExpiry(string $nickname, string $xuid, string $deviceId, string $locale): string
    {
        $punishmentDatabase = $this->getPunishmentDatabase();
        $nickname = strtolower($nickname);

        if ($this->isBannedByNickname($nickname)) {
            $query = $punishmentDatabase->prepare("SELECT `ban_expiry` FROM `bans` WHERE `nickname` = :nickname;");
            $query->bindValue(":nickname", $nickname);
        } elseif ($this->isBannedByXuid($xuid)) {
            $query = $punishmentDatabase->prepare("SELECT `ban_expiry` FROM `bans` WHERE `xuid` = :xuid;");
            $query->bindValue(":xuid", $xuid);
        } elseif ($this->isBannedByDeviceId($deviceId)) {
            $query = $punishmentDatabase->prepare("SELECT `ban_expiry` FROM `bans` WHERE `deviceid` = :deviceid;");
            $query->bindValue(":deviceid", $deviceId);
        } else {
            $query = $punishmentDatabase->prepare("SELECT `ban_expiry` FROM `bans` WHERE `nickname` = :nickname;");
            $query->bindValue(":nickname", $nickname);
        }

        $result = $query->execute()->fetchArray(SQLITE3_ASSOC);
        if (!($result)) {
            return $this->plugin->getTranslationManager()->translateBan($locale, "banNeverExpires");
        }

        if (!($result["ban_expiry"])) {
            return $this->plugin->getTranslationManager()->translateBan($locale, "banNeverExpires");
        }

        $time = ((int)$result["ban_expiry"]) - time();
        if ($time < 86400) {
            $date = date("H,i", $time - PracticeUtils::DATE_INACCURACY);
            $banExpiryDate = explode(",", $date);
            $banExpiry = [
                0 => "0",
                1 => $banExpiryDate[0],
                2 => $banExpiryDate[1]
            ];
        } else {
            $date = date("d,H,i", $time - PracticeUtils::DATE_INACCURACY);
            $banExpiry = explode(",", $date);
        }

        return sprintf($this->plugin->getTranslationManager()->translateBan($locale, "banExpiry"), $banExpiry[0], $banExpiry[1], $banExpiry[2]);
    }

    /**
     * @param string $nickname
     * @param string $xuid
     * @param string $deviceId
     * @return int
     */
    public function getRawBanExpiry(string $nickname, string $xuid, string $deviceId): int
    {
        $punishmentDatabase = $this->getPunishmentDatabase();
        $nickname = strtolower($nickname);

        if ($this->isBannedByNickname($nickname)) {
            $query = $punishmentDatabase->prepare("SELECT `ban_expiry` FROM `bans` WHERE `nickname` = :nickname;");
            $query->bindValue(":nickname", $nickname);
        } elseif ($this->isBannedByXuid($xuid)) {
            $query = $punishmentDatabase->prepare("SELECT `ban_expiry` FROM `bans` WHERE `xuid` = :xuid;");
            $query->bindValue(":xuid", $xuid);
        } elseif ($this->isBannedByDeviceId($deviceId)) {
            $query = $punishmentDatabase->prepare("SELECT `ban_expiry` FROM `bans` WHERE `deviceid` = :deviceid;");
            $query->bindValue(":deviceid", $deviceId);
        } else {
            $query = $punishmentDatabase->prepare("SELECT `ban_expiry` FROM `bans` WHERE `nickname` = :nickname;");
            $query->bindValue(":nickname", $nickname);
        }

        $result = $query->execute()->fetchArray(SQLITE3_ASSOC);
        if (!($result)) {
            return 0;
        } elseif (!($result["ban_expiry"])) {
            return 0;
        } else {
            return $result["ban_expiry"];
        }
    }

    /**
     * @param string $nickname
     * @param string $xuid
     * @param string $deviceId
     * @return string
     */
    public function getBanReason(string $nickname, string $xuid, string $deviceId): string
    {
        $punishmentDatabase = $this->getPunishmentDatabase();
        $nickname = strtolower($nickname);

        if ($this->isBannedByNickname($nickname)) {
            $query = $punishmentDatabase->prepare("SELECT `ban_reason` FROM `bans` WHERE `nickname` = :nickname;");
            $query->bindValue(":nickname", $nickname);
        } elseif ($this->isBannedByXuid($xuid)) {
            $query = $punishmentDatabase->prepare("SELECT `ban_reason` FROM `bans` WHERE `xuid` = :xuid;");
            $query->bindValue(":xuid", $xuid);
        } elseif ($this->isBannedByDeviceId($deviceId)) {
            $query = $punishmentDatabase->prepare("SELECT `ban_reason` FROM `bans` WHERE `deviceid` = :deviceid;");
            $query->bindValue(":deviceid", $deviceId);
        } else {
            $query = $punishmentDatabase->prepare("SELECT `ban_reason` FROM `bans` WHERE `nickname` = :nickname;");
            $query->bindValue(":nickname", $nickname);
        }

        $result = $query->execute()->fetchArray(SQLITE3_ASSOC);
        return !($result) ? "Unknown" : $result["ban_reason"];
    }

    /**
     * @param string $nickname
     * @param string $xuid
     * @param string $deviceId
     * @return string
     */
    public function getBanDate(string $nickname, string $xuid, string $deviceId): string
    {
        $punishmentDatabase = $this->getPunishmentDatabase();
        $nickname = strtolower($nickname);

        if ($this->isBannedByNickname($nickname)) {
            $query = $punishmentDatabase->prepare("SELECT `banned_when` FROM `bans` WHERE `nickname` = :nickname;");
            $query->bindValue(":nickname", $nickname);
        } elseif ($this->isBannedByXuid($xuid)) {
            $query = $punishmentDatabase->prepare("SELECT `banned_when` FROM `bans` WHERE `xuid` = :xuid;");
            $query->bindValue(":xuid", $xuid);
        } elseif ($this->isBannedByDeviceId($deviceId)) {
            $query = $punishmentDatabase->prepare("SELECT `banned_when` FROM `bans` WHERE `deviceid` = :deviceid;");
            $query->bindValue(":deviceid", $deviceId);
        } else {
            $query = $punishmentDatabase->prepare("SELECT `banned_when` FROM `bans` WHERE `nickname` = :nickname;");
            $query->bindValue(":nickname", $nickname);
        }

        $result = $query->execute()->fetchArray(SQLITE3_ASSOC);
        return !($result) ? "00.00.00" : date("d.m.y", (int)$result["banned_when"]);
    }

    /**
     * @param string $nickname
     * @param string $xuid
     * @param string $deviceId
     * @return void
     */
    public function removeBan(string $nickname, string $xuid, string $deviceId): void
    {
        $punishmentDatabase = $this->getPunishmentDatabase();
        $nickname = strtolower($nickname);

        if ($this->isBannedByNickname($nickname)) {
            $query = $punishmentDatabase->prepare("DELETE FROM `bans` WHERE `nickname` = :nickname;");
            $query->bindValue(":nickname", $nickname);
        } elseif ($this->isBannedByXuid($xuid)) {
            $query = $punishmentDatabase->prepare("DELETE FROM `bans` WHERE `xuid` = :xuid;");
            $query->bindValue(":xuid", $xuid);
        } elseif ($this->isBannedByDeviceId($deviceId)) {
            $query = $punishmentDatabase->prepare("DELETE FROM `bans` WHERE `deviceid` = :deviceid;");
            $query->bindValue(":deviceid", $deviceId);
        } else {
            $query = $punishmentDatabase->prepare("DELETE FROM `bans` WHERE `nickname` = :nickname;");
            $query->bindValue(":nickname", $nickname);
        }

        $query->execute();
    }

    /**
     * @param string $nickname
     * @param string $unbannedBy
     * @return void
     */
    public function removeBanByNickname(string $nickname, string $unbannedBy): void
    {
        $nickname = strtolower($nickname);

        if (!($this->isBannedByNickname($nickname))) {
            return;
        }

        $query = $this->getPunishmentDatabase()->prepare("DELETE FROM `bans` WHERE `nickname` = :nickname;");
        $query->bindValue(":nickname", $nickname);
        $query->execute();

        $this->plugin->getLogger()->info(sprintf(
            TextFormat::YELLOW . "%s was unbanned by %s",
            $nickname,
            $unbannedBy,
        ));

        foreach ($this->plugin->getServer()->getOnlinePlayers() as $onlinePlayer) {
            if ($onlinePlayer->hasPermission("practice.channel.administrative")) {
                if (!($onlinePlayer->isConnected())) {
                    return;
                }

                if (!($onlinePlayer instanceof PracticePlayer)) {
                    return;
                }

                $onlinePlayer->sendMessage(sprintf(
                    $this->plugin->getTranslationManager()->translate($onlinePlayer, "playerUnbanNotification"),
                    $nickname,
                    $unbannedBy,
                ));
            }
        }

        Telegram::sendMessage(sprintf(
            "[%s] %s was unbanned by %s",
            date("d.m.y"),
            $nickname,
            $unbannedBy,
        ));
        VK::sendMessage(sprintf(
            "[%s] Игрок %s был разбанен от руки %s",
            date("d.m.y"),
            $nickname,
            $unbannedBy,
        ));
    }

    /**
     * @param string $nickname
     * @return bool
     */
    public function isMutedByNickname(string $nickname): bool
    {
        $query = $this->getPunishmentDatabase()->prepare("SELECT * FROM `mutes` WHERE `nickname` = :nickname;");
        $query->bindValue(":nickname", strtolower($nickname));
        $result = $query->execute()->fetchArray(SQLITE3_ASSOC);

        return (bool)$result;
    }

    /**
     * @param PracticePlayer $player
     * @return bool
     */
    public function isMutedByXuid(PracticePlayer $player): bool
    {
        $query = $this->getPunishmentDatabase()->prepare("SELECT * FROM `mutes` WHERE `xuid` = :xuid;");
        $query->bindValue(":xuid", $player->getXuid());
        $result = $query->execute()->fetchArray(SQLITE3_ASSOC);

        return (bool)$result;
    }

    /**
     * @param PracticePlayer $player
     * @return bool
     */
    public function isMutedFromArray(PracticePlayer $player): bool
    {
        return isset($this->mutedPlayers[$player->getName()]);
    }

    /**
     * @param PracticePlayer $player
     * @param string $mutedBy
     * @param int $time
     * @param string $muteReason
     * @return void
     */
    public function addMute(PracticePlayer $player, string $mutedBy, int $time, string $muteReason = "-"): void
    {
        $query = $this->getPunishmentDatabase()->prepare("INSERT INTO `mutes` VALUES (:nickname, :xuid, :muted_by, :mute_expiry, :muted_when, :mute_reason);");
        $query->bindValue(":nickname", $player->getLowerCaseName());
        $query->bindValue(":xuid", $player->getXuid());
        $query->bindValue(":muted_by", $mutedBy);
        $query->bindValue(":mute_expiry", $this->convertDaysToExpiryDate($time), SQLITE3_INTEGER);
        $query->bindValue(":muted_when", time(), SQLITE3_INTEGER);
        $query->bindValue(":mute_reason", $muteReason);
        $query->execute();

        $this->mutedPlayers[$player->getName()] = true;
        $player->sendMessage(sprintf(
            $this->plugin->getTranslationManager()->translate($player, "muteMessage"),
            $player->getName(),
            $this->getMuteDate($player),
            $muteReason,
            $this->getMuteExpiry($player)
        ));

        $this->plugin->getLogger()->info(sprintf(
            TextFormat::YELLOW . "%s was muted by %s %s with reason: %s",
            $player->getName(),
            $mutedBy,
            $time === 0 ? "permanently" : "for " . $time . " days",
            $muteReason
        ));

        foreach ($this->plugin->getServer()->getOnlinePlayers() as $onlinePlayer) {
            if (!($onlinePlayer->isConnected())) {
                return;
            }

            if (!($onlinePlayer instanceof PracticePlayer)) {
                return;
            }

            if ($onlinePlayer->hasPermission("practice.channel.administrative")) {
                if ($this->plugin->getLanguageManager()->getLanguage($onlinePlayer) === "ru") {
                    $muteTime = $time === 0 ? "навсегда" : "на " . $time . " дней";
                } else {
                    $muteTime = $time === 0 ? "permanently" : "for " . $time . " days";
                }

                $onlinePlayer->sendMessage(sprintf(
                    $this->plugin->getTranslationManager()->translate($onlinePlayer, "playerMuteNotification"),
                    $player->getName(),
                    $mutedBy,
                    $muteTime,
                    $muteReason
                ));
            }
        }

        Telegram::sendMessage(sprintf(
            "[%s] %s was muted by %s %s with reason: %s",
            date("d.m.y"),
            $player->getName(),
            $mutedBy,
            $time === 0 ? "permanently" : "for " . $time . " days",
            $muteReason
        ));
        VK::sendMessage(sprintf(
            "[%s] Игроку %s был заблокирован чат от руки %s %s с причиной: %s",
            date("d.m.y"),
            $player->getName(),
            $mutedBy,
            $time === 0 ? "навсегда" : "на " . $time . " дней",
            $muteReason
        ));
    }

    /**
     * @param string $nickname
     * @param string $mutedBy
     * @param int $time
     * @param string $muteReason
     * @return void
     */
    public function addMuteOffline(string $nickname, string $mutedBy, int $time, string $muteReason = "-"): void
    {
        $provider = $this->plugin->getProvider();
        $nickname = strtolower($nickname);

        if (!($provider->isPlayerRegisteredByNickname($nickname))) {
            return;
        }

        $query = $this->getPunishmentDatabase()->prepare("INSERT INTO `mutes` VALUES (:nickname, :xuid, :muted_by, :mute_expiry, :muted_when, :mute_reason);");
        $query->bindValue(":nickname", $nickname);
        $query->bindValue(":xuid", $provider->getPlayerXuidByNickname($nickname));
        $query->bindValue(":muted_by", $mutedBy);
        $query->bindValue(":mute_expiry", $this->convertDaysToExpiryDate($time), SQLITE3_INTEGER);
        $query->bindValue(":muted_when", time(), SQLITE3_INTEGER);
        $query->bindValue(":mute_reason", $muteReason);
        $query->execute();

        $this->plugin->getLogger()->info(sprintf(
            TextFormat::YELLOW . "%s was muted by %s %s with reason: %s",
            $nickname,
            $mutedBy,
            $time === 0 ? "permanently" : "for " . $time . " days",
            $muteReason
        ));

        foreach ($this->plugin->getServer()->getOnlinePlayers() as $onlinePlayer) {
            if (!($onlinePlayer->isConnected())) {
                return;
            }

            if (!($onlinePlayer instanceof PracticePlayer)) {
                return;
            }

            if ($onlinePlayer->hasPermission("practice.channel.administrative")) {
                if ($this->plugin->getLanguageManager()->getLanguage($onlinePlayer) === "ru") {
                    $muteTime = $time === 0 ? "навсегда" : "на " . $time . " дней";
                } else {
                    $muteTime = $time === 0 ? "permanently" : "for " . $time . " days";
                }

                $onlinePlayer->sendMessage(sprintf(
                    $this->plugin->getTranslationManager()->translate($onlinePlayer, "playerMuteNotification"),
                    $nickname,
                    $mutedBy,
                    $muteTime,
                    $muteReason
                ));
            }
        }

        Telegram::sendMessage(sprintf(
            "[%s] %s was muted by %s %s with reason: %s",
            date("d.m.y"),
            $nickname,
            $mutedBy,
            $time === 0 ? "permanently" : "for " . $time . " days",
            $muteReason
        ));
        VK::sendMessage(sprintf(
            "[%s] Игроку %s был заблокирован чат от руки %s %s с причиной: %s",
            date("d.m.y"),
            $nickname,
            $mutedBy,
            $time === 0 ? "навсегда" : "на " . $time . " дней",
            $muteReason
        ));
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function addMuteToArray(PracticePlayer $player): void
    {
        $this->mutedPlayers[$player->getName()] = true;
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function setMutedNickname(PracticePlayer $player): void
    {
        if (!($this->isMutedByXuid($player))) {
            return;
        }

        $query = $this->getPunishmentDatabase()->prepare("UPDATE `mutes` SET `nickname` = :nickname WHERE `xuid` = :xuid;");
        $query->bindValue(":nickname", $player->getLowerCaseName());
        $query->bindValue(":xuid", $player->getXuid());
        $query->execute();
    }

    /**
     * @param PracticePlayer $player
     * @return string
     */
    public function getMutedNickname(PracticePlayer $player): string
    {
        if (!($this->isMutedByXuid($player))) {
            return "Steve";
        }

        $query = $this->getPunishmentDatabase()->prepare("SELECT `nickname` FROM `mutes` WHERE `xuid` = :xuid;");
        $query->bindValue(":xuid", $player->getXuid());
        $result = $query->execute()->fetchArray(SQLITE3_ASSOC);

        return !($result) ? "Steve" : $result["nickname"];
    }

    /**
     * @param PracticePlayer $player
     * @return string
     */
    public function getMuteExpiry(PracticePlayer $player): string
    {
        $punishmentDatabase = $this->getPunishmentDatabase();
        $nickname = $player->getLowerCaseName();

        if ($this->isMutedByNickname($nickname)) {
            $query = $punishmentDatabase->prepare("SELECT `mute_expiry` FROM `mutes` WHERE `nickname` = :nickname;");
            $query->bindValue(":nickname", $nickname);
        } elseif ($this->isMutedByXuid($player)) {
            $query = $punishmentDatabase->prepare("SELECT `mute_expiry` FROM `mutes` WHERE `xuid` = :xuid;");
            $query->bindValue(":xuid", $player->getXuid());
        } else {
            $query = $punishmentDatabase->prepare("SELECT `mute_expiry` FROM `mutes` WHERE `nickname` = :nickname;");
            $query->bindValue(":nickname", $nickname);
        }

        $result = $query->execute()->fetchArray(SQLITE3_ASSOC);

        if (!($result)) {
            return $this->plugin->getTranslationManager()->translate($player, "muteNeverExpires");
        }

        if ($result["mute_expiry"] === 0) {
            return $this->plugin->getTranslationManager()->translate($player, "muteNeverExpires");
        }

        $time = ((int)$result["mute_expiry"]) - time();
        if ($time < 86400) {
            $date = date("H,i", $time - PracticeUtils::DATE_INACCURACY);
            $muteExpiryDate = explode(",", $date);
            $muteExpiry = [
                0 => "0",
                1 => $muteExpiryDate[0],
                2 => $muteExpiryDate[1]
            ];
        } else {
            $date = date("d,H,i", $time - PracticeUtils::DATE_INACCURACY);
            $muteExpiry = explode(",", $date);
        }

        return sprintf($this->plugin->getTranslationManager()->translate($player, "muteExpiry"), $muteExpiry[0], $muteExpiry[1], $muteExpiry[2]);
    }

    /**
     * @param PracticePlayer $player
     * @return int
     */
    public function getRawMuteExpiry(PracticePlayer $player): int
    {
        $punishmentDatabase = $this->getPunishmentDatabase();
        $nickname = $player->getLowerCaseName();

        if ($this->isMutedByNickname($nickname)) {
            $query = $punishmentDatabase->prepare("SELECT `mute_expiry` FROM `mutes` WHERE `nickname` = :nickname;");
            $query->bindValue(":nickname", $nickname);
        } elseif ($this->isMutedByXuid($player)) {
            $query = $punishmentDatabase->prepare("SELECT `mute_expiry` FROM `mutes` WHERE `xuid` = :xuid;");
            $query->bindValue(":xuid", $player->getXuid());
        } else {
            $query = $punishmentDatabase->prepare("SELECT `mute_expiry` FROM `mutes` WHERE `nickname` = :nickname;");
            $query->bindValue(":nickname", $nickname);
        }

        $result = $query->execute()->fetchArray(SQLITE3_ASSOC);
        if (!($result)) {
            return 0;
        } elseif (!($result["mute_expiry"])) {
            return 0;
        } else {
            return $result["mute_expiry"];
        }
    }

    /**
     * @param PracticePlayer $player
     * @return string
     */
    public function getMuteReason(PracticePlayer $player): string
    {
        $punishmentDatabase = $this->getPunishmentDatabase();
        $nickname = $player->getLowerCaseName();

        if ($this->isMutedByNickname($nickname)) {
            $query = $punishmentDatabase->prepare("SELECT `mute_reason` FROM `mutes` WHERE `nickname` = :nickname;");
            $query->bindValue(":nickname", $nickname);
        } elseif ($this->isMutedByXuid($player)) {
            $query = $punishmentDatabase->prepare("SELECT `mute_reason` FROM `mutes` WHERE `xuid` = :xuid;");
            $query->bindValue(":xuid", $player->getXuid());
        } else {
            $query = $punishmentDatabase->prepare("SELECT `mute_reason` FROM `mutes` WHERE `nickname` = :nickname;");
            $query->bindValue(":nickname", $nickname);
        }

        $result = $query->execute()->fetchArray(SQLITE3_ASSOC);
        return !($result) ? "Unknown" : $result["mute_reason"];
    }

    /**
     * @param PracticePlayer $player
     * @return string
     */
    public function getMuteDate(PracticePlayer $player): string
    {
        $punishmentDatabase = $this->getPunishmentDatabase();
        $nickname = $player->getLowerCaseName();

        if ($this->isMutedByNickname($nickname)) {
            $query = $punishmentDatabase->prepare("SELECT `muted_when` FROM `mutes` WHERE `nickname` = :nickname;");
            $query->bindValue(":nickname", $nickname);
        } elseif ($this->isMutedByXuid($player)) {
            $query = $punishmentDatabase->prepare("SELECT `muted_when` FROM `mutes` WHERE `xuid` = :xuid;");
            $query->bindValue(":xuid", $player->getXuid());
        } else {
            $query = $punishmentDatabase->prepare("SELECT `muted_when` FROM `mutes` WHERE `nickname` = :nickname;");
            $query->bindValue(":nickname", $nickname);
        }

        $result = $query->execute()->fetchArray(SQLITE3_ASSOC);
        return !($result) ? "00.00.00" : date("d.m.y", (int)$result["muted_when"]);
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function removeMuteFromArray(PracticePlayer $player): void
    {
        if (isset($this->mutedPlayers[$player->getName()])) {
            unset($this->mutedPlayers[$player->getName()]);
        }
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function removeMute(PracticePlayer $player): void
    {
        $punishmentDatabase = $this->getPunishmentDatabase();
        $nickname = $player->getLowerCaseName();

        if ($this->isMutedByNickname($nickname)) {
            $query = $punishmentDatabase->prepare("DELETE FROM `mutes` WHERE `nickname` = :nickname;");
            $query->bindValue(":nickname", $nickname);
        } elseif ($this->isMutedByXuid($player)) {
            $query = $punishmentDatabase->prepare("DELETE FROM `mutes` WHERE `xuid` = :xuid;");
            $query->bindValue(":xuid", $player->getXuid());
        } else {
            $query = $punishmentDatabase->prepare("DELETE FROM `mutes` WHERE `nickname` = :nickname;");
            $query->bindValue(":nickname", $nickname);
        }

        $query->execute();
        $this->removeMuteFromArray($player);
    }

    /**
     * @param string $nickname
     * @param string $unmutedBy
     * @return void
     */
    public function removeMuteByNickname(string $nickname, string $unmutedBy): void
    {
        $nickname = strtolower($nickname);

        if (!($this->isMutedByNickname($nickname))) {
            return;
        }

        $query = $this->getPunishmentDatabase()->prepare("DELETE FROM `mutes` WHERE `nickname` = :nickname;");
        $query->bindValue(":nickname", $nickname);
        $query->execute();

        if ($player = $this->plugin->getServer()->getPlayerExact($nickname)) {
            if (!($player instanceof PracticePlayer)) {
                return;
            }

            $this->removeMuteFromArray($player);
        }

        $this->plugin->getLogger()->info(sprintf(
            TextFormat::YELLOW . "%s was unmuted by %s",
            $nickname,
            $unmutedBy,
        ));

        foreach ($this->plugin->getServer()->getOnlinePlayers() as $onlinePlayer) {
            if ($onlinePlayer->hasPermission("practice.channel.administrative")) {
                if (!($onlinePlayer->isConnected())) {
                    return;
                }

                if (!($onlinePlayer instanceof PracticePlayer)) {
                    return;
                }

                $onlinePlayer->sendMessage(sprintf(
                    $this->plugin->getTranslationManager()->translate($onlinePlayer, "playerUnmuteNotification"),
                    $nickname,
                    $unmutedBy,
                ));
            }
        }

        Telegram::sendMessage(sprintf(
            "[%s] %s was unmuted by %s",
            date("d.m.y"),
            $nickname,
            $unmutedBy,
        ));
        VK::sendMessage(sprintf(
            "[%s] Игроку %s был разблокирован чат от руки %s",
            date("d.m.y"),
            $nickname,
            $unmutedBy,
        ));
    }

    /**
     * @param PracticePlayer $player
     * @param string $kickedBy
     * @param string $kickReason
     * @return void
     */
    public function kick(PracticePlayer $player, string $kickedBy, string $kickReason = "-"): void
    {
        $player->kick(sprintf(
            $this->plugin->getTranslationManager()->translate($player, "kickMessage"),
            $player->getName(),
            date("d.m.y"),
            $kickReason
        ));

        $this->plugin->getLogger()->info(sprintf(
            TextFormat::YELLOW . "%s was kicked by %s with reason: %s",
            $player->getName(),
            $kickedBy,
            $kickReason
        ));

        foreach ($this->plugin->getServer()->getOnlinePlayers() as $onlinePlayer) {
            if (!($onlinePlayer->isConnected())) {
                return;
            }

            if (!($onlinePlayer instanceof PracticePlayer)) {
                return;
            }

            if ($onlinePlayer->hasPermission("practice.channel.administrative")) {
                $onlinePlayer->sendMessage(sprintf(
                    $this->plugin->getTranslationManager()->translate($onlinePlayer, "playerKickNotification"),
                    $player->getName(),
                    $kickedBy,
                    $kickReason
                ));
            }
        }

        Telegram::sendMessage(sprintf(
            "[%s] %s was kicked by %s with reason: %s",
            date("d.m.y"),
            $player->getName(),
            $kickedBy,
            $kickReason
        ));
        VK::sendMessage(sprintf(
            "[%s] Игрок %s был кикнут от руки %s с причиной: %s",
            date("d.m.y"),
            $player->getName(),
            $kickedBy,
            $kickReason
        ));
    }

    /**
     * Closing the database.
     */
    public function __destruct()
    {
        $this->getPunishmentDatabase()->close();
    }
}