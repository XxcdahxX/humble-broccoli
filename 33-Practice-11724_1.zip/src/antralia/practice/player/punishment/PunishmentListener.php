<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\player\punishment;

use antralia\practice\player\PracticePlayer;
use antralia\practice\PracticePlugin;
use antralia\practice\utils\PracticeUtils;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerPreLoginEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\player\XboxLivePlayerInfo;

final class PunishmentListener implements Listener
{

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @handleCancelled
     *
     * @param PlayerPreLoginEvent $event
     * @return void
     */
    public function handlePlayerPreLogin(PlayerPreLoginEvent $event): void
    {
        $playerInfo = $event->getPlayerInfo();

        $nickname = PracticeUtils::filterStringForSQL($playerInfo->getUsername());
        $deviceId = PracticeUtils::filterStringForSQL($playerInfo->getExtraData()["DeviceId"]);

        if ($playerInfo instanceof XboxLivePlayerInfo) {
            $xuid = PracticeUtils::filterStringForSQL($playerInfo->getXuid());
        } else {
            $xuid = "0";
        }

        $punishmentManager = $this->plugin->getPunishmentManager();

        if ($punishmentManager->isBannedByNickname($nickname) || $punishmentManager->isBannedByXuid($xuid) || $punishmentManager->isBannedByDeviceId($deviceId)) {
            if (time() >= $punishmentManager->getRawBanExpiry($nickname, $xuid, $deviceId) && $punishmentManager->getRawBanExpiry($nickname, $xuid, $deviceId) !== 0) {
                $punishmentManager->removeBan($nickname, $xuid, $deviceId);
            } else {
                if ($punishmentManager->getBannedNickname($xuid) !== $nickname && $punishmentManager->getBannedXuid($deviceId) === $xuid) {
                    $punishmentManager->setBannedNickname($xuid, $nickname);
                }

                if ($this->plugin->getLanguageManager()->getLanguageByXuid($xuid) === "none") {
                    $locale = match ($playerInfo->getLocale())
                    {
                        "ru_RU" => "ru",
                        default => "en"
                    };
                } else {
                    $locale = $this->plugin->getLanguageManager()->getLanguageByXuid($xuid);
                }

                $event->setKickReason(PlayerPreLoginEvent::KICK_REASON_PLUGIN, sprintf(
                    $this->plugin->getTranslationManager()->translateBan($locale, "banKick"),
                    $punishmentManager->getBannedNicknameForKick($nickname, $xuid, $deviceId),
                    $punishmentManager->getBanDate($nickname, $xuid, $deviceId),
                    $punishmentManager->getBanReason($nickname, $xuid, $deviceId),
                    $punishmentManager->getBanExpiry($nickname, $xuid, $deviceId, $locale)
                ));
            }
        }
    }

    /**
     * @param PlayerJoinEvent $event
     * @return void
     */
    public function handlePlayerJoin(PlayerJoinEvent $event): void
    {
        $player = $event->getPlayer();

        if (!($player instanceof PracticePlayer)) {
            return;
        }

        $punishmentManager = $this->plugin->getPunishmentManager();

        if ($punishmentManager->isMutedByNickname($player->getName()) || $punishmentManager->isMutedByXuid($player)) {
            $punishmentManager->addMuteToArray($player);
        }
    }

    /**
     * @param PlayerQuitEvent $event
     * @return void
     */
    public function handlePlayerQuit(PlayerQuitEvent $event): void
    {
        $player = $event->getPlayer();

        if (!($player instanceof PracticePlayer)) {
            return;
        }

        $punishmentManager = $this->plugin->getPunishmentManager();

        if ($punishmentManager->isMutedFromArray($player)) {
            $punishmentManager->removeMuteFromArray($player);
        }
    }

    /**
     * @handleCancelled
     *
     * @param PlayerChatEvent $event
     * @return void
     */
    public function handlePlayerChat(PlayerChatEvent $event): void
    {
        $player = $event->getPlayer();

        if (!($player instanceof PracticePlayer)) {
            return;
        }

        $punishmentManager = $this->plugin->getPunishmentManager();

        if ($punishmentManager->isMutedFromArray($player)) {
            if (time() >= $punishmentManager->getRawMuteExpiry($player) && $punishmentManager->getRawMuteExpiry($player) !== 0) {
                $punishmentManager->removeMute($player);
            } else {
                if ($punishmentManager->getMutedNickname($player) !== $player->getLowerCaseName()) {
                    $punishmentManager->setMutedNickname($player);
                }

                $player->sendMessage(sprintf(
                    $this->plugin->getTranslationManager()->translate($player, "muteMessage"),
                    $punishmentManager->getMutedNickname($player),
                    $punishmentManager->getMuteDate($player),
                    $punishmentManager->getMuteReason($player),
                    $punishmentManager->getMuteExpiry($player)
                ));
                $event->cancel();
            }
        }
    }
}