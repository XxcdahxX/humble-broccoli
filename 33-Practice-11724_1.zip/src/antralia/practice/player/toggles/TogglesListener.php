<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\player\toggles;

use antralia\practice\player\PracticePlayer;
use antralia\practice\PracticePlugin;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\server\DataPacketReceiveEvent;
use pocketmine\network\mcpe\protocol\InventoryTransactionPacket;
use pocketmine\network\mcpe\protocol\LevelSoundEventPacket;
use pocketmine\network\mcpe\protocol\PlayerAuthInputPacket;
use pocketmine\network\mcpe\protocol\types\inventory\UseItemOnEntityTransactionData;
use pocketmine\network\mcpe\protocol\types\LevelSoundEvent;
use pocketmine\network\mcpe\protocol\types\PlayerAuthInputFlags;

final class TogglesListener implements Listener
{

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @param PlayerJoinEvent $event
     * @return void
     */
    public function handlePlayerJoin(PlayerJoinEvent $event): void
    {
        $player = $event->getPlayer();

        if (!($player instanceof PracticePlayer)) {
            return;
        }

        $togglesManager = $this->plugin->getTogglesManager();

        $togglesManager->setToggleStatus($player, "scoreboard", $togglesManager->getToggleStatusFromDatabase($player, "scoreboard"));
        $togglesManager->setToggleStatus($player, "cps", $togglesManager->getToggleStatusFromDatabase($player, "cps"));
        $togglesManager->setToggleStatus($player, "autosprint", $togglesManager->getToggleStatusFromDatabase($player, "autosprint"));
        $togglesManager->setToggleStatus($player, "lightning", $togglesManager->getToggleStatusFromDatabase($player, "lightning"));
        $togglesManager->setToggleStatus($player, "hide_players", $togglesManager->getToggleStatusFromDatabase($player, "hide_players"));
        $togglesManager->setToggleStatus($player, "arena_respawn", $togglesManager->getToggleStatusFromDatabase($player, "arena_respawn"));
    }

    /**
     * @param PlayerQuitEvent $event
     * @return void
     */
    public function handlePlayerQuit(PlayerQuitEvent $event): void
    {
        $player = $event->getPlayer();

        if (!($player instanceof PracticePlayer)) {
            return;
        }

        $this->plugin->getTogglesManager()->removeToggleStatus($player);
        $this->plugin->getTogglesManager()->removeCPS($player);
    }

    /**
     * @param DataPacketReceiveEvent $event
     * @return void
     */
    public function handleDataPacketReceive(DataPacketReceiveEvent $event): void
    {
        $player = $event->getOrigin()->getPlayer();
        $packet = $event->getPacket();

        if (!($player instanceof PracticePlayer)) {
            return;
        }

        $togglesManager = $this->plugin->getTogglesManager();

        if ($packet instanceof PlayerAuthInputPacket) {
            $player->currentInputMode = $packet->getInputMode();
            if ($player->isSprinting()) {
                if ($packet->hasFlag(PlayerAuthInputFlags::DOWN) || $packet->hasFlag(PlayerAuthInputFlags::SNEAKING)) {
                    $player->setSprinting(false);
                }
            } elseif ($packet->hasFlag(PlayerAuthInputFlags::UP) && !($packet->hasFlag(PlayerAuthInputFlags::SNEAKING)) && $togglesManager->getToggleStatus($player, "autosprint")) {
                $player->setSprinting();
            }
        }

        $packet = $event->getPacket();
        if ($packet instanceof LevelSoundEventPacket && $packet->sound === LevelSoundEvent::ATTACK_NODAMAGE) {
            $togglesManager->addCPS($player);
            $togglesManager->sendCPSBar($player);
            $this->plugin->getAntiCheatManager()->processCPSCheck($player, $togglesManager->getCPS($player));
        } elseif ($packet instanceof InventoryTransactionPacket && $packet->trData instanceof UseItemOnEntityTransactionData) {
            $togglesManager->addCPS($player);
            $togglesManager->sendCPSBar($player);
            $this->plugin->getAntiCheatManager()->processCPSCheck($player, $togglesManager->getCPS($player));
        }
    }
}