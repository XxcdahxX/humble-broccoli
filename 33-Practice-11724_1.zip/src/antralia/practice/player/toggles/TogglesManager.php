<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\player\toggles;

use antralia\core\form\CustomForm;
use antralia\core\form\SimpleForm;
use antralia\core\scoreboard\Scoreboard;
use antralia\practice\player\PracticePlayer;
use antralia\practice\PracticePlugin;
use pocketmine\player\Player;

final class TogglesManager
{

    /**
     * @var string[]
     */
    public const TOGGLES = [
        "scoreboard",
        "cps",
        "autosprint",
        "lightning",
        "hide_players",
        "arena_respawn"
    ];

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @var array
     */
    private array $toggles = [];

    /**
     * @var array
     */
    private array $cps = [];

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @param PracticePlayer $player
     * @param string $toggle
     * @return bool
     */
    public function getToggleStatusFromDatabase(PracticePlayer $player, string $toggle): bool
    {
        if (!(in_array($toggle, self::TOGGLES, true))) {
            $this->plugin->getLogger()->alert("Undefined toggle: " . $toggle);
            return false;
        }

        $database = $this->plugin->getProvider()->getDatabase();

        if ($toggle === "scoreboard") {
            $query = $database->prepare("SELECT `scoreboard` FROM `toggles` WHERE `xuid` = :xuid;");
        } elseif ($toggle === "cps") {
            $query = $database->prepare("SELECT `cps` FROM `toggles` WHERE `xuid` = :xuid;");
        } elseif ($toggle === "autosprint") {
            $query = $database->prepare("SELECT `autosprint` FROM `toggles` WHERE `xuid` = :xuid;");
        } elseif ($toggle === "lightning") {
            $query = $database->prepare("SELECT `lightning` FROM `toggles` WHERE `xuid` = :xuid;");
        } elseif ($toggle === "hide_players") {
            $query = $database->prepare("SELECT `hide_players` FROM `toggles` WHERE `xuid` = :xuid;");
        } elseif ($toggle === "arena_respawn") {
            $query = $database->prepare("SELECT `arena_respawn` FROM `toggles` WHERE `xuid` = :xuid;");
        } else {
            $query = $database->prepare("SELECT `scoreboard` FROM `toggles` WHERE `xuid` = :xuid;");
        }

        $query->bindValue(":toggle", $toggle);
        $query->bindValue(":xuid", $player->getXuid());
        $result = $query->execute()->fetchArray(SQLITE3_ASSOC);

        if (!($result)) {
            return $toggle === "scoreboard" || $toggle === "lightning";
        } else {
            return $result[$toggle] === "enabled";
        }
    }

    /**
     * @param PracticePlayer $player
     * @param string $toggle
     * @return bool
     */
    public function getToggleStatus(PracticePlayer $player, string $toggle): bool
    {
        if (!(in_array($toggle, self::TOGGLES, true))) {
            $this->plugin->getLogger()->alert("Undefined toggle: " . $toggle);
            return false;
        }

        if (!(isset($this->toggles[$player->getName()][$toggle]))) {
            return false;
        } else {
            return $this->toggles[$player->getName()][$toggle];
        }
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function removeToggleStatus(PracticePlayer $player): void
    {
        if (isset($this->toggles[$player->getName()])) {
            unset($this->toggles[$player->getName()]);
        }
    }

    /**
     * @param PracticePlayer $player
     * @param string $toggle
     * @return void
     */
    public function enableToggle(PracticePlayer $player, string $toggle): void
    {
        if (!(in_array($toggle, self::TOGGLES, true))) {
            $this->plugin->getLogger()->alert("Undefined toggle: " . $toggle);
            return;
        }

        $database = $this->plugin->getProvider()->getDatabase();
        $this->toggles[$player->getName()][$toggle] = true;

        if ($toggle === "scoreboard") {
            $query = $database->prepare("UPDATE `toggles` SET `scoreboard` = :status WHERE `xuid` = :xuid;");
        } elseif ($toggle === "cps") {
            $query = $database->prepare("UPDATE `toggles` SET `cps` = :status WHERE `xuid` = :xuid;");
        } elseif ($toggle === "autosprint") {
            $query = $database->prepare("UPDATE `toggles` SET `autosprint` = :status WHERE `xuid` = :xuid;");
        } elseif ($toggle === "lightning") {
            $query = $database->prepare("UPDATE `toggles` SET `lightning` = :status WHERE `xuid` = :xuid;");
        } elseif ($toggle === "hide_players") {
            $query = $database->prepare("UPDATE `toggles` SET `hide_players` = :status WHERE `xuid` = :xuid;");
        } elseif ($toggle === "arena_respawn") {
            $query = $database->prepare("UPDATE `toggles` SET `arena_respawn` = :status WHERE `xuid` = :xuid;");
        } else {
            $query = $database->prepare("UPDATE `toggles` SET `scoreboard` = :status WHERE `xuid` = :xuid;");
        }

        $query->bindValue(":status", "enabled");
        $query->bindValue(":xuid", $player->getXuid());
        $query->execute();
    }

    /**
     * @param PracticePlayer $player
     * @param string $toggle
     * @return void
     */
    public function disableToggle(PracticePlayer $player, string $toggle): void
    {
        if (!(in_array($toggle, self::TOGGLES, true))) {
            $this->plugin->getLogger()->alert("Undefined toggle: " . $toggle);
            return;
        }

        $database = $this->plugin->getProvider()->getDatabase();
        $this->toggles[$player->getName()][$toggle] = false;

        if ($toggle === "scoreboard") {
            $query = $database->prepare("UPDATE `toggles` SET `scoreboard` = :status WHERE `xuid` = :xuid;");
        } elseif ($toggle === "cps") {
            $query = $database->prepare("UPDATE `toggles` SET `cps` = :status WHERE `xuid` = :xuid;");
        } elseif ($toggle === "autosprint") {
            $query = $database->prepare("UPDATE `toggles` SET `autosprint` = :status WHERE `xuid` = :xuid;");
        } elseif ($toggle === "lightning") {
            $query = $database->prepare("UPDATE `toggles` SET `lightning` = :status WHERE `xuid` = :xuid;");
        } elseif ($toggle === "hide_players") {
            $query = $database->prepare("UPDATE `toggles` SET `hide_players` = :status WHERE `xuid` = :xuid;");
        } elseif ($toggle === "arena_respawn") {
            $query = $database->prepare("UPDATE `toggles` SET `arena_respawn` = :status WHERE `xuid` = :xuid;");
        } else {
            $query = $database->prepare("UPDATE `toggles` SET `scoreboard` = :status WHERE `xuid` = :xuid;");
        }

        $query->bindValue(":status", "disabled");
        $query->bindValue(":xuid", $player->getXuid());
        $query->execute();
    }

    /**
     * @param PracticePlayer $player
     * @param string $toggle
     * @param bool $value
     * @return void
     */
    public function setToggleStatus(PracticePlayer $player, string $toggle, bool $value): void
    {
        if (!(in_array($toggle, self::TOGGLES, true))) {
            $this->plugin->getLogger()->alert("Undefined toggle: " . $toggle);
            return;
        }

        $this->toggles[$player->getName()][$toggle] = $value;
    }

    /**
     * @param PracticePlayer $player
     * @return int
     */
    public function getCPS(PracticePlayer $player): int
    {
        $time = microtime(true);
        return count(array_filter($this->cps[$player->getName()] ?? [], function (float $value) use ($time): bool {
            return ($time - $value) <= 1;
        }));
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function addCPS(PracticePlayer $player): void
    {
        $this->cps[$player->getName()][] = microtime(true);
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function removeCPS(PracticePlayer $player): void
    {
        if (isset($this->cps[$player->getName()])) {
            unset($this->cps[$player->getName()]);
        }
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function sendCPSBar(PracticePlayer $player): void
    {
        if (!($player->isConnected())) {
            return;
        }

        if ($this->getToggleStatus($player, "cps")) {
            $player->sendTip("§e" . $this->getCPS($player) . " CPS");
        }
    }

    /**
     * @param Player[] $players
     * @return PracticePlayer[]
     */
    public function getLightningViewers(array $players): array
    {
        $viewers = [];
        foreach ($players as $player) {
            if (!($player instanceof PracticePlayer)) {
                continue;
            }

            if (!($player->isConnected())) {
                continue;
            }

            if ($this->getToggleStatus($player, "lightning")) {
                if (!($this->getToggleStatus($player, "hide_players") && $this->plugin->getFFAManager()->isInCombat($player))) {
                    $viewers[] = $player;
                }
            }
        }
        return $viewers;
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function sendTogglesForm(PracticePlayer $player): void
    {
        $form = new SimpleForm(function (PracticePlayer $player, int $data = null): void {
            if ($data === null) {
                return;
            }

            switch ($data) {
                case 0:
                    $this->sendGeneralTogglesForm($player);
                    break;
                case 1:
                    $this->sendFFATogglesForm($player);
                    break;
                case 2:
                    $this->plugin->getHubManager()->sendPreferencesForm($player);
                    break;
            }
        });

        $formContents = $this->plugin->getTranslationManager()->translate($player, "togglesForm");

        $form->setTitle($formContents[0]);

        $form->addButton($formContents[1]);
        $form->addButton($formContents[2]);
        $form->addButton($formContents[3]);

        $player->sendForm($form);
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function sendGeneralTogglesForm(PracticePlayer $player): void
    {
        $form = new CustomForm(function (PracticePlayer $player, array $data = null): void {
            if ($data === null) {
                return;
            }

            $translationManager = $this->plugin->getTranslationManager();

            $flag = false;
            if ($data[0] !== $this->getToggleStatus($player, "scoreboard")) {
                $flag = true;
                if ($this->getToggleStatusFromDatabase($player, "scoreboard")) {
                    $this->disableToggle($player, "scoreboard");
                    $player->sendMessage($translationManager->translate($player, "scoreboardDisabled"));

                    if (Scoreboard::hasScore($player)) {
                        Scoreboard::removeScore($player);
                    }
                } else {
                    $this->enableToggle($player, "scoreboard");
                    $player->sendMessage($translationManager->translate($player, "scoreboardEnabled"));

                    $hubManager = $this->plugin->getHubManager();
                    if ($hubManager->isInHub($player)) {
                        $hubManager->updateScoreboard($player);
                    }
                }
            }
            if ($data[1] !== $this->getToggleStatusFromDatabase($player, "cps")) {
                $flag = true;
                if ($this->getToggleStatusFromDatabase($player, "cps")) {
                    $this->disableToggle($player, "cps");
                    $player->sendMessage($translationManager->translate($player, "cpsDisabled"));
                } else {
                    $this->enableToggle($player, "cps");
                    $player->sendMessage($translationManager->translate($player, "cpsEnabled"));
                }
            }
            if ($data[2] !== $this->getToggleStatusFromDatabase($player, "autosprint")) {
                $flag = true;
                if ($this->getToggleStatusFromDatabase($player, "autosprint")) {
                    $this->disableToggle($player, "autosprint");
                    $player->sendMessage($translationManager->translate($player, "autosprintDisabled"));
                } else {
                    $this->enableToggle($player, "autosprint");
                    $player->sendMessage($translationManager->translate($player, "autosprintEnabled"));
                }
            }
            if ($data[3] !== $this->getToggleStatusFromDatabase($player, "lightning")) {
                $flag = true;
                if ($this->getToggleStatusFromDatabase($player, "lightning")) {
                    $this->disableToggle($player, "lightning");
                    $player->sendMessage($translationManager->translate($player, "lightningDisabled"));
                } else {
                    $this->enableToggle($player, "lightning");
                    $player->sendMessage($translationManager->translate($player, "lightningEnabled"));
                }
            }

            if (!($flag)) {
                $this->sendTogglesForm($player);
            }
        });

        $formContents = $this->plugin->getTranslationManager()->translate($player, "generalTogglesForm");

        $form->setTitle($formContents[0]);

        $form->addToggle($formContents[1], $this->getToggleStatusFromDatabase($player, "scoreboard"));
        $form->addToggle($formContents[2], $this->getToggleStatusFromDatabase($player, "cps"));
        $form->addToggle($formContents[3], $this->getToggleStatusFromDatabase($player, "autosprint"));
        $form->addToggle($formContents[4], $this->getToggleStatusFromDatabase($player, "lightning"));

        $player->sendForm($form);
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function sendFFATogglesForm(PracticePlayer $player): void
    {
        $form = new CustomForm(function (PracticePlayer $player, array $data = null): void {
            if ($data === null) {
                return;
            }

            $translationManager = $this->plugin->getTranslationManager();

            $flag = false;
            if ($data[0] !== $this->getToggleStatusFromDatabase($player, "hide_players")) {
                $flag = true;
                if ($this->getToggleStatusFromDatabase($player, "hide_players")) {
                    $this->disableToggle($player, "hide_players");
                    $player->sendMessage($translationManager->translate($player, "hidePlayersDisabled"));
                } else {
                    $this->enableToggle($player, "hide_players");
                    $player->sendMessage($translationManager->translate($player, "hidePlayersEnabled"));
                }
            }
            if ($data[1] !== $this->getToggleStatusFromDatabase($player, "arena_respawn")) {
                $flag = true;
                if ($this->getToggleStatusFromDatabase($player, "arena_respawn")) {
                    $this->disableToggle($player, "arena_respawn");
                    $player->sendMessage($translationManager->translate($player, "arenaRespawnDisabled"));
                } else {
                    $this->enableToggle($player, "arena_respawn");
                    $player->sendMessage($translationManager->translate($player, "arenaRespawnEnabled"));
                }
            }

            if (!($flag)) {
                $this->sendTogglesForm($player);
            }
        });

        $formContents = $this->plugin->getTranslationManager()->translate($player, "ffaTogglesForm");

        $form->setTitle($formContents[0]);

        $form->addToggle($formContents[1], $this->getToggleStatusFromDatabase($player, "hide_players"));
        $form->addToggle($formContents[2], $this->getToggleStatusFromDatabase($player, "arena_respawn"));

        $player->sendForm($form);
    }
}