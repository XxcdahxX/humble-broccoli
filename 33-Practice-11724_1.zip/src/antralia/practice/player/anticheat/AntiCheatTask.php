<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\player\anticheat;

use antralia\core\telegram\Telegram;
use antralia\practice\player\PracticePlayer;
use antralia\practice\player\rank\RankManager;
use antralia\practice\PracticePlugin;
use pocketmine\scheduler\Task;
use pocketmine\utils\TextFormat;

final class AntiCheatTask extends Task
{

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @return void
     */
    public function onRun(): void
    {
        foreach ($this->plugin->getServer()->getOnlinePlayers() as $player) {
            if (!($player->isConnected())) {
                continue;
            }

            if (!($player instanceof PracticePlayer)) {
                continue;
            }

            $antiCheatManager = $this->plugin->getAntiCheatManager();
            $packetsPerSecond = $antiCheatManager->packetsPerSecond[$player->getName()] ?? 0;

            if ($packetsPerSecond >= AntiCheatManager::PACKET_LIMIT) {
                if ($player->getRank() === RankManager::OWNER_RANK) {
                    continue;
                }

                Telegram::sendMessage(sprintf("[%s] %s tried to send %s packets per second, when limit is %s (%s)", date("d.m.y"), $player->getName(), $packetsPerSecond, AntiCheatManager::PACKET_LIMIT, AntiCheatManager::ERROR_TOO_MANY_PACKETS));
                $this->plugin->getLogger()->info(sprintf(TextFormat::YELLOW . "%s tried to send %s packets per second, when limit is %s (%s)", $player->getName(), $packetsPerSecond, AntiCheatManager::PACKET_LIMIT, AntiCheatManager::ERROR_TOO_MANY_PACKETS));
                $player->kick(sprintf("In-game error (%s)\nCode: %s", $player->getName(), AntiCheatManager::ERROR_TOO_MANY_PACKETS));
                $this->plugin->getServer()->getNetwork()->blockAddress($player->getNetworkSession()->getIp(), 5);
                unset($antiCheatManager->packetsPerSecond[$player->getName()]);
            } else {
                $antiCheatManager->packetsPerSecond[$player->getName()] = 0;
            }
        }
    }
}