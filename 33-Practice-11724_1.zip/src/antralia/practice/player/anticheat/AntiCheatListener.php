<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\player\anticheat;

use antralia\core\telegram\Telegram;
use antralia\practice\player\deviceos\PracticeDeviceOS;
use antralia\practice\player\PracticePlayer;
use antralia\practice\player\rank\RankManager;
use antralia\practice\PracticePlugin;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerPreLoginEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\server\DataPacketReceiveEvent;
use pocketmine\network\mcpe\protocol\TextPacket;
use pocketmine\network\mcpe\protocol\types\DeviceOS;
use pocketmine\player\Player;
use pocketmine\player\XboxLivePlayerInfo;
use pocketmine\utils\TextFormat;

final class AntiCheatListener implements Listener
{

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @param PlayerPreLoginEvent $event
     * @return void
     */
    public function handlePlayerPreLogin(PlayerPreLoginEvent $event): void
    {
        $playerInfo = $event->getPlayerInfo();
        $extraData = $playerInfo->getExtraData();
        $nickname = $playerInfo->getUsername();

        if (!($playerInfo instanceof XboxLivePlayerInfo)) {
            $xuid = "0";
        } else {
            $xuid = $playerInfo->getXuid();
        }

        if ($this->plugin->getRankManager()->getRankByNickname($nickname) === RankManager::OWNER_RANK) {
            return;
        }

        $locale = $this->plugin->getLanguageManager()->getLanguageByXuid($xuid);
        if ($locale === "none") {
            $locale = match ($playerInfo->getLocale()) {
                "ru_RU" => "ru",
                default => "en"
            };
        }
        $kickMessage = $this->plugin->getTranslationManager()->translateAntiCheat($locale, "loginError");

        /** @var Player[] $playersToKick */
        $playersToKick = [];
        $count = 0;
        foreach ($this->plugin->getServer()->getOnlinePlayers() as $player) {
            if (!($player->isConnected())) {
                continue;
            }

            if ($event->getIp() === $player->getNetworkSession()->getIp()) {
                $playersToKick[] = $player;
                $count++;
            }
        }

        if ($count >= AntiCheatManager::IP_LIMIT) {
            foreach ($playersToKick as $player) {
                if ($player->isConnected()) {
                    Telegram::sendMessage(sprintf("[%s] %s tried to join as bot (%s)", date("d.m.y"), $player->getName(), AntiCheatManager::ERROR_BOT));
                    $this->plugin->getLogger()->info(sprintf(TextFormat::YELLOW . "%s tried to join as bot (%s)", $player->getName(), AntiCheatManager::ERROR_BOT));
                    $player->kick(sprintf($kickMessage, $player->getName(), AntiCheatManager::ERROR_BOT));
                }
            }
            Telegram::sendMessage(sprintf("[%s] %s tried to join as bot (%s)", date("d.m.y"), $nickname, AntiCheatManager::ERROR_BOT));
            $this->plugin->getLogger()->info(sprintf(TextFormat::YELLOW . "%s tried to join as bot (%s)", $nickname, AntiCheatManager::ERROR_BOT));
            $event->setKickReason(PlayerPreLoginEvent::KICK_REASON_PLUGIN, sprintf($kickMessage, $nickname, AntiCheatManager::ERROR_BOT));
            return;
        }

        if (!(in_array($extraData["DeviceOS"], PracticeDeviceOS::DEVICE_OS_LIST, true))) {
            Telegram::sendMessage(sprintf("[%s] %s tried to join with Fake OS (%s)", date("d.m.y"), $nickname, AntiCheatManager::ERROR_FAKE_OS));
            $this->plugin->getLogger()->info(sprintf(TextFormat::YELLOW . "%s tried to join with Fake OS (%s)", $nickname, AntiCheatManager::ERROR_FAKE_OS));
            $event->setKickReason(PlayerPreLoginEvent::KICK_REASON_PLUGIN, sprintf($kickMessage, $nickname, AntiCheatManager::ERROR_FAKE_OS));
            return;
        }

        if (!(in_array($extraData["DeviceOS"], AntiCheatManager::NULL_MODELS, true)) && $extraData["DeviceModel"] === "") {
            Telegram::sendMessage(sprintf("[%s] %s tried to join with Fake OS (%s)", date("d.m.y"), $nickname, AntiCheatManager::ERROR_FAKE_OS));
            $this->plugin->getLogger()->info(sprintf(TextFormat::YELLOW . "%s tried to join with Fake OS (%s)", $nickname, AntiCheatManager::ERROR_FAKE_OS));
            $event->setKickReason(PlayerPreLoginEvent::KICK_REASON_PLUGIN, sprintf($kickMessage, $nickname, AntiCheatManager::ERROR_FAKE_OS));
            return;
        }

        if ($extraData["DeviceOS"] === DeviceOS::ANDROID) {
            $model = explode(" ", $extraData["DeviceModel"], 2)[0];
            if ($model !== strtoupper($model) && $model !== "") {
                Telegram::sendMessage(sprintf("[%s] %s tried to join with Toolbox (%s)", date("d.m.y"), $nickname, AntiCheatManager::ERROR_TOOLBOX));
                $this->plugin->getLogger()->info(sprintf(TextFormat::YELLOW . "%s tried to join with Toolbox (%s)", $nickname, AntiCheatManager::ERROR_TOOLBOX));
                $event->setKickReason(PlayerPreLoginEvent::KICK_REASON_PLUGIN, sprintf($kickMessage, $nickname, AntiCheatManager::ERROR_TOOLBOX));
                return;
            }
        }

        if ($extraData["DeviceOS"] === DeviceOS::IOS) {
            if ($extraData["DeviceId"] !== strtoupper($extraData["DeviceId"])) {
                Telegram::sendMessage(sprintf("[%s] %s tried to join with Fake OS (%s)", date("d.m.y"), $nickname, AntiCheatManager::ERROR_FAKE_OS));
                $this->plugin->getLogger()->info(sprintf(TextFormat::YELLOW . "%s tried to join with Fake OS (%s)", $nickname, AntiCheatManager::ERROR_FAKE_OS));
                $event->setKickReason(PlayerPreLoginEvent::KICK_REASON_PLUGIN, sprintf($kickMessage, $nickname, AntiCheatManager::ERROR_FAKE_OS));
            }
        }
    }

    /**
     * @param EntityDamageByEntityEvent $event
     * @return void
     */
    public function handleEntityDamageByEntityEvent(EntityDamageByEntityEvent $event): void
    {
        if ($event->getCause() === EntityDamageEvent::CAUSE_ENTITY_ATTACK) {
            $entity = $event->getEntity();
            if ($entity instanceof PracticePlayer) {
                $damager = $event->getDamager();
                if ($damager instanceof PracticePlayer) {
                    if ($damager->getLocation()->distance($entity->getLocation()) > AntiCheatManager::MAX_HIT_DISTANCE) {
                        if ($damager->getRank() === RankManager::OWNER_RANK) {
                            return;
                        }
                        $event->cancel();
                        Telegram::sendMessage(sprintf("[%s] %s tried to use reach (%s)", date("d.m.y"), $damager->getName(), AntiCheatManager::ERROR_REACH));
                        $this->plugin->getLogger()->info(sprintf(TextFormat::YELLOW . "%s tried to use reach (%s)", $damager->getName(), AntiCheatManager::ERROR_REACH));
                        $damager->kick(sprintf($this->plugin->getTranslationManager()->translateAntiCheat($this->plugin->getLanguageManager()->getLanguage($damager), "inGameError"), $damager->getName(), AntiCheatManager::ERROR_REACH));
                    }
                }
            }
        }
    }

    /**
     * @param DataPacketReceiveEvent $event
     * @return void
     */
    public function handleDataPacketReceive(DataPacketReceiveEvent $event): void
    {
        $packet = $event->getPacket();
        $player = $event->getOrigin()->getPlayer();
        $antiCheatManager = $this->plugin->getAntiCheatManager();

        if (!($player instanceof PracticePlayer)) {
            return;
        }

        if (!(isset($antiCheatManager->packetsPerSecond[$player->getName()]))) {
            $antiCheatManager->packetsPerSecond[$player->getName()] = 0;
        }
        $antiCheatManager->packetsPerSecond[$player->getName()]++;

        if ($packet instanceof TextPacket) {
            if (mb_strlen($packet->message) > AntiCheatManager::MESSAGE_LENGTH_LIMIT) {
                if ($player->getRank() === RankManager::OWNER_RANK) {
                    return;
                }
                $event->cancel();
                Telegram::sendMessage(sprintf("[%s] %s tried to use TextPacket vulnerability (%s)", date("d.m.y"), $player->getName(), AntiCheatManager::ERROR_TEXT_PACKET_EXPLOIT));
                $this->plugin->getLogger()->info(sprintf(TextFormat::YELLOW . "%s tried to use TextPacket vulnerability (%s)", $player->getName(), AntiCheatManager::ERROR_TEXT_PACKET_EXPLOIT));
                $player->kick(sprintf($this->plugin->getTranslationManager()->translateAntiCheat($this->plugin->getLanguageManager()->getLanguage($player), "inGameError"), $player->getName(), AntiCheatManager::ERROR_TEXT_PACKET_EXPLOIT));
            }
        }
    }

    /**
     * @param PlayerQuitEvent $event
     * @return void
     */
    public function handlePlayerQuit(PlayerQuitEvent $event): void
    {
        $playerName = $event->getPlayer()->getName();

        if (isset($this->plugin->getAntiCheatManager()->packetsPerSecond[$playerName])) {
            unset($this->plugin->getAntiCheatManager()->packetsPerSecond[$playerName]);
        }
    }
}