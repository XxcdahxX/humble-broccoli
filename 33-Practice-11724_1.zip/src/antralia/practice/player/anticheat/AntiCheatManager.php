<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\player\anticheat;

use antralia\core\telegram\Telegram;
use antralia\practice\player\PracticePlayer;
use antralia\practice\player\rank\RankManager;
use antralia\practice\PracticePlugin;
use pocketmine\network\mcpe\protocol\types\DeviceOS;
use pocketmine\utils\TextFormat;

final class AntiCheatManager
{

    /**
     * @var string
     */
    public const ERROR_TOOLBOX = "Sheep";

    /**
     * @var string
     */
    public const ERROR_FAKE_OS = "Wolf";

    /**
     * @var string
     */
    public const ERROR_TOO_MANY_PACKETS = "Zombie";

    /**
     * @var string
     */
    public const ERROR_TEXT_PACKET_EXPLOIT = "Skeleton";

    /**
     * @var string
     */
    public const ERROR_TOO_MUCH_CPS = "Ocelot";

    /**
     * @var string
     */
    public const ERROR_REACH = "Enderman";

    /**
     * @var string
     */
    public const ERROR_BOT = "Sniffer";

    /**
     * @var array
     */
    public const NULL_MODELS = [
        DeviceOS::ANDROID,
        DeviceOS::OSX,
        DeviceOS::WINDOWS_10,
        DeviceOS::WIN32,
        DeviceOS::DEDICATED,
    ];

    /**
     * @var int
     */
    public const PACKET_LIMIT = 650;

    /**
     * @var int
     */
    public const MESSAGE_LENGTH_LIMIT = 500;

    /**
     * @var int
     */
    public const CPS_LIMIT = 50;

    /**
     * @var float
     */
    public const MAX_HIT_DISTANCE = 8.1;

    /**
     * @var int
     */
    public const IP_LIMIT = 3;

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @var array
     */
    public array $packetsPerSecond = array();

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @param PracticePlayer $player
     * @param int $cps
     * @return bool
     */
    public function processCPSCheck(PracticePlayer $player, int $cps): bool
    {
        if ($cps >= self::CPS_LIMIT) {
            if ($player->getRank() === RankManager::OWNER_RANK) {
                return false;
            }
            Telegram::sendMessage(sprintf("[%s] %s tried to click %s CPS, when limit is %s (%s)", date("d.m.y"), $player->getName(), $cps, self::CPS_LIMIT, self::ERROR_TOO_MUCH_CPS));
            $this->plugin->getLogger()->info(sprintf(TextFormat::YELLOW . "%s tried to click %s CPS, when limit is %s (%s)", $player->getName(), $cps, self::CPS_LIMIT, self::ERROR_TOO_MUCH_CPS));
            $player->kick(sprintf("In-game error (%s)\nCode: %s", $player->getName(), self::ERROR_TOO_MUCH_CPS));
            return true;
        } else {
            return false;
        }
    }
}