<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\player\statistics;

use antralia\core\form\SimpleForm;
use antralia\practice\player\PracticePlayer;
use antralia\practice\PracticePlugin;
use antralia\practice\utils\PracticeUtils;

final class StatisticsManager
{

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @var array<string, int>
     */
    private array $kills = [];

    /**
     * @var array<string, int>
     */
    private array $playTime = [];

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @param PracticePlayer $player
     * @return int
     */
    public function getKills(PracticePlayer $player): int
    {
        $query = $this->plugin->getProvider()->getDatabase()->prepare("SELECT `kills` FROM `statistics` WHERE `xuid` = :xuid;");
        $query->bindValue(":xuid", $player->getXuid());
        $result = $query->execute()->fetchArray(SQLITE3_ASSOC);

        if (!($result)) {
            return 0;
        } else {
            return $result["kills"];
        }
    }

    /**
     * @param PracticePlayer $player
     * @param int $value
     * @return void
     */
    public function addKill(PracticePlayer $player, int $value = 1): void
    {
        $kills = $this->getKills($player) + $value;

        $query = $this->plugin->getProvider()->getDatabase()->prepare("UPDATE `statistics` SET `kills` = :kills WHERE `xuid` = :xuid;");
        $query->bindValue(":kills", $kills, SQLITE3_INTEGER);
        $query->bindValue(":xuid", $player->getXuid());
        $query->execute();

        $this->kills[$player->getName()] = $kills;
    }

    /**
     * @param PracticePlayer $player
     * @return int
     */
    public function getDeaths(PracticePlayer $player): int
    {
        $query = $this->plugin->getProvider()->getDatabase()->prepare("SELECT `deaths` FROM `statistics` WHERE `xuid` = :xuid;");
        $query->bindValue(":xuid", $player->getXuid());
        $result = $query->execute()->fetchArray(SQLITE3_ASSOC);

        if (!($result)) {
            return 0;
        } else {
            return $result["deaths"];
        }
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function setKillsToArray(PracticePlayer $player): void
    {
        $this->kills[$player->getName()] = $this->getKills($player);
    }

    /**
     * @param PracticePlayer $player
     * @return int
     */
    public function getKillsFromArray(PracticePlayer $player): int
    {
        return !(isset($this->kills[$player->getName()])) ? 0 : $this->kills[$player->getName()];
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function removeKillsFromArray(PracticePlayer $player): void
    {
        if (isset($this->kills[$player->getName()])) {
            unset($this->kills[$player->getName()]);
        }
    }

    /**
     * @param PracticePlayer $player
     * @param int $value
     * @return void
     */
    public function addDeath(PracticePlayer $player, int $value = 1): void
    {
        $deaths = $this->getDeaths($player) + $value;

        $query = $this->plugin->getProvider()->getDatabase()->prepare("UPDATE `statistics` SET `deaths` = :deaths WHERE `xuid` = :xuid;");
        $query->bindValue(":deaths", $deaths, SQLITE3_INTEGER);
        $query->bindValue(":xuid", $player->getXuid());
        $query->execute();
    }

    /**
     * @param PracticePlayer $player
     * @return string
     */
    public function getDivisionColored(PracticePlayer $player): string
    {
        $kills = $this->getKills($player);

        if ($kills >= 0 && $kills < 50) {
            return "§6Bronze";
        } elseif ($kills >= 50 && $kills < 100) {
            return "§7Silver";
        } elseif ($kills >= 100 && $kills < 150) {
            return "§eGold";
        } elseif ($kills >= 150 && $kills < 200) {
            return "§dPlatinum";
        } elseif ($kills >= 200 && $kills < 300) {
            return "§bDiamond";
        } elseif ($kills >= 300 && $kills < 400) {
            return "§aEmerald";
        } elseif ($kills >= 400 && $kills < 500) {
            return "§8Netherite";
        } elseif ($kills >= 500 && $kills < 1000) {
            return "§5Sapphire";
        } elseif ($kills >= 1000 && $kills < 2000) {
            return "§cMaster";
        } elseif ($kills >= 2000) {
            return "§cMaster§e+";
        } else {
            return "§0Bedrock";
        }
    }

    /**
     * @param PracticePlayer $player
     * @return string
     */
    public function getDivisionColoredFromArray(PracticePlayer $player): string
    {
        $kills = $this->getKillsFromArray($player);

        if ($kills >= 0 && $kills < 50) {
            return "§6Bronze";
        } elseif ($kills >= 50 && $kills < 100) {
            return "§7Silver";
        } elseif ($kills >= 100 && $kills < 150) {
            return "§eGold";
        } elseif ($kills >= 150 && $kills < 200) {
            return "§dPlatinum";
        } elseif ($kills >= 200 && $kills < 300) {
            return "§bDiamond";
        } elseif ($kills >= 300 && $kills < 400) {
            return "§aEmerald";
        } elseif ($kills >= 400 && $kills < 500) {
            return "§8Netherite";
        } elseif ($kills >= 500 && $kills < 1000) {
            return "§5Sapphire";
        } elseif ($kills >= 1000 && $kills < 2000) {
            return "§cMaster";
        } elseif ($kills >= 2000) {
            return "§cMaster§e+";
        } else {
            return "§0Bedrock";
        }
    }

    /**
     * @param PracticePlayer $player
     * @return int|float
     */
    public function getKillDeathRatio(PracticePlayer $player): int|float
    {
        $kills = $this->getKills($player);
        $deaths = $this->getDeaths($player);

        if ($deaths === 0) {
            return $kills;
        } else {
            return round(($kills / $deaths), 2);
        }
    }

    /**
     * @param PracticePlayer $player
     * @return int
     */
    public function getPlayTime(PracticePlayer $player): int
    {
        $query = $this->plugin->getProvider()->getDatabase()->prepare("SELECT `playtime` FROM `statistics` WHERE `xuid` = :xuid;");
        $query->bindValue(":xuid", $player->getXuid());
        $result = $query->execute()->fetchArray(SQLITE3_ASSOC);

        if (!($result)) {
            return 0;
        } else {
            return $result["playtime"];
        }
    }

    /**
     * @param PracticePlayer $player
     * @return int
     */
    public function getPlayTimeForForm(PracticePlayer $player): int
    {
        return PracticeUtils::convertTimeStampToHours(($this->getPlayTime($player) + $this->getPlayTimeFromArray($player)));
    }

    /**
     * @param PracticePlayer $player
     * @param int $value
     * @return void
     */
    public function addPlayTime(PracticePlayer $player, int $value): void
    {
        $playTime = $this->getPlayTime($player) + $value;

        $query = $this->plugin->getProvider()->getDatabase()->prepare("UPDATE `statistics` SET `playtime` = :playtime WHERE `xuid` = :xuid;");
        $query->bindValue(":playtime", $playTime, SQLITE3_INTEGER);
        $query->bindValue(":xuid", $player->getXuid());
        $query->execute();
    }

    /**
     * @param PracticePlayer $player
     * @return int
     */
    public function getPlayTimeFromArray(PracticePlayer $player): int
    {
        return time() - ($this->playTime[$player->getName()] ?? time());
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function setPlayTimeToArray(PracticePlayer $player): void
    {
        $this->playTime[$player->getName()] = time();
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function removePlayTimeFromArray(PracticePlayer $player): void
    {
        if (isset($this->playTime[$player->getName()])) {
            unset($this->playTime[$player->getName()]);
        }
    }

    /**
     * @param PracticePlayer $player
     * @return string
     */
    public function getTopKillersForPlayer(PracticePlayer $player): string
    {
        $query = $this->plugin->getProvider()->getDatabase()->prepare("SELECT * FROM `statistics` WHERE `kills` > 0 ORDER BY `kills` DESC LIMIT 10;");
        $result = $query->execute();

        if ($result === false) {
            return "";
        }

        $array = [];
        $rowCount = 1;
        while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
            if ($rowCount === 1) {
                $color = "§6";
            } else {
                $color = "§e";
            }
            $array[] = sprintf($this->plugin->getTranslationManager()->translate($player, "topKillersForm")[1], $color, $rowCount++, $row["nickname"], $row["kills"]);
        }

        $result = implode("\n", $array);
        return $result === "" ? ":(" : $result;
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function sendStatisticsForm(PracticePlayer $player): void
    {
        $form = new SimpleForm(function (PracticePlayer $player, int $data = null): void {
            if ($data === null) {
                return;
            }

            if ($data === 0) {
                $this->sendTopKillersForm($player);
            }
        });

        $formContents = $this->plugin->getTranslationManager()->translate($player, "statisticsForm");

        $form->setTitle($formContents[0]);

        $form->setContent(sprintf(
            $formContents[1],
            $this->getDivisionColored($player),
            (string)$this->getKills($player),
            (string)$this->getDeaths($player),
            (string)$this->getKillDeathRatio($player),
            (string)$this->getPlayTimeForForm($player)
        ));
        $form->addButton($formContents[2]);

        $player->sendForm($form);
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function sendTopKillersForm(PracticePlayer $player): void
    {
        $form = new SimpleForm(function (PracticePlayer $player, int $data = null): void {
            if ($data === null) {
                return;
            }

            if ($data === 0) {
                $this->sendStatisticsForm($player);
            }
        });

        $formContents = $this->plugin->getTranslationManager()->translate($player, "topKillersForm");

        $form->setTitle($formContents[0]);

        $form->setContent($this->getTopKillersForPlayer($player));
        $form->addButton($formContents[2]);

        $player->sendForm($form);
    }
}