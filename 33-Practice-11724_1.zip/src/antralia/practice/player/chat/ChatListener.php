<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\player\chat;

use antralia\practice\player\PracticePlayer;
use antralia\practice\player\rank\PlayerRankChangeEvent;
use antralia\practice\player\rank\RankManager;
use antralia\practice\PracticePlugin;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\utils\TextFormat;

final class ChatListener implements Listener
{

    /**
     * @var int
     */
    public const CHAT_COOLDOWN = 1;

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @var array<string, int>
     */
    private array $chatCooldown = [];

    /**
     * @var array<string, string>
     */
    private array $lastMessage = [];

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @param PlayerJoinEvent $event
     * @return void
     */
    public function playerJoin(PlayerJoinEvent $event): void
    {
        $player = $event->getPlayer();

        if (!($player instanceof PracticePlayer)) {
            return;
        }

        $player->setNameTag($this->plugin->getChatManager()->getNameTagFormat($player));
    }

    /**
     * @param PlayerRankChangeEvent $event
     * @return void
     */
    public function handlePlayerRankChange(PlayerRankChangeEvent $event): void
    {
        $player = $event->getPlayer();

        if ($this->plugin->getServer()->getPlayerExact($player->getName()) !== null) {
            $player->setNameTag($this->plugin->getChatManager()->getNameTagFormat($player));
        }
    }

    /**
     * @param PlayerChatEvent $event
     * @return void
     */
    public function handlePlayerChat(PlayerChatEvent $event): void
    {
        $player = $event->getPlayer();

        if (!($player instanceof PracticePlayer)) {
            return;
        }

        $playerName = $player->getName();
        $message = $event->getMessage();

        $chatManager = $this->plugin->getChatManager();
        $chatFormat = $chatManager->getChatFormat($player);

        $translationManager = $this->plugin->getTranslationManager();

        if (mb_strlen($message) > ChatManager::MESSAGE_LENGTH_LIMIT) {
            if ($player->getRank() !== RankManager::OWNER_RANK) {
                $event->cancel();
                $player->sendMessage($translationManager->translate($player, "chatLongMessage"));
                return;
            }
        }

        if (isset($this->chatCooldown[$playerName])) {
            if (time() - $this->chatCooldown[$playerName] <= self::CHAT_COOLDOWN) {
                if ($player->getRank() !== RankManager::OWNER_RANK) {
                    $event->cancel();
                    $player->sendMessage($translationManager->translate($player, "chatCooldown"));
                    return;
                }
            }
        }
        $this->chatCooldown[$playerName] = time();

        if (isset($this->lastMessage[$playerName])) {
            if (strtolower($this->lastMessage[$playerName]) == strtolower($message)) {
                if ($player->getRank() !== RankManager::OWNER_RANK) {
                    $event->cancel();
                    $player->sendMessage($translationManager->translate($player, "chatCooldown"));
                    return;
                }
            }
        }
        $this->lastMessage[$playerName] = $message;

        $tagsManager = $this->plugin->getTagsManager();
        $message = str_replace([":skull:", ":fire:", ":eyes:", ":clown:", ":100:", ":laugh:"], ["", "", "", "", "", ""], trim(TextFormat::clean($message)));

        if ($tagsManager->hasTagFromArray($player)) {
            $tagFormat = $chatManager->getTagFormat($player);
            $event->setFormat($tagFormat . $chatFormat . $message);
        } else {
            $event->setFormat($chatFormat . $message);
        }
    }

    /**
     * @param PlayerQuitEvent $event
     * @return void
     */
    public function handlePlayerQuit(PlayerQuitEvent $event): void
    {
        $player = $event->getPlayer();

        if (!($player instanceof PracticePlayer)) {
            return;
        }

        if (isset($this->chatCooldown[$player->getName()])) {
            unset($this->chatCooldown[$player->getName()]);
        }

        if (isset($this->lastMessage[$player->getName()])) {
            unset($this->lastMessage[$player->getName()]);
        }

        $this->plugin->getChatManager()->removeReplyPlayer($player);
    }
}