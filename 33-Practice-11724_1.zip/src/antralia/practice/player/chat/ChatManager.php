<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\player\chat;

use antralia\practice\player\PracticePlayer;
use antralia\practice\player\rank\RankManager;
use antralia\practice\PracticePlugin;

final class ChatManager
{

    /**
     * @var int
     */
    public const MESSAGE_LENGTH_LIMIT = 125;

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @var array<string, string>
     */
    private array $reply = [];

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @param PracticePlayer $player
     * @return string
     */
    public function getChatFormat(PracticePlayer $player): string
    {
        $nickname = $player->getName();

        return match ($player->getRank()) {
            RankManager::PLAYER_RANK => "§f" . $nickname . ": §7",
            RankManager::MYSTERY_RANK => "§l§5Mystery §r§f" . $nickname . ": §5",
            RankManager::GANGSTER_RANK => "§l§aGangster §r§f" . $nickname . ": §a",
            RankManager::IMMORTAL_RANK => "§l§dImmortal §r§f" . $nickname . ": §d",
            RankManager::SNOWMAN_RANK => "§l§fSnow§9man §r§f" . $nickname . ": §9",
            RankManager::BOOSTER_RANK => "§l§gBooster §r§f" . $nickname . ": §g",
            RankManager::FAMOUS_RANK => "§l§6Famous §r§f" . $nickname . ": §6",
            RankManager::MODERATOR_RANK => "§l§bModerator §r§f" . $nickname . ": §b",
            RankManager::ADMIN_RANK => "§l§3Admin §r§f" . $nickname . ": §3",
            RankManager::BUILDER_RANK => "§l§eBuilder §r§f" . $nickname . ": §e",
            RankManager::STAFF_RANK => "§l§cStaff §r§f" . $nickname . ": §c",
            RankManager::OWNER_RANK => "§l§4Owner §r§f" . $nickname . ": §4",
            default => "§8" . $nickname . ": "
        };
    }

    /**
     * @param PracticePlayer $player
     * @return string
     */
    public function getNameTagFormat(PracticePlayer $player): string
    {
        $nickname = $player->getName();

        $format = match ($player->getRank()) {
            RankManager::PLAYER_RANK => "§f" . $nickname,
            RankManager::MYSTERY_RANK => "§5" . $nickname,
            RankManager::GANGSTER_RANK => "§a" . $nickname,
            RankManager::IMMORTAL_RANK => "§d" . $nickname,
            RankManager::SNOWMAN_RANK => "§9" . $nickname,
            RankManager::BOOSTER_RANK => "§g" . $nickname,
            RankManager::FAMOUS_RANK => "§6" . $nickname,
            RankManager::MODERATOR_RANK => "§b" . $nickname,
            RankManager::ADMIN_RANK => "§3" . $nickname,
            RankManager::BUILDER_RANK => "§e" . $nickname,
            RankManager::STAFF_RANK => "§c" . $nickname,
            RankManager::OWNER_RANK => "§4" . $nickname,
            default => "§8" . $nickname
        };
        return $player->getDeviceOSIcon() . " " . $format;
    }

    /**
     * @param PracticePlayer $player
     * @return string
     */
    public function getTagFormat(PracticePlayer $player): string
    {
        return $player->hasPermission("practice.cosmetics.tags.silver") ? "§l" . $this->plugin->getTagsManager()->getTagFromArrayColored($player) . "§r " : "";
    }

    /**
     * @param PracticePlayer $player
     * @param PracticePlayer $replyTo
     * @return void
     */
    public function setReplyPlayer(PracticePlayer $player, PracticePlayer $replyTo): void
    {
        $this->reply[$player->getName()] = $replyTo->getName();
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function removeReplyPlayer(PracticePlayer $player): void
    {
        if (isset($this->reply[$player->getName()])) {
            unset($this->reply[$player->getName()]);
        }
    }

    /**
     * @param PracticePlayer $player
     * @return PracticePlayer|null
     */
    public function getReplyPlayer(PracticePlayer $player): ?PracticePlayer
    {
        if (isset($this->reply[$player->getName()])) {
            if (($replyTo = $this->plugin->getServer()->getPlayerExact($this->reply[$player->getName()]))) {
                if ($replyTo instanceof PracticePlayer) {
                    return $replyTo;
                } else {
                    unset($this->reply[$player->getName()]);
                    return null;
                }
            } else {
                unset($this->reply[$player->getName()]);
                return null;
            }
        } else {
            return null;
        }
    }
}