<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\player\chat\command;

use antralia\practice\command\CommandArgs;
use antralia\practice\command\PracticeCommand;
use antralia\practice\player\chat\ChatManager;
use antralia\practice\player\PracticePlayer;
use antralia\practice\player\rank\RankManager;
use antralia\practice\PracticePlugin;
use pocketmine\command\CommandSender;
use pocketmine\utils\TextFormat;

final class ReplyCommand extends PracticeCommand
{

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;

        $this->setPermission("practice.command.reply");
        $this->commandArg = new CommandArgs();
        $this->commandArg->addParameter(0, "message");

        parent::__construct("reply", "Reply to player's message", "Usage: /reply <message>", ["r"]);
    }

    /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     * @return bool
     */
    public function execute(CommandSender $sender, string $commandLabel, array $args): bool
    {
        if (!($this->testPermission($sender))) {
            return false;
        }

        if (!($sender instanceof PracticePlayer)) {
            $sender->sendMessage(TextFormat::RED . "Only for players!");
            return true;
        }

        $translationManager = $this->plugin->getTranslationManager();

        if (!(isset($args[0]))) {
            $sender->sendMessage($translationManager->translate($sender, "replyUsage"));
            return true;
        }

        $chatManager = $this->plugin->getChatManager();
        $punishmentManager = $this->plugin->getPunishmentManager();
        $player = $chatManager->getReplyPlayer($sender);
        $message = implode(" ", $args);

        if ($player) {
            if ($punishmentManager->isMutedFromArray($sender)) {
                $sender->sendMessage(sprintf(
                    $this->plugin->getTranslationManager()->translate($sender, "muteMessage"),
                    $punishmentManager->getMutedNickname($sender),
                    $punishmentManager->getMuteDate($sender),
                    $punishmentManager->getMuteReason($sender),
                    $punishmentManager->getMuteExpiry($sender)
                ));
                return true;
            }

            if (mb_strlen($message) > ChatManager::MESSAGE_LENGTH_LIMIT) {
                if ($sender->getRank() !== RankManager::OWNER_RANK) {
                    $player->sendMessage($translationManager->translate($player, "chatLongMessage"));
                    return true;
                }
            }

            $chatManager->setReplyPlayer($player, $sender);
            $sender->sendMessage(sprintf($translationManager->translate($sender, "replySelf"), $player->getName(), $message));
            $player->sendMessage(sprintf($translationManager->translate($player, "replyAnother"), $sender->getName(), $message));
            $this->plugin->getLogger()->info(sprintf("%s to %s: %s", $sender->getName(), $player->getName(), $message));
        } else {
            $sender->sendMessage($translationManager->translate($sender, "replyNoOneTo"));
        }
        return true;
    }

    /**
     * @param PracticePlayer $player
     * @return string
     */
    public function getDescriptionForPlayer(PracticePlayer $player): string
    {
        return $this->plugin->getTranslationManager()->translate($player, "replyCommandDescription");
    }
}