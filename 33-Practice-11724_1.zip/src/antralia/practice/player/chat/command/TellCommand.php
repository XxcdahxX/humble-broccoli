<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\player\chat\command;

use antralia\practice\command\CommandArgs;
use antralia\practice\command\PracticeCommand;
use antralia\practice\player\chat\ChatManager;
use antralia\practice\player\PracticePlayer;
use antralia\practice\player\rank\RankManager;
use antralia\practice\PracticePlugin;
use antralia\practice\utils\PracticeUtils;
use pocketmine\command\CommandSender;
use pocketmine\network\mcpe\protocol\AvailableCommandsPacket;
use pocketmine\utils\TextFormat;

final class TellCommand extends PracticeCommand
{

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;

        $this->setPermission("practice.command.tell");
        $this->commandArg = new CommandArgs();
        $this->commandArg->addParameter(0, "player", AvailableCommandsPacket::ARG_TYPE_TARGET);
        $this->commandArg->addParameter(0, "message");

        parent::__construct("tell", "Send a message to player", "Usage: /tell <player> <message>", ["whisper", "message", "msg", "w", "m"]);
    }

    /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     * @return bool
     */
    public function execute(CommandSender $sender, string $commandLabel, array $args): bool
    {
        if (!($this->testPermission($sender))) {
            return false;
        }

        $translationManager = $this->plugin->getTranslationManager();

        if (!(isset($args[0])) || !(isset($args[1]))) {
            if ($sender instanceof PracticePlayer) {
                $sender->sendMessage($translationManager->translate($sender, "tellUsage"));
            } else {
                $sender->sendMessage($this->usageMessage);
            }
        } else {
            $nickname = array_shift($args);
            $message = implode(" ", $args);
            $player = PracticeUtils::getPlayerByPrefix($nickname);

            $punishmentManager = $this->plugin->getPunishmentManager();

            if ($player) {
                if (!($player instanceof PracticePlayer)) {
                    return true;
                }

                if ($sender instanceof PracticePlayer) {
                    if ($punishmentManager->isMutedFromArray($sender)) {
                        $sender->sendMessage(sprintf(
                            $this->plugin->getTranslationManager()->translate($sender, "muteMessage"),
                            $punishmentManager->getMutedNickname($sender),
                            $punishmentManager->getMuteDate($sender),
                            $punishmentManager->getMuteReason($sender),
                            $punishmentManager->getMuteExpiry($sender)
                        ));
                        return true;
                    }

                    if ($sender->getName() === $player->getName()) {
                        $sender->sendMessage($translationManager->translate($sender, "tellSelfError"));
                        return true;
                    }

                    if (mb_strlen($message) > ChatManager::MESSAGE_LENGTH_LIMIT) {
                        if ($sender->getRank() !== RankManager::OWNER_RANK) {
                            $player->sendMessage($translationManager->translate($player, "chatLongMessage"));
                            return true;
                        }
                    }

                    $sender->sendMessage(sprintf($translationManager->translate($sender, "tellSelf"), $player->getName(), $message));
                    $player->sendMessage(sprintf($translationManager->translate($player, "tellAnother"), $sender->getName(), $message));
                    $this->plugin->getChatManager()->setReplyPlayer($player, $sender);
                } else {
                    $sender->sendMessage(TextFormat::YELLOW . "Your message to " . $player->getName() . ": " . $message);
                    $player->sendMessage(sprintf($translationManager->translate($player, "tellAnother"), $sender->getName(), $message));
                }
                $this->plugin->getLogger()->info(sprintf("%s to %s: %s", $sender->getName(), $player->getName(), $message));
            } elseif ($sender instanceof PracticePlayer) {
                if ($punishmentManager->isMutedFromArray($sender)) {
                    $sender->sendMessage(sprintf(
                        $this->plugin->getTranslationManager()->translate($sender, "muteMessage"),
                        $punishmentManager->getMutedNickname($sender),
                        $punishmentManager->getMuteDate($sender),
                        $punishmentManager->getMuteReason($sender),
                        $punishmentManager->getMuteExpiry($sender)
                    ));
                    return true;
                }
                $sender->sendMessage($translationManager->translate($sender, "playerNotFound"));
            } else {
                $sender->sendMessage(TextFormat::RED . "Player not found!");
            }
        }
        return true;
    }

    /**
     * @param PracticePlayer $player
     * @return string
     */
    public function getDescriptionForPlayer(PracticePlayer $player): string
    {
        return $this->plugin->getTranslationManager()->translate($player, "tellCommandDescription");
    }
}