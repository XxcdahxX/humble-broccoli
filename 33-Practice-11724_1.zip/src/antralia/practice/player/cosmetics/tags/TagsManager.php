<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\player\cosmetics\tags;

use antralia\core\form\SimpleForm;
use antralia\practice\player\PracticePlayer;
use antralia\practice\PracticePlugin;

final class TagsManager
{

    /**
     * @var string[]
     */
    public const SILVER_TAGS = [
        "E-GIRL",
        "BESTWW",
        "GOD",
        "LIT",
        "LUNAR",
        "STARDUST",
        "CHOPPA",
        "CLOUTLORD"
    ];

    /**
     * @var string[]
     */
    public const GOLDEN_TAGS = [
        "ANTRALIA",
        "JUGG",
        "FINESSE",
        "MEMPHIS",
        "LEANDOER",
        "CAPYBARA",
        "SHOOTA",
        "L",
        "W"
    ];

    /**
     * @var string[]
     */
    public const PLATINUM_TAGS = [
        "SANTA",
        "TRIPPY",
        "MAFIA",
        "ALCOHOLIC",
        "BLATANT",
        "JUICY",
        "OG",
        "BROKE",
        "INDIAN",
        "GOAT"
    ];

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @var array<string, string>
     */
    private array $tags = [];

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @param PracticePlayer $player
     * @return bool
     */
    public function hasTag(PracticePlayer $player): bool
    {
        $query = $this->plugin->getProvider()->getDatabase()->prepare("SELECT `tag` FROM `cosmetics` WHERE `xuid` = :xuid;");
        $query->bindValue(":xuid", $player->getXuid());
        $result = $query->execute()->fetchArray(SQLITE3_ASSOC);

        if (!($result) || $result["tag"] === "disabled") {
            return false;
        } else {
            return true;
        }
    }

    /**
     * @param PracticePlayer $player
     * @return bool
     */
    public function hasTagFromArray(PracticePlayer $player): bool
    {
        return isset($this->tags[$player->getName()]);
    }

    /**
     * @param PracticePlayer $player
     * @return string
     */
    public function getTag(PracticePlayer $player): string
    {
        $query = $this->plugin->getProvider()->getDatabase()->prepare("SELECT `tag` FROM `cosmetics` WHERE `xuid` = :xuid;");
        $query->bindValue(":xuid", $player->getXuid());
        $result = $query->execute()->fetchArray(SQLITE3_ASSOC);

        if (!($result) || $result["tag"] === "disabled") {
            return "default";
        } else {
            return $result["tag"];
        }
    }

    /**
     * @param PracticePlayer $player
     * @return string
     */
    public function getTagType(PracticePlayer $player): string
    {
        if ($this->hasTag($player)) {
            if (in_array($this->getTag($player), self::SILVER_TAGS)) {
                return "silver";
            } elseif (in_array($this->getTag($player), self::GOLDEN_TAGS)) {
                return "golden";
            } elseif (in_array($this->getTag($player), self::PLATINUM_TAGS)) {
                return "platinum";
            } else {
                return "undefined";
            }
        } else {
            return "undefined";
        }
    }

    /**
     * @param PracticePlayer $player
     * @return string
     */
    public function getTagColoredForForm(PracticePlayer $player): string
    {
        return match ($this->getTag($player)) {
            "E-GIRL" => "§dE-GIRL",
            "BESTWW" => "§cBESTWW",
            "GOD" => "§6GOD",
            "LIT" => "§eLIT",
            "LUNAR" => "§dLUNAR",
            "STARDUST" => "§7STARDUST",
            "CHOPPA" => "§8CHOPPA",
            "CLOUTLORD" => "§fCLOUTLORD",
            "ANTRALIA" => "§aANTRALIA",
            "JUGG" => "§2JUGG",
            "FINESSE" => "§bFINESSE",
            "MEMPHIS" => "§cMEMPHIS",
            "LEANDOER" => "§5LEANDOER",
            "CAPYBARA" => "§gCAPYBARA",
            "SHOOTA" => "§3SHOOTA",
            "L" => "§6L",
            "W" => "§4W",
            "SANTA" => "§cSANTA",
            "TRIPPY" => "§dTRIPPY",
            "MAFIA" => "§4MAFIA",
            "ALCOHOLIC" => "§3ALCOHOLIC",
            "BLATANT" => "§bBLATANT",
            "JUICY" => "§eJUICY",
            "OG" => "§6OG",
            "BROKE" => "§gBROKE",
            "INDIAN" => "§2INDIAN",
            "GOAT" => "§5GOAT",
            default => "§7-"
        };
    }

    /**
     * @param PracticePlayer $player
     * @return string
     */
    public function getTagFromArrayColored(PracticePlayer $player): string
    {
        return match ($this->getTagFromArray($player)) {
            "E-GIRL" => "§dE-GIRL",
            "BESTWW" => "§cBESTWW",
            "GOD" => "§6GOD",
            "LIT" => "§eLIT",
            "LUNAR" => "§dLUNAR",
            "STARDUST" => "§7STARDUST",
            "CHOPPA" => "§8CHOPPA",
            "CLOUTLORD" => "§fCLOUTLORD",
            "ANTRALIA" => "§aANTRALIA",
            "JUGG" => "§2JUGG",
            "FINESSE" => "§bFINESSE",
            "MEMPHIS" => "§cMEMPHIS",
            "LEANDOER" => "§5LEANDOER",
            "CAPYBARA" => "§gCAPYBARA",
            "SHOOTA" => "§3SHOOTA",
            "L" => "§6L",
            "W" => "§4W",
            "SANTA" => "§cSANTA",
            "TRIPPY" => "§dTRIPPY",
            "MAFIA" => "§4MAFIA",
            "ALCOHOLIC" => "§3ALCOHOLIC",
            "BLATANT" => "§bBLATANT",
            "JUICY" => "§eJUICY",
            "OG" => "§6OG",
            "BROKE" => "§gBROKE",
            "INDIAN" => "§2INDIAN",
            "GOAT" => "§5GOAT",
            default => "§0???"
        };
    }

    /**
     * @param PracticePlayer $player
     * @return string
     */
    public function getTagFromArray(PracticePlayer $player): string
    {
        return $this->hasTagFromArray($player) ? $this->tags[$player->getName()] : "default";
    }

    /**
     * @param PracticePlayer $player
     * @param string $tag
     * @return void
     */
    public function setTag(PracticePlayer $player, string $tag): void
    {
        if (!(in_array($tag, self::SILVER_TAGS, true) || in_array($tag, self::GOLDEN_TAGS, true) || in_array($tag, self::PLATINUM_TAGS, true))) {
            $this->plugin->getLogger()->alert("Undefined tag: " . $tag);
            return;
        }

        $query = $this->plugin->getProvider()->getDatabase()->prepare("UPDATE `cosmetics` SET `tag` = :tag WHERE `xuid` = :xuid;");
        $query->bindValue(":tag", $tag);
        $query->bindValue(":xuid", $player->getXuid());
        $query->execute();

        $this->setTagToArray($player, $tag);
    }

    /**
     * @param PracticePlayer $player
     * @param string $tag
     * @return void
     */
    public function setTagToArray(PracticePlayer $player, string $tag): void
    {
        if (!(in_array($tag, self::SILVER_TAGS, true) || in_array($tag, self::GOLDEN_TAGS, true) || in_array($tag, self::PLATINUM_TAGS, true))) {
            $this->plugin->getLogger()->alert("Undefined tag: " . $tag);
            return;
        }

        $this->tags[$player->getName()] = $tag;
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function removeTag(PracticePlayer $player): void
    {
        if ($this->hasTag($player)) {
            $query = $this->plugin->getProvider()->getDatabase()->prepare("UPDATE `cosmetics` SET `tag` = :tag WHERE `xuid` = :xuid;");
            $query->bindValue(":tag", "disabled");
            $query->bindValue(":xuid", $player->getXuid());
            $query->execute();
            $this->removeTagFromArray($player);
        }
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function removeTagFromArray(PracticePlayer $player): void
    {
        if (isset($this->tags[$player->getName()])) {
            unset($this->tags[$player->getName()]);
        }
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function sendTagsForm(PracticePlayer $player): void
    {
        if (!($player->hasPermission("practice.cosmetics.tags.silver"))) {
            $player->sendMessage($this->plugin->getTranslationManager()->translate($player, "tagsNoPermission"));
            return;
        }

        $form = new SimpleForm(function (PracticePlayer $player, int $data = null): void {
            if ($data === null) {
                return;
            }

            $translationManager = $this->plugin->getTranslationManager();

            switch ($data) {
                case 0:
                    $this->sendSilverTagsForm($player);
                    break;
                case 1:
                    $this->sendGoldenTagsForm($player);
                    break;
                case 2:
                    $this->sendPlatinumTagsForm($player);
                    break;
                case 3:
                    if ($this->hasTag($player)) {
                        $this->removeTag($player);
                        $player->sendMessage($translationManager->translate($player, "tagDisabled"));
                    } else {
                        $player->sendMessage($translationManager->translate($player, "tagDoesNotSet"));
                    }
                    break;
                case 4:
                    $this->plugin->getCosmeticsManager()->sendCosmeticsForm($player);
                    break;
            }
        });

        $formContents = $this->plugin->getTranslationManager()->translate($player, "tagsForm");

        $form->setTitle($formContents[0]);

        $form->setContent(sprintf($formContents[1], $this->getTagColoredForForm($player)));

        $form->addButton($formContents[2], SimpleForm::IMAGE_TYPE_PATH, "textures/items/iron_ingot");
        $form->addButton($formContents[3], SimpleForm::IMAGE_TYPE_PATH, "textures/items/gold_ingot");
        $form->addButton($formContents[4], SimpleForm::IMAGE_TYPE_PATH, "textures/items/netherite_ingot");
        $form->addButton($formContents[5], SimpleForm::IMAGE_TYPE_PATH, "textures/blocks/barrier");
        $form->addButton($formContents[6], SimpleForm::IMAGE_TYPE_PATH, "textures/ui/arrow_left");

        $player->sendForm($form);
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function sendSilverTagsForm(PracticePlayer $player): void
    {
        if (!($player->hasPermission("practice.cosmetics.tags.silver"))) {
            $player->sendMessage($this->plugin->getTranslationManager()->translate($player, "silverTagsNoPermission"));
            return;
        }

        $form = new SimpleForm(function (PracticePlayer $player, int $data = null): void {
            if ($data === null) {
                return;
            }

            $translationManager = $this->plugin->getTranslationManager();

            $tag = "";
            switch ($data) {
                case 0:
                    $tag = "E-GIRL";
                    break;
                case 1:
                    $tag = "BESTWW";
                    break;
                case 2:
                    $tag = "GOD";
                    break;
                case 3:
                    $tag = "LIT";
                    break;
                case 4:
                    $tag = "LUNAR";
                    break;
                case 5:
                    $tag = "STARDUST";
                    break;
                case 6:
                    $tag = "CHOPPA";
                    break;
                case 7:
                    $tag = "CLOUTLORD";
                    break;
                case 8:
                    $this->sendTagsForm($player);
                    return;
            }

            if ($tag !== "") {
                if ($this->getTag($player) === $tag) {
                    $player->sendMessage($translationManager->translate($player, "tagAlreadySelected"));
                    return;
                }

                $this->setTag($player, $tag);
                $player->sendMessage(sprintf($translationManager->translate($player, "tagEnabled"), $tag));
            }
        });

        $formContents = $this->plugin->getTranslationManager()->translate($player, "silverTagsForm");

        $form->setTitle($formContents[0]);

        for ($i = 1; $i <= 9; $i++) {
            $form->addButton($formContents[$i]);
        }

        $player->sendForm($form);
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function sendGoldenTagsForm(PracticePlayer $player): void
    {
        if (!($player->hasPermission("practice.cosmetics.tags.golden"))) {
            $player->sendMessage($this->plugin->getTranslationManager()->translate($player, "goldenTagsNoPermission"));
            return;
        }

        $form = new SimpleForm(function (PracticePlayer $player, int $data = null): void {
            if ($data === null) {
                return;
            }

            $translationManager = $this->plugin->getTranslationManager();

            $tag = "";
            switch ($data) {
                case 0:
                    $tag = "ANTRALIA";
                    break;
                case 1:
                    $tag = "FINESSE";
                    break;
                case 2:
                    $tag = "MEMPHIS";
                    break;
                case 3:
                    $tag = "LEANDOER";
                    break;
                case 4:
                    $tag = "JUGG";
                    break;
                case 5:
                    $tag = "CAPYBARA";
                    break;
                case 6:
                    $tag = "SHOOTA";
                    break;
                case 7:
                    $tag = "L";
                    break;
                case 8:
                    $tag = "W";
                    break;
                case 9:
                    $this->sendTagsForm($player);
                    return;
            }

            if ($tag !== "") {
                if ($this->getTag($player) === $tag) {
                    $player->sendMessage($translationManager->translate($player, "tagAlreadySelected"));
                    return;
                }

                $this->setTag($player, $tag);
                $player->sendMessage(sprintf($translationManager->translate($player, "tagEnabled"), $tag));
            }
        });

        $formContents = $this->plugin->getTranslationManager()->translate($player, "goldenTagsForm");

        $form->setTitle($formContents[0]);

        for ($i = 1; $i <= 10; $i++) {
            $form->addButton($formContents[$i]);
        }

        $player->sendForm($form);
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function sendPlatinumTagsForm(PracticePlayer $player): void
    {
        if (!($player->hasPermission("practice.cosmetics.tags.platinum"))) {
            $player->sendMessage($this->plugin->getTranslationManager()->translate($player, "platinumTagsNoPermission"));
            return;
        }

        $form = new SimpleForm(function (PracticePlayer $player, int $data = null): void {
            if ($data === null) {
                return;
            }

            $translationManager = $this->plugin->getTranslationManager();

            $tag = "";
            switch ($data) {
                case 0:
                    $tag = "SANTA";
                    break;
                case 1:
                    $tag = "TRIPPY";
                    break;
                case 2:
                    $tag = "MAFIA";
                    break;
                case 3:
                    $tag = "ALCOHOLIC";
                    break;
                case 4:
                    $tag = "BLATANT";
                    break;
                case 5:
                    $tag = "JUICY";
                    break;
                case 6:
                    $tag = "OG";
                    break;
                case 7:
                    $tag = "BROKE";
                    break;
                case 8:
                    $tag = "INDIAN";
                    break;
                case 9:
                    $tag = "GOAT";
                    break;
                case 10:
                    $this->sendTagsForm($player);
                    return;
            }

            if ($tag !== "") {
                if ($this->getTag($player) === $tag) {
                    $player->sendMessage($translationManager->translate($player, "tagAlreadySelected"));
                    return;
                }

                $this->setTag($player, $tag);
                $player->sendMessage(sprintf($translationManager->translate($player, "tagEnabled"), $tag));
            }
        });

        $formContents = $this->plugin->getTranslationManager()->translate($player, "platinumTagsForm");

        $form->setTitle($formContents[0]);

        for ($i = 1; $i <= 11; $i++) {
            $form->addButton($formContents[$i]);
        }

        $player->sendForm($form);
    }
}