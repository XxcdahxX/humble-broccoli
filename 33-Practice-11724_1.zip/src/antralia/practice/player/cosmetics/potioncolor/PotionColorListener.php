<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\player\cosmetics\potioncolor;

use antralia\practice\player\PracticePlayer;
use antralia\practice\player\rank\PlayerRankChangeEvent;
use antralia\practice\PracticePlugin;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;

final class PotionColorListener implements Listener
{

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @param PlayerJoinEvent $event
     * @return void
     */
    public function handlePlayerJoin(PlayerJoinEvent $event): void
    {
        $player = $event->getPlayer();

        if (!($player instanceof PracticePlayer)) {
            return;
        }

        $potionColorManager = $this->plugin->getPotionColorManager();

        if ($potionColorManager->hasPotionColor($player)) {
            if (!($player->hasPermission("practice.cosmetics.potioncolor"))) {
                $potionColorManager->removePotionColor($player);
            } else {
                $potionColorManager->setPotionColorToArray($player, $potionColorManager->getPotionColor($player));
            }
        }
    }

    /**
     * @param PlayerRankChangeEvent $event
     * @return void
     */
    public function handlePlayerRankChange(PlayerRankChangeEvent $event): void
    {
        $player = $event->getPlayer();
        $potionColorManager = $this->plugin->getPotionColorManager();

        if ($potionColorManager->hasPotionColorFromArray($player)) {
            if (!($player->hasPermission("practice.cosmetics.potioncolor"))) {
                $potionColorManager->removePotionColor($player);
            }
        }
    }

    /**
     * @param PlayerQuitEvent $event
     * @return void
     */
    public function handlePlayerQuit(PlayerQuitEvent $event): void
    {
        $player = $event->getPlayer();

        if (!($player instanceof PracticePlayer)) {
            return;
        }

        $potionColorManager = $this->plugin->getPotionColorManager();

        if ($potionColorManager->hasPotionColorFromArray($player)) {
            $potionColorManager->removePotionColorFromArray($player);
        }
    }
}