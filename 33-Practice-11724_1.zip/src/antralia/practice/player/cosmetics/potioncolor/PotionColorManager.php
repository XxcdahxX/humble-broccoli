<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\player\cosmetics\potioncolor;

use antralia\core\form\SimpleForm;
use antralia\practice\player\PracticePlayer;
use antralia\practice\PracticePlugin;
use pocketmine\color\Color;
use pocketmine\world\particle\PotionSplashParticle;

final class PotionColorManager
{

    /**
     * @var string[]
     */
    public const COLORS = [
        "Red",
        "Dark_Red",
        "Blue",
        "Light_Blue",
        "Green",
        "Purple",
        "Yellow",
        "White",
        "Black"
    ];

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @var array<string, string>
     */
    private array $potionColors = [];

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @param PracticePlayer $player
     * @return bool
     */
    public function hasPotionColor(PracticePlayer $player): bool
    {
        $query = $this->plugin->getProvider()->getDatabase()->prepare("SELECT `potion_color` FROM `cosmetics` WHERE `xuid` = :xuid;");
        $query->bindValue(":xuid", $player->getXuid());
        $result = $query->execute()->fetchArray(SQLITE3_ASSOC);

        if (!($result) || $result["potion_color"] === "disabled") {
            return false;
        } else {
            return true;
        }
    }

    /**
     * @param PracticePlayer $player
     * @param string $color
     * @return void
     */
    public function setPotionColor(PracticePlayer $player, string $color): void
    {
        if (!(in_array($color, self::COLORS))) {
            $this->plugin->getLogger()->alert("Undefined potion color: " . $color);
            return;
        }

        $query = $this->plugin->getProvider()->getDatabase()->prepare("UPDATE `cosmetics` SET `potion_color` = :color WHERE `xuid` = :xuid;");
        $query->bindValue(":color", $color);
        $query->bindValue(":xuid", $player->getXuid());
        $query->execute();

        $this->setPotionColorToArray($player, $color);
    }

    /**
     * @param PracticePlayer $player
     * @return string
     */
    public function getPotionColor(PracticePlayer $player): string
    {
        $query = $this->plugin->getProvider()->getDatabase()->prepare("SELECT `potion_color` FROM `cosmetics` WHERE `xuid` = :xuid;");
        $query->bindValue(":xuid", $player->getXuid());
        $result = $query->execute()->fetchArray(SQLITE3_ASSOC);

        if (!($result) || $result["potion_color"] === "disabled") {
            return "default";
        } else {
            return $result["potion_color"];
        }
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function removePotionColor(PracticePlayer $player): void
    {
        if ($this->hasPotionColor($player)) {
            $query = $this->plugin->getProvider()->getDatabase()->prepare("UPDATE `cosmetics` SET `potion_color` = :color WHERE `xuid` = :xuid;");
            $query->bindValue(":color", "disabled");
            $query->bindValue(":xuid", $player->getXuid());
            $query->execute();

            $this->removePotionColorFromArray($player);
        }
    }

    /**
     * @param PracticePlayer $player
     * @return bool
     */
    public function hasPotionColorFromArray(PracticePlayer $player): bool
    {
        return isset($this->potionColors[$player->getName()]);
    }

    /**
     * @param PracticePlayer $player
     * @param string $color
     * @return void
     */
    public function setPotionColorToArray(PracticePlayer $player, string $color): void
    {
        if (!(in_array($color, self::COLORS))) {
            $this->plugin->getLogger()->alert("Undefined potion color: " . $color);
            return;
        }

        $this->potionColors[$player->getName()] = $color;
    }

    /**
     * @param PracticePlayer $player
     * @return string
     */
    public function getPotionColorFromArray(PracticePlayer $player): string
    {
        return $this->hasPotionColorFromArray($player) ? $this->potionColors[$player->getName()] : "default";
    }

    /**
     * @param PracticePlayer $player
     * @return Color
     */
    public function getPotionColorForGame(PracticePlayer $player): Color
    {
        if ($this->hasPotionColorFromArray($player)) {
            return match ($this->getPotionColorFromArray($player)) {
                "Red" => new Color(255, 0, 0),
                "Dark_Red" => new Color(139, 0, 0),
                "Blue" => new Color(0, 0, 255),
                "Light_Blue" => new Color(0, 255, 255),
                "Green" => new Color(0, 255, 0),
                "Purple" => new Color(153, 50, 204),
                "Yellow" => new Color(255,255, 0),
                "White" => new Color(255, 255, 255),
                "Black" => new Color(0, 0, 0)
            };
        } else {
            return PotionSplashParticle::DEFAULT_COLOR();
        }
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function removePotionColorFromArray(PracticePlayer $player): void
    {
        if (isset($this->potionColors[$player->getName()])) {
            unset($this->potionColors[$player->getName()]);
        }
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function sendPotionColorForm(PracticePlayer $player): void
    {
        if (!($player->hasPermission("practice.cosmetics.potioncolor"))) {
            $player->sendMessage($this->plugin->getTranslationManager()->translate($player, "potionColorNoPermission"));
            return;
        }

        $form = new SimpleForm(function (PracticePlayer $player, int $data = null): void {
            if ($data === null) {
                return;
            }

            $translationManager = $this->plugin->getTranslationManager();

            switch ($data) {
                case 0:
                    $this->sendPotionColorSelectionForm($player);
                    break;
                case 1:
                    if ($this->hasPotionColor($player)) {
                        $this->removePotionColor($player);
                        $player->sendMessage($translationManager->translate($player, "potionColorDisabled"));
                    } else {
                        $player->sendMessage($translationManager->translate($player, "potionColorAlreadyDisabled"));
                    }
                    break;
                case 2:
                    $this->plugin->getCosmeticsManager()->sendCosmeticsForm($player);
                    break;
            }
        });

        $translationManager = $this->plugin->getTranslationManager();
        $formContents = $translationManager->translate($player, "potionColorForm");

        $form->setTitle($formContents[0]);

        $form->setContent(sprintf($formContents[1], $translationManager->translatePotionColor($player, $this->getPotionColor($player), true)));

        $form->addButton($formContents[2], SimpleForm::IMAGE_TYPE_PATH, "textures/items/potion_bottle_splash_heal");
        $form->addButton($formContents[3], SimpleForm::IMAGE_TYPE_PATH, "textures/blocks/barrier");
        $form->addButton($formContents[4], SimpleForm::IMAGE_TYPE_PATH, "textures/ui/arrow_left");

        $player->sendForm($form);
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function sendPotionColorSelectionForm(PracticePlayer $player): void
    {
        if (!($player->hasPermission("practice.cosmetics.potioncolor"))) {
            $player->sendMessage($this->plugin->getTranslationManager()->translate($player, "potionColorNoPermission"));
            return;
        }

        $form = new SimpleForm(function (PracticePlayer $player, int $data = null): void {
            if ($data === null) {
                return;
            }

            $translationManager = $this->plugin->getTranslationManager();

            $color = "";
            switch ($data) {
                case 0:
                    $color = "Red";
                    break;
                case 1:
                    $color = "Dark_Red";
                    break;
                case 2:
                    $color = "Blue";
                    break;
                case 3:
                    $color = "Light_Blue";
                    break;
                case 4:
                    $color = "Green";
                    break;
                case 5:
                    $color = "Purple";
                    break;
                case 6:
                    $color = "Yellow";
                    break;
                case 7:
                    $color = "White";
                    break;
                case 8:
                    $color = "Black";
                    break;
                case 9:
                    $this->sendPotionColorForm($player);
                    return;
            }

            if ($color !== "") {
                if ($this->getPotionColor($player) === $color) {
                    $player->sendMessage($translationManager->translate($player, "potionColorAlreadySelected"));
                    return;
                }

                $this->setPotionColor($player, $color);
                $player->sendMessage(sprintf($translationManager->translate($player, "potionColorEnabled"), $translationManager->translatePotionColor($player, $color)));
            }
        });

        $formContents = $this->plugin->getTranslationManager()->translate($player, "potionColorSelectionForm");

        $form->setTitle($formContents[0]);

        for ($i = 1; $i <= 10; $i++) {
            $form->addButton($formContents[$i]);
        }

        $player->sendForm($form);
    }
}