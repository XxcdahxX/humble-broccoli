<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\player\cosmetics;

use antralia\core\form\SimpleForm;
use antralia\practice\player\PracticePlayer;
use antralia\practice\PracticePlugin;

final class CosmeticsManager
{

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function sendCosmeticsForm(PracticePlayer $player): void
    {
        if (!($player->hasPermission("practice.cosmetics.default"))) {
            $player->sendMessage($this->plugin->getTranslationManager()->translate($player, "cosmeticsNoPermission"));
            return;
        }

        $form = new SimpleForm(function (PracticePlayer $player, int $data = null): void {
            if ($data === null) {
                return;
            }

            switch ($data) {
                case 0:
                    $this->plugin->getCapesManager()->sendCapesForm($player);
                    break;
                case 1:
                    $this->plugin->getTagsManager()->sendTagsForm($player);
                    break;
                case 2:
                    $this->plugin->getFlyManager()->sendFlyForm($player);
                    break;
                case 3:
                    $this->plugin->getPotionColorManager()->sendPotionColorForm($player);
                    break;
                case 4:
                    $this->plugin->getHubManager()->sendPreferencesForm($player);
                    break;
            }
        });

        $formContents = $this->plugin->getTranslationManager()->translate($player, "cosmeticsForm");

        $form->setTitle($formContents[0]);

        $form->addButton($formContents[1]);
        $form->addButton($formContents[2]);
        $form->addButton($formContents[3]);
        $form->addButton($formContents[4]);
        $form->addButton($formContents[5]);

        $player->sendForm($form);
    }
}