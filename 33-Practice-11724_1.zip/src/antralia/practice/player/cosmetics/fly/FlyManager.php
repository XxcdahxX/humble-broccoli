<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\player\cosmetics\fly;

use antralia\core\form\SimpleForm;
use antralia\practice\player\PracticePlayer;
use antralia\practice\PracticePlugin;

final class FlyManager
{

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @var array<string, bool>
     */
    private array $fly = [];

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @param PracticePlayer $player
     * @return bool
     */
    public function hasFly(PracticePlayer $player): bool
    {
        $query = $this->plugin->getProvider()->getDatabase()->prepare("SELECT `fly` FROM `cosmetics` WHERE `xuid` = :xuid;");
        $query->bindValue(":xuid", $player->getXuid());
        $result = $query->execute()->fetchArray(SQLITE3_ASSOC);

        if (!($result) || $result["fly"] === "disabled") {
            return false;
        } else {
            return true;
        }
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function setFly(PracticePlayer $player): void
    {
        $query = $this->plugin->getProvider()->getDatabase()->prepare("UPDATE `cosmetics` SET `fly` = :status WHERE `xuid` = :xuid;");
        $query->bindValue(":status", "enabled");
        $query->bindValue(":xuid", $player->getXuid());
        $query->execute();

        $this->setFlyToArray($player);
        $player->setAllowFlight(true);
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function removeFly(PracticePlayer $player): void
    {
        if ($this->hasFly($player)) {
            $query = $this->plugin->getProvider()->getDatabase()->prepare("UPDATE `cosmetics` SET `fly` = :status WHERE `xuid` = :xuid;");
            $query->bindValue(":status", "disabled");
            $query->bindValue(":xuid", $player->getXuid());
            $query->execute();

            $this->removeFlyFromArray($player);
            $player->setFlying(false);
            $player->setAllowFlight(false);
        }
    }

    /**
     * @param PracticePlayer $player
     * @return bool
     */
    public function hasFlyFromArray(PracticePlayer $player): bool
    {
        return isset($this->fly[$player->getName()]);
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function setFlyToArray(PracticePlayer $player): void
    {
        $this->fly[$player->getName()] = true;
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function removeFlyFromArray(PracticePlayer $player): void
    {
        if (isset($this->fly[$player->getName()])) {
            unset($this->fly[$player->getName()]);
        }
    }

    /**
     * @param PracticePlayer $player
     * @return string
     */
    public function getFlyStatusForForm(PracticePlayer $player): string
    {
        return $this->hasFly($player) ? $this->plugin->getTranslationManager()->translate($player, "flyEnabledForForm") : $this->plugin->getTranslationManager()->translate($player, "flyDisabledForForm");
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function sendFlyForm(PracticePlayer $player): void
    {
        if (!($player->hasPermission("practice.cosmetics.fly"))) {
            $player->sendMessage($this->plugin->getTranslationManager()->translate($player, "flyNoPermission"));
            return;
        }

        $form = new SimpleForm(function (PracticePlayer $player, int $data = null): void {
            if ($data === null) {
                return;
            }

            $translationManager = $this->plugin->getTranslationManager();

            switch ($data) {
                case 0:
                    if ($this->hasFly($player)) {
                        $player->sendMessage($translationManager->translate($player, "flyAlreadyEnabled"));
                    } else {
                        $this->setFly($player);
                        $player->sendMessage($translationManager->translate($player, "flyEnabled"));
                    }
                    break;
                case 1:
                    if ($this->hasFly($player)) {
                        $this->removeFly($player);
                        $player->sendMessage($translationManager->translate($player, "flyDisabled"));
                    } else {
                        $player->sendMessage($translationManager->translate($player, "flyAlreadyDisabled"));
                    }
                    break;
                case 2:
                    $this->plugin->getCosmeticsManager()->sendCosmeticsForm($player);
                    break;
            }
        });

        $formContents = $this->plugin->getTranslationManager()->translate($player, "flyForm");

        $form->setTitle($formContents[0]);

        $form->setContent(sprintf($formContents[1], $this->getFlyStatusForForm($player)));

        $form->addButton($formContents[2], SimpleForm::IMAGE_TYPE_PATH, "textures/items/feather");
        $form->addButton($formContents[3], SimpleForm::IMAGE_TYPE_PATH, "textures/blocks/barrier");
        $form->addButton($formContents[4], SimpleForm::IMAGE_TYPE_PATH, "textures/ui/arrow_left");

        $player->sendForm($form);
    }
}