<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\player\cosmetics\capes;

use antralia\practice\player\PracticePlayer;
use antralia\practice\player\rank\PlayerRankChangeEvent;
use antralia\practice\PracticePlugin;
use pocketmine\entity\Skin;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChangeSkinEvent;
use pocketmine\event\player\PlayerJoinEvent;

use JsonException;

final class CapesListener implements Listener
{

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @param PlayerJoinEvent $event
     * @return void
     *
     * @throws JsonException
     */
    public function handlePlayerJoin(PlayerJoinEvent $event): void
    {
        $player = $event->getPlayer();

        if (!($player instanceof PracticePlayer)) {
            return;
        }

        $capesManager = $this->plugin->getCapesManager();
        if ($capesManager->hasCape($player)) {
            if (!($player->hasPermission("practice.cosmetics.capes"))) {
                $capesManager->removeCape($player);
            } else {
                $oldSkin = $player->getSkin();
                $newSkin = new Skin($oldSkin->getSkinId(), $oldSkin->getSkinData(), $capesManager->getCapeImage($capesManager->getCape($player)), $oldSkin->getGeometryName(), $oldSkin->getGeometryData());

                $player->setSkin($newSkin);
                $player->sendSkin();
            }
        }
    }

    /**
     * @param PlayerChangeSkinEvent $event
     * @return void
     *
     * @throws JsonException
     */
    public function handlePlayerChangeSkin(PlayerChangeSkinEvent $event): void
    {
        $player = $event->getPlayer();

        if (!($player instanceof PracticePlayer)) {
            return;
        }

        $capesManager = $this->plugin->getCapesManager();
        if ($capesManager->hasCape($player)) {
            $event->cancel();
            if (!($player->hasPermission("practice.cosmetics.capes"))) {
                $capesManager->removeCape($player);
            } else {
                $skin = $event->getNewSkin();
                $newSkin = new Skin($skin->getSkinId(), $skin->getSkinData(), $capesManager->getCapeImage($capesManager->getCape($player)), $skin->getGeometryName(), $skin->getGeometryData());

                $player->setSkin($newSkin);
                $player->sendSkin();
            }
        }
    }

    /**
     * @param PlayerRankChangeEvent $event
     * @return void
     *
     * @throws JsonException
     */
    public function handleRankChange(PlayerRankChangeEvent $event): void
    {
        $player = $event->getPlayer();
        $capesManager = $this->plugin->getCapesManager();

        if ($capesManager->hasCape($player)) {
            if (!($player->hasPermission("practice.cosmetics.capes"))) {
                $capesManager->removeCape($player);
            }
        }
    }
}