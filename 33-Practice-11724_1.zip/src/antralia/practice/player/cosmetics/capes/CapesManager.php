<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\player\cosmetics\capes;

use antralia\core\form\SimpleForm;
use antralia\practice\player\PracticePlayer;
use antralia\practice\PracticePlugin;
use pocketmine\entity\Skin;

use GdImage;
use JsonException;

final class CapesManager
{

    /**
     * @var string[]
     */
    public const CAPES = [
        "Antralia",
        "Lunarelly",
        "Birthday",
        "Cake",
        "Enderman",
        "Firework",
        "Iron_Golem",
        "Pickaxe",
        "Green_Creeper",
        "Red_Creeper",
        "Turtle",
        "Migrator"
    ];

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @var array<string, string>
     */
    private array $capes = [];

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;
        foreach (self::CAPES as $cape) {
            $plugin->saveResource("skins/capes/" . $cape . ".png");
            $this->capes[$cape] = $this->createCape($cape);
        }
    }

    /**
     * @param string $capeName
     * @return string
     */
    public function getCapeImage(string $capeName): string
    {
        return $this->capes[$capeName] ?? "";
    }

    /**
     * @param PracticePlayer $player
     * @return bool
     */
    public function hasCape(PracticePlayer $player): bool
    {
        $query = $this->plugin->getProvider()->getDatabase()->prepare("SELECT `cape` FROM `cosmetics` WHERE `xuid` = :xuid;");
        $query->bindValue(":xuid", $player->getXuid());
        $result = $query->execute()->fetchArray(SQLITE3_ASSOC);

        if (!($result) || $result["cape"] === "disabled") {
            return false;
        } else {
            return true;
        }
    }

    /**
     * @param PracticePlayer $player
     * @return string
     */
    public function getCape(PracticePlayer $player): string
    {
        $query = $this->plugin->getProvider()->getDatabase()->prepare("SELECT `cape` FROM `cosmetics` WHERE `xuid` = :xuid;");
        $query->bindValue(":xuid", $player->getXuid());
        $result = $query->execute()->fetchArray(SQLITE3_ASSOC);

        if (!($result) || $result["cape"] === "disabled") {
            return "-";
        } else {
            return $result["cape"];
        }
    }

    /**
     * @param PracticePlayer $player
     * @param string $cape
     * @return void
     *
     * @throws JsonException
     */
    public function setCape(PracticePlayer $player, string $cape): void
    {
        if (!(in_array($cape, self::CAPES, true))) {
            $this->plugin->getLogger()->alert("Undefined cape: " . $cape);
            return;
        }

        $query = $this->plugin->getProvider()->getDatabase()->prepare("UPDATE `cosmetics` SET `cape` = :cape WHERE `xuid` = :xuid;");
        $query->bindValue(":cape", $cape);
        $query->bindValue(":xuid", $player->getXuid());
        $query->execute();

        $oldSkin = $player->getSkin();
        $newSkin = new Skin($oldSkin->getSkinId(), $oldSkin->getSkinData(), $this->getCapeImage($cape), $oldSkin->getGeometryName(), $oldSkin->getGeometryData());

        $player->setSkin($newSkin);
        $player->sendSkin();
    }

    /**
     * @param PracticePlayer $player
     * @return void
     *
     * @throws JsonException
     */
    public function removeCape(PracticePlayer $player): void
    {
        $query = $this->plugin->getProvider()->getDatabase()->prepare("UPDATE `cosmetics` SET `cape` = :cape WHERE `xuid` = :xuid;");
        $query->bindValue(":cape", "disabled");
        $query->bindValue(":xuid", $player->getXuid());
        $query->execute();

        $oldSkin = $player->getSkin();
        $newSkin = new Skin($oldSkin->getSkinId(), $oldSkin->getSkinData(), "", $oldSkin->getGeometryName(), $oldSkin->getGeometryData());

        $player->setSkin($newSkin);
        $player->sendSkin();
    }

    /**
     * @param string $cape
     * @return string
     */
    public function createCape(string $cape): string
    {
        $path = $this->plugin->getDataFolder() . "skins/capes/" . $cape . ".png";

        $bytes = "";
        $image = @imagecreatefrompng($path);

        if (!($image instanceof GdImage)) {
            return "";
        }

        for ($y = 0; $y < imagesy($image); $y++) {
            for ($x = 0; $x < imagesx($image); $x++) {
                $rgba = @imagecolorat($image, $x, $y);

                $a = ((~(($rgba >> 24))) << 1) & 0xff;
                $r = ($rgba >> 16) & 0xff;
                $g = ($rgba >> 8) & 0xff;
                $b = $rgba & 0xff;

                $bytes .= chr($r) . chr($g) . chr($b) . chr($a);
            }
        }
        @imagedestroy($image);

        if (strlen($bytes) !== 8192) {
            return "";
        }

        return $bytes;
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function sendCapesForm(PracticePlayer $player): void
    {
        if (!($player->hasPermission("practice.cosmetics.capes"))) {
            $player->sendMessage($this->plugin->getTranslationManager()->translate($player, "capesNoPermission"));
            return;
        }

        $form = new SimpleForm(function (PracticePlayer $player, int $data = null): void {
            if ($data === null) {
                return;
            }

            $translationManager = $this->plugin->getTranslationManager();

            switch ($data) {
                case 0:
                    $this->sendCapesSelectionForm($player);
                    break;
                case 1:
                    if ($this->hasCape($player)) {
                        $this->removeCape($player);
                        $player->sendMessage($translationManager->translate($player, "capeDisabled"));
                    } else {
                        $player->sendMessage($translationManager->translate($player, "capeDoesNotSet"));
                    }
                    break;
                case 2:
                    $this->plugin->getCosmeticsManager()->sendCosmeticsForm($player);
                    break;
            }
        });

        $translationManager = $this->plugin->getTranslationManager();
        $formContents = $translationManager->translate($player, "capesForm");

        $form->setTitle($formContents[0]);

        $form->setContent(sprintf($formContents[1], $translationManager->translateCape($player, $this->getCape($player), true)));

        $form->addButton($formContents[2], SimpleForm::IMAGE_TYPE_PATH, "textures/items/banner_pattern");
        $form->addButton($formContents[3], SimpleForm::IMAGE_TYPE_PATH, "textures/blocks/barrier");
        $form->addButton($formContents[4], SimpleForm::IMAGE_TYPE_PATH, "textures/ui/arrow_left");

        $player->sendForm($form);
    }

    /**
     * @param PracticePlayer $player
     * @return void
     */
    public function sendCapesSelectionForm(PracticePlayer $player): void
    {
        if (!($player->hasPermission("practice.cosmetics.capes"))) {
            $player->sendMessage($this->plugin->getTranslationManager()->translate($player, "capesNoPermission"));
            return;
        }

        $form = new SimpleForm(function (PracticePlayer $player, int $data = null): void {
            if ($data === null) {
                return;
            }

            $translationManager = $this->plugin->getTranslationManager();

            $cape = "";
            switch ($data) {
                case 0:
                    $cape = "Antralia";
                    break;
                case 1:
                    $cape = "Lunarelly";
                    break;
                case 2:
                    $cape = "Birthday";
                    break;
                case 3:
                    $cape = "Cake";
                    break;
                case 4:
                    $cape = "Enderman";
                    break;
                case 5:
                    $cape = "Firework";
                    break;
                case 6:
                    $cape = "Iron_Golem";
                    break;
                case 7:
                    $cape = "Pickaxe";
                    break;
                case 8:
                    $cape = "Green_Creeper";
                    break;
                case 9:
                    $cape = "Red_Creeper";
                    break;
                case 10:
                    $cape = "Turtle";
                    break;
                case 11:
                    $cape = "Migrator";
                    break;
                case 12:
                    $this->sendCapesForm($player);
                    return;
            }

            if ($cape !== "") {
                if ($this->getCape($player) === $cape) {
                    $player->sendMessage($translationManager->translate($player, "capeAlreadySelected"));
                    return;
                }

                $this->setCape($player, $cape);
                $player->sendMessage(sprintf($translationManager->translate($player, "capeEnabled"), $translationManager->translateCape($player, $cape)));
            }
        });

        $formContents = $this->plugin->getTranslationManager()->translate($player, "capesSelectionForm");

        $form->setTitle($formContents[0]);

        for ($i = 1; $i <= 13; $i++) {
            $form->addButton($formContents[$i]);
        }

        $player->sendForm($form);
    }
}