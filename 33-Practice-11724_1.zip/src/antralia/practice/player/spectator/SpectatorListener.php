<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\player\spectator;

use antralia\practice\player\PracticePlayer;
use antralia\practice\PracticePlugin;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\inventory\InventoryTransactionEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerItemUseEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\item\VanillaItems;

final class SpectatorListener implements Listener
{

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @handleCancelled
     *
     * @param PlayerItemUseEvent $event
     * @return void
     */
    public function handlePlayerItemUse(PlayerItemUseEvent $event): void
    {
        $player = $event->getPlayer();

        if (!($player instanceof PracticePlayer)) {
            return;
        }

        $spectatorManager = $this->plugin->getSpectatorManager();

        if ($spectatorManager->isSpectator($player)) {
            $item = $event->getItem();
            $translationManager = $this->plugin->getTranslationManager();
            $spectatorItems = $translationManager->translate($player, "spectatorItems");
            $suspect = $spectatorManager->getSuspect($player);

            if ($item->getCustomName() === $spectatorItems[0]) {
                $event->cancel();
                $player->teleport($suspect->getPosition());
                $player->sendMessage($translationManager->translate($player, "spectatorSuccessfulTeleport"));
            } elseif ($item->getCustomName() === $spectatorItems[1]) {
                $event->cancel();
                $suspect->setImmobile();
                $player->getInventory()->removeItem(VanillaItems::SNOWBALL());
                $player->getInventory()->setItem(4, VanillaItems::ENDER_PEARL()->setCustomName($spectatorItems[2]));
                $player->sendMessage($translationManager->translate($player, "spectatorSuccessfulFreeze"));
                $suspect->sendMessage($translationManager->translate($suspect, "frozenBySpectator"));
            } elseif ($item->getCustomName() === $spectatorItems[2]) {
                $event->cancel();
                $suspect->setImmobile(false);
                $player->getInventory()->removeItem(VanillaItems::ENDER_PEARL());
                $player->getInventory()->setItem(4, VanillaItems::SNOWBALL()->setCustomName($spectatorItems[1]));
                $player->sendMessage($translationManager->translate($player, "spectatorSuccessfulUnfreeze"));
            } elseif ($item->getCustomName() === $spectatorItems[3]) {
                $event->cancel();
                if ($suspect->isImmobile()) {
                    $suspect->setImmobile(false);
                }
                $spectatorManager->removeSpectator($player);
                $player->sendMessage($translationManager->translate($player, "spectatorSuccessfulQuit"));
            }
        }
    }

    /**
     * @param EntityDamageEvent $event
     * @return void
     */
    public function handleEntityDamage(EntityDamageEvent $event): void
    {
        $entity = $event->getEntity();

        if (!($entity instanceof PracticePlayer)) {
            return;
        }

        $spectatorManager = $this->plugin->getSpectatorManager();

        if ($spectatorManager->isSpectator($entity)) {
            $event->cancel();
            return;
        }

        if ($event instanceof EntityDamageByEntityEvent) {
            $damager = $event->getDamager();
            if ($damager instanceof PracticePlayer) {
                if ($spectatorManager->isSpectator($damager)) {
                    $event->cancel();
                }
            }
        }
    }

    /**
     * @param PlayerQuitEvent $event
     * @return void
     */
    public function handlePlayerQuit(PlayerQuitEvent $event): void
    {
        $player = $event->getPlayer();

        if (!($player instanceof PracticePlayer)) {
            return;
        }

        $spectatorManager = $this->plugin->getSpectatorManager();

        if ($spectatorManager->isSpectator($player)) {
            $suspect = $spectatorManager->getSuspect($player);
            if ($suspect?->isImmobile()) {
                $suspect?->setImmobile(false);
            }
            $spectatorManager->removeSpectator($player);
        }

        foreach ($spectatorManager->getSpectators() as $spectatorName => $_) {
            $spectator = $this->plugin->getServer()->getPlayerExact($spectatorName);

            if (!($spectator instanceof PracticePlayer)) {
                return;
            }

            if ($spectatorManager->getSuspect($spectator) === $player) {
                $spectatorManager->removeSpectator($spectator);
                $spectator->sendMessage($this->plugin->getTranslationManager()->translate($spectator, "spectatorSuspectHadQuit"));
            }
        }
    }

    /**
     * @param InventoryTransactionEvent $event
     * @return void
     */
    public function handleInventoryTransaction(InventoryTransactionEvent $event): void
    {
        $source = $event->getTransaction()->getSource();

        if (!($source instanceof PracticePlayer)) {
            return;
        }

        if ($this->plugin->getSpectatorManager()->isSpectator($source)) {
            $event->cancel();
        }
    }
}