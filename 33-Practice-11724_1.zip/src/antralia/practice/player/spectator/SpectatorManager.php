<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\player\spectator;

use antralia\core\scoreboard\Scoreboard;
use antralia\practice\player\PracticePlayer;
use antralia\practice\PracticePlugin;
use antralia\practice\utils\PracticeUtils;
use pocketmine\item\VanillaItems;
use pocketmine\player\GameMode;

final class SpectatorManager
{

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @var array<string, string>
     */
    private array $spectators = [];

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @return array
     */
    public function getSpectators(): array
    {
        return $this->spectators;
    }

    /**
     * @param PracticePlayer $player
     * @return bool
     */
    public function isSpectator(PracticePlayer $player): bool
    {
        return isset($this->spectators[$player->getName()]);
    }

    /**
     * @param PracticePlayer $spectator
     * @return PracticePlayer|null
     */
    public function getSuspect(PracticePlayer $spectator): ?PracticePlayer
    {
        $player = $this->plugin->getServer()->getPlayerExact($this->spectators[$spectator->getName()]);

        if (!($player instanceof PracticePlayer)) {
            return null;
        }

        return $player;
    }

    /**
     * @param PracticePlayer $spectator
     * @return void
     */
    public function setSpectatorSettings(PracticePlayer $spectator): void
    {
        $hubManager = $this->plugin->getHubManager();
        if ($hubManager->isInHub($spectator)) {
            $hubManager->removeFromHub($spectator);
        }

        if (Scoreboard::hasScore($spectator)) {
            Scoreboard::removeScore($spectator);
        }

        $spectator->setGamemode(GameMode::SPECTATOR());

        $spectator->setMaxHealth(20);
        $spectator->setHealth(20);
        $spectator->getHungerManager()->setFood(20);
        $spectator->getXpManager()->setXpAndProgress(0, 0);

        $spectator->extinguish();
        $spectator->getEffects()->clear();
        $spectator->getCursorInventory()->clearAll();
        $spectator->getArmorInventory()->clearAll();

        $inventory = $spectator->getInventory();
        $spectatorItemNames = $this->plugin->getTranslationManager()->translate($spectator, "spectatorItems");

        $inventory->clearAll();
        $inventory->setItem(0, VanillaItems::SLIMEBALL()->setCustomName($spectatorItemNames[0])->setLore([PracticeUtils::ITEM_LORE]));
        $inventory->setItem(4, VanillaItems::SNOWBALL()->setCustomName($spectatorItemNames[1])->setLore([PracticeUtils::ITEM_LORE]));
        $inventory->setItem(8, VanillaItems::RED_BED()->setCustomName($spectatorItemNames[3])->setLore([PracticeUtils::ITEM_LORE]));
    }

    /**
     * @param PracticePlayer $spectator
     * @return void
     */
    public function setDefaultSettings(PracticePlayer $spectator): void
    {
        $hubManager = $this->plugin->getHubManager();

        $hubManager->setPlayerSettings($spectator);
        $hubManager->sendMenuItems($spectator);
        $hubManager->updateScoreboard($spectator);
        $hubManager->updateScoreTag($spectator);
    }

    /**
     * @param PracticePlayer $spectator
     * @param PracticePlayer $suspect
     * @return void
     */
    public function addSpectator(PracticePlayer $spectator, PracticePlayer $suspect): void
    {
        if (!($spectator->isConnected() || $suspect->isConnected())) {
            return;
        }

        $this->spectators[$spectator->getName()] = $suspect->getName();
        $this->setSpectatorSettings($spectator);
        $spectator->teleport($suspect->getPosition());
    }

    /**
     * @param PracticePlayer $spectator
     * @return void
     */
    public function removeSpectator(PracticePlayer $spectator): void
    {
        if (isset($this->spectators[$spectator->getName()])) {
            unset($this->spectators[$spectator->getName()]);
            $this->setDefaultSettings($spectator);
        }
    }

    /**
     * @param string $spectatorName
     * @return void
     */
    public function removeSpectatorByName(string $spectatorName): void
    {
        if (isset($this->spectators[$spectatorName])) {
            unset($this->spectators[$spectatorName]);
        }
    }
}