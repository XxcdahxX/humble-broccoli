<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\player\spectator;

use antralia\practice\player\PracticePlayer;
use antralia\practice\PracticePlugin;
use pocketmine\scheduler\Task;

final class SpectatorTask extends Task
{

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @return void
     */
    public function onRun(): void
    {
        $spectatorManager = $this->plugin->getSpectatorManager();

        foreach ($spectatorManager->getSpectators() as $spectatorName => $_) {
            $spectator = $this->plugin->getServer()->getPlayerExact($spectatorName);

            if (!($spectator instanceof PracticePlayer)) {
                $spectatorManager->removeSpectatorByName($spectatorName);
                continue;
            }

            if (!($spectator->isConnected())) {
                $spectatorManager->removeSpectator($spectator);
                continue;
            }

            $suspect = $spectatorManager->getSuspect($spectator);
            $translationManager = $this->plugin->getTranslationManager();
            $spectator->sendActionBarMessage(sprintf(
                $translationManager->translate($spectator, "spectatorActionBar"),
                $suspect->getName(),
                $suspect->getNetworkSession()->getPing(),
                $suspect->getDeviceOSNameForMessages(),
                $translationManager->translateInputMode($spectator, $suspect->getCurrentInputModeName())
            ));
        }
    }
}