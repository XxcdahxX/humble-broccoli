<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\player\skin;

use antralia\practice\PracticePlugin;
use pocketmine\entity\InvalidSkinException;
use pocketmine\entity\Skin;
use pocketmine\network\mcpe\convert\LegacySkinAdapter;
use pocketmine\network\mcpe\protocol\types\skin\SkinData;

use InvalidArgumentException;
use JsonException;

final class SkinAdapterPersona extends LegacySkinAdapter
{

    /**
     * @var array
     */
    private array $bounds = [];

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $plugin->saveResource("skins/default_geometry.json");
        $cubes = $this->getCubes(json_decode(file_get_contents($plugin->getDataFolder() . "skins/default_geometry.json"), true)["geometry.humanoid"]);

        $this->bounds[0] = $this->getBounds($cubes);
        $this->bounds[1] = $this->getBounds($cubes, 2.0);
    }

    /**
     * @param SkinData $data
     * @return Skin
     *
     * @throws JsonException
     */
    public function fromSkinData(SkinData $data): Skin
    {
        if ($data->isPersona() || $data->isPremium()) {
            return SkinManager::getInstance()->getSkin();
        } else {
            $resourcePatch = json_decode($data->getResourcePatch(), true);

            if (is_array($resourcePatch) && isset($resourcePatch["geometry"]["default"]) && is_string($resourcePatch["geometry"]["default"])) {
                $geometryName = $resourcePatch["geometry"]["default"];
            } else {
                throw new InvalidSkinException("Missing geometry name field");
            }

            $skin = new Skin($data->getSkinId(), $data->getSkinImage()->getData(), "", $geometryName, $data->getGeometryData());
        }

        if ($this->getSkinTransparencyPercentage($skin->getSkinData()) > 4) {
            return SkinManager::getInstance()->getSkin();
        }

        return $skin;
    }

    /**
     * @param string $skinData
     * @return int
     */
    private function getSkinTransparencyPercentage(string $skinData): int
    {
        switch (strlen($skinData)) {
            case 8192:
                $maxX = 64;
                $maxY = 32;
                $bounds = $this->bounds[0];
                break;
            case 16384:
                $maxX = 64;
                $maxY = 64;
                $bounds = $this->bounds[0];
                break;
            case 65536:
                $maxX = 128;
                $maxY = 128;
                $bounds = $this->bounds[1];
                break;
            default:
                throw new InvalidArgumentException("Invalid skin data length: " . strlen($skinData));
        }

        $transparentPixels = 0;
        $pixels = 0;
        foreach ($bounds as $bound) {
            if ($bound["max"]["x"] > $maxX || $bound["max"]["y"] > $maxY) {
                continue;
            }

            for ($y = $bound["min"]["y"]; $y <= $bound["max"]["y"]; $y++) {
                for ($x = $bound["min"]["x"]; $x <= $bound["max"]["x"]; $x++) {
                    $key = (($maxX * $y) + $x) * 4;
                    $a = ord($skinData[$key + 3]);
                    if ($a < 127) {
                        ++$transparentPixels;
                    }
                    ++$pixels;
                }
            }
        }
        return (int)round(($transparentPixels * 100) / max(1, $pixels));
    }

    /**
     * @param array $geometryData
     * @return array
     */
    private function getCubes(array $geometryData): array
    {
        $cubes = [];
        foreach ($geometryData["bones"] as $bone) {
            if (!(isset($bone["cubes"]))) {
                continue;
            }

            if ($bone["mirror"] ?? false) {
                throw new InvalidArgumentException("Unsupported geometry data");
            }

            foreach ($bone["cubes"] as $cubeData) {
                $cube = [];
                $cube["x"] = $cubeData["size"][0];
                $cube["y"] = $cubeData["size"][1];
                $cube["z"] = $cubeData["size"][2];
                $cube["uvX"] = $cubeData["uv"][0];
                $cube["uvY"] = $cubeData["uv"][1];
                $cubes[] = $cube;
            }
        }
        return $cubes;
    }

    /**
     * @param array $cubes
     * @param float $scale
     * @return array
     */
    private function getBounds(array $cubes, float $scale = 1.0): array
    {
        $bounds = [];
        foreach ($cubes as $cube) {
            $x = (int)($scale * $cube["x"]);
            $y = (int)($scale * $cube["y"]);
            $z = (int)($scale * $cube["z"]);
            $uvX = (int)($scale * $cube["uvX"]);
            $uvY = (int)($scale * $cube["uvY"]);
            $bounds[] = ["min" => ["x" => $uvX + $z, "y" => $uvY], "max" => ["x" => $uvX + $z + (2 * $x) - 1, "y" => $uvY + $z - 1]];
            $bounds[] = ["min" => ["x" => $uvX, "y" => $uvY + $z], "max" => ["x" => $uvX + (2 * ($z + $x)) - 1, "y" => $uvY + $z + $y - 1]];
        }
        return $bounds;
    }
}