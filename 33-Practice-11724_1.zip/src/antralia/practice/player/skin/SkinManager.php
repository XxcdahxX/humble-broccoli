<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\player\skin;

use antralia\practice\exception\PracticeException;
use antralia\practice\PracticePlugin;
use pocketmine\entity\Skin;
use pocketmine\network\mcpe\convert\SkinAdapterSingleton;

use GdImage;
use JsonException;

final class SkinManager
{

    /**
     * @var self
     */
    private static self $instance;

    /**
     * @var Skin
     */
    private Skin $skin;

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        self::$instance = $this;
        $plugin->saveResource("skins/Steve.png");

        try {
            $image = imagecreatefrompng($plugin->getDataFolder() . "skins/Steve.png");

            if ($image === false) {
                throw new PracticeException("Image cannot be created");
            }

            $this->skin = new Skin("Standard_Antralia", $this->fromImage($image), "", "geometry.humanoid.custom");
            @imagedestroy($image);
        } catch (JsonException $e) {
            throw new PracticeException($e->getMessage());
        }

        SkinAdapterSingleton::set(new SkinAdapterPersona($plugin));
    }

    /**
     * @return self
     */
    public static function getInstance(): self
    {
        return self::$instance;
    }

    /**
     * @param GdImage $image
     * @return string
     */
    public static function fromImage(GdImage $image): string
    {
        $bytes = "";

        for ($y = 0; $y < imagesy($image); $y++) {
            for ($x = 0; $x < imagesx($image); $x++) {
                $rgba = @imagecolorat($image, $x, $y);

                $r = ($rgba >> 16) & 0xff;
                $g = ($rgba >> 8) & 0xff;
                $b = $rgba & 0xff;
                $a = ((~(($rgba >> 24))) << 1) & 0xff;

                $bytes .= chr($r) . chr($g) . chr($b) . chr($a);
            }
        }
        @imagedestroy($image);

        return $bytes;
    }

    /**
     * @return Skin
     */
    public function getSkin(): Skin
    {
        return $this->skin;
    }
}