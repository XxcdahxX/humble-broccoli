<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\player\report;

use antralia\practice\command\CommandArgs;
use antralia\practice\command\PracticeCommand;
use antralia\practice\player\PracticePlayer;
use antralia\practice\player\rank\RankManager;
use antralia\practice\PracticePlugin;
use antralia\practice\utils\PracticeUtils;
use pocketmine\command\CommandSender;
use pocketmine\network\mcpe\protocol\AvailableCommandsPacket;
use pocketmine\utils\TextFormat;

final class ReportCommand extends PracticeCommand
{

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;

        $this->setPermission("practice.command.report");
        $this->commandArg = new CommandArgs();
        $this->commandArg->addParameter(0, "player", AvailableCommandsPacket::ARG_TYPE_TARGET);
        $this->commandArg->addParameter(0, "reason");

        parent::__construct("report", "Report a player", "Usage: /report <player> <reason>");
    }

    /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     * @return bool
     */
    public function execute(CommandSender $sender, string $commandLabel, array $args): bool
    {
        if (!($this->testPermission($sender))) {
            return false;
        }

        if (!($sender instanceof PracticePlayer)) {
            $sender->sendMessage(TextFormat::RED . "Only for players!");
            return true;
        }

        $translationManager = $this->plugin->getTranslationManager();

        if (!(isset($args[0])) || !(isset($args[1]))) {
            $sender->sendMessage($translationManager->translate($sender, "reportUsage"));
        } else {
            $nickname = array_shift($args);
            $reason = implode(" ", $args);
            $player = PracticeUtils::getPlayerByPrefix($nickname);

            if ($player) {
                if (!($player instanceof PracticePlayer)) {
                    return true;
                }

                if ($player->getName() === $sender->getName()) {
                    $sender->sendMessage($translationManager->translate($sender, "reportSelf"));
                    return true;
                }

                if ($player->getRank() === RankManager::OWNER_RANK) {
                    $sender->sendMessage($translationManager->translate($sender, "playerCannotBeReported"));
                    return true;
                }

                $this->plugin->getReportManager()->sendReport($sender->getName(), $player->getName(), $reason);
                $sender->sendMessage(sprintf($translationManager->translate($sender, "successfulReport"), $player->getName(), $reason));
            } else {
                $sender->sendMessage($translationManager->translate($sender, "playerNotFound"));
            }
        }
        return true;
    }

    /**
     * @param PracticePlayer $player
     * @return string
     */
    public function getDescriptionForPlayer(PracticePlayer $player): string
    {
        return $this->plugin->getTranslationManager()->translate($player, "reportCommandDescription");
    }
}