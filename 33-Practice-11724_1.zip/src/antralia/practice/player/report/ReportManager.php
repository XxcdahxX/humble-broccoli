<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\player\report;

use antralia\core\telegram\Telegram;
use antralia\core\vk\VK;
use antralia\practice\player\PracticePlayer;
use antralia\practice\PracticePlugin;
use pocketmine\utils\TextFormat;

final class ReportManager
{

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @param string $senderName
     * @param string $reportedName
     * @param string $reason
     * @return void
     */
    public function sendReport(string $senderName, string $reportedName, string $reason): void
    {
        $this->plugin->getLogger()->info(sprintf(
            TextFormat::YELLOW . "%s was reported by %s with reason: %s",
            $reportedName,
            $senderName,
            $reason
        ));

        foreach ($this->plugin->getServer()->getOnlinePlayers() as $player) {
            if ($player->hasPermission("practice.channel.administrative")) {
                if (!($player->isConnected())) {
                    return;
                }

                if (!($player instanceof PracticePlayer)) {
                    return;
                }

                $player->sendMessage(sprintf(
                    $this->plugin->getTranslationManager()->translate($player, "playerReportNotification"),
                    $reportedName,
                    $senderName,
                    $reason
                ));
            }
        }

        Telegram::sendMessage(sprintf(
            "[%s] New report!\nSuspect: %s\nBy: %s\nReason: %s",
            date("d.m.y"),
            $reportedName,
            $senderName,
            $reason
        ));
        VK::sendMessage(sprintf(
            "[%s] Новая жалоба!\nПодозреваемый: %s\nЖалуется: %s\nПричина: %s",
            date("d.m.y"),
            $reportedName,
            $senderName,
            $reason
        ));
    }
}