<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\player\resourcepack;

use antralia\practice\PracticePlugin;
use pocketmine\event\Listener;
use pocketmine\event\server\DataPacketSendEvent;
use pocketmine\network\mcpe\protocol\ResourcePacksInfoPacket;
use pocketmine\network\mcpe\protocol\ResourcePackStackPacket;
use pocketmine\network\mcpe\protocol\types\resourcepacks\ResourcePackInfoEntry;

final class ResourcePackListener implements Listener
{

    /**
     * @var PracticePlugin
     */
    private PracticePlugin $plugin;

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @param DataPacketSendEvent $event
     * @return void
     */
    public function handleDataPacketSend(DataPacketSendEvent $event): void
    {
        foreach ($event->getPackets() as $packet) {
            if ($packet instanceof ResourcePackStackPacket) {
                $resourcePackStack = $packet->resourcePackStack;
                foreach ($resourcePackStack as $index => $resourcePack) {
                    if ($resourcePack->getPackId() === ResourcePackManager::CHEMISTRY_PACK_ID) {
                        unset($resourcePackStack[$index]);
                    }
                }
                $packet->resourcePackStack = $resourcePackStack;
            }

            if ($packet instanceof ResourcePacksInfoPacket) {
                foreach ($packet->resourcePackEntries as $index => $entry) {
                    $resourcePackManager = $this->plugin->getResourcePackManager();
                    if ($entry->getPackId() === $resourcePackManager->getResourcePack()->getPackId()) {
                        $packet->resourcePackEntries[$index] = new ResourcePackInfoEntry(
                            $entry->getPackId(),
                            $entry->getVersion(),
                            $entry->getSizeBytes(),
                            $resourcePackManager->getEncryptionKey(),
                            $entry->getSubPackName(),
                            $entry->getPackId(),
                            $entry->hasScripts(),
                            $entry->isRtxCapable()
                        );
                    }
                }
            }
        }
    }
}