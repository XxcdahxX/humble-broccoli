<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\player\resourcepack;

use antralia\practice\PracticePlugin;
use pocketmine\resourcepacks\ResourcePack;

final class ResourcePackManager
{

    /**
     * @var string
     */
    public const CHEMISTRY_PACK_ID = "0fba4063-dba1-4281-9b89-ff9390653530";

    /**
     * @var ResourcePack
     */
    private ResourcePack $resourcePack;

    /**
     * @var string
     */
    private string $encryptionKey = "encryptmypack.com-SL0C4NJTE082R3";

    /**
     * @param PracticePlugin $plugin
     */
    public function __construct(PracticePlugin $plugin)
    {
        foreach ($plugin->getServer()->getResourcePackManager()->getResourceStack() as $resourcePack) {
            $this->resourcePack = $resourcePack;
            break;
        }
    }

    /**
     * @return ResourcePack
     */
    public function getResourcePack(): ResourcePack
    {
        return $this->resourcePack;
    }

    /**
     * @return string
     */
    public function getEncryptionKey(): string
    {
        return $this->encryptionKey;
    }
}