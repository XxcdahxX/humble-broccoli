<?php

declare(strict_types=1);

/**
 *     _          _             _ _
 *    / \   _ __ | |_ _ __ __ _| (_) __ _
 *   / _ \ | '_ \| __| '__/ _` | | |/ _` |
 *  / ___ \| | | | |_| | | (_| | | | (_| |
 * /_/   \_\_| |_|\__|_|  \__,_|_|_|\__,_|
 *
 * @author Antralia (Lunarelly)
 * @link https://github.com/Antralia
 *
 */

namespace antralia\practice\player;

use antralia\practice\entity\FakeDeadHuman;
use antralia\practice\entity\PracticeLightningBoltEntity;
use antralia\practice\player\knockback\KnockBack;
use antralia\practice\player\rank\RankManager;
use antralia\practice\PracticePlugin;
use pocketmine\entity\Location;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\form\Form;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\network\mcpe\NetworkSession;
use pocketmine\network\mcpe\protocol\RemoveActorPacket;
use pocketmine\network\mcpe\protocol\types\DeviceOS;
use pocketmine\network\mcpe\protocol\types\InputMode;
use pocketmine\player\Player;
use pocketmine\player\PlayerInfo;
use pocketmine\player\XboxLivePlayerInfo;
use pocketmine\Server;
use pocketmine\utils\Limits;
use pocketmine\world\Position;

final class PracticePlayer extends Player
{

    /**
     * @var int
     */
    public const CRASH_FAST_MODE = 0;

    /**
     * @var int
     */
    public const CRASH_SLOW_MODE = 1;

    /**
     * @var XboxLivePlayerInfo
     */
    protected PlayerInfo $playerInfo;

    /**
     * @var KnockBack
     */
    protected KnockBack $knockBack;

    /**
     * @var string
     */
    private string $lowerCaseName;

    /**
     * @var int
     */
    private int $deviceOS;

    /**
     * @var string
     */
    private string $deviceModel;

    /**
     * @var int
     */
    public int $currentInputMode;

    /**
     * @var string
     */
    private string $gameVersion;

    /**
     * @var bool
     */
    private bool $lookingAtForm = false;

    /**
     * @param Server $server
     * @param NetworkSession $session
     * @param PlayerInfo $playerInfo
     * @param bool $authenticated
     * @param Location $spawnLocation
     * @param CompoundTag|null $namedtag
     */
    public function __construct(Server $server, NetworkSession $session, PlayerInfo $playerInfo, bool $authenticated, Location $spawnLocation, ?CompoundTag $namedtag)
    {
        parent::__construct($server, $session, $playerInfo, $authenticated, $spawnLocation, $namedtag);

        $this->knockBack = new KnockBack($this);

        if (!($authenticated)) {
            $this->kick("You are not authenticated in Xbox Live services.");
        }

        $this->lowerCaseName = strtolower($this->getName());
        $this->deviceOS = $playerInfo->getExtraData()["DeviceOS"];
        $this->deviceModel = $playerInfo->getExtraData()["DeviceModel"];
        $this->currentInputMode = $playerInfo->getExtraData()["CurrentInputMode"];
        $this->gameVersion = $playerInfo->getExtraData()["GameVersion"];
    }

    /**
     * @return KnockBack
     */
    public function getKnockBack(): KnockBack
    {
        return $this->knockBack;
    }

    /**
     * @param float $x
     * @param float $z
     * @param float $force
     * @param float|null $verticalLimit
     * @return void
     */
    public function knockBack(float $x, float $z, float $force = 0.4, ?float $verticalLimit = 0.4): void
    {
        $knockBackData = $this->getKnockBack()->getData();
        $xKB = $knockBackData["x"];
        $yKB = $knockBackData["y"];

        $f = sqrt($x * $x + $z * $z);

        if ($f <= 0) {
            return;
        }

        if (mt_rand() / mt_getrandmax() > $this->knockbackResistanceAttr->getValue()) {
            $f = 1 / $f;

            $motionX = $this->motion->x / 2;
            $motionY = $this->motion->y / 2;
            $motionZ = $this->motion->z / 2;

            $motionX += $x * $f * $xKB;
            $motionY += $yKB;
            $motionZ += $z * $f * $xKB;

            if ($motionY > $yKB) {
                $motionY = $yKB;
            }

            if ($knockBackData["verticalLimit"] === true) {
                $motionY = 0;
            }

            $this->setMotion(new Vector3($motionX, $motionY, $motionZ));
        }
    }

    /**
     * @param EntityDamageEvent $source
     * @return void
     */
    public function attack(EntityDamageEvent $source): void
    {
        if ($this->attackTime > 0) {
            $source->cancel();
            return;
        }

        parent::attack($source);

        if ($source->isCancelled()) {
            return;
        }

        $this->attackTime = $this->getKnockBack()->getAttackSpeed();
    }

    /**
     * @param int $formId
     * @param mixed $responseData
     * @return bool
     */
    public function onFormSubmit(int $formId, $responseData): bool
    {
        $this->lookingAtForm = false;
        return parent::onFormSubmit($formId, $responseData);
    }

    /**
     * @param Form $form
     * @return void
     */
    public function sendForm(Form $form): void
    {
        if (!($this->lookingAtForm)) {
            $this->lookingAtForm = true;
            parent::sendForm($form);
        }
    }

    /**
     * @param string $title
     * @param string $subtitle
     * @param int $fadeIn
     * @param int $stay
     * @param int $fadeOut
     * @return void
     */
    public function sendTitle(string $title, string $subtitle = "", int $fadeIn = 10, int $stay = 18, int $fadeOut = 10): void
    {
        parent::sendTitle($title, $subtitle, $fadeIn, $stay, $fadeOut);
    }

    /**
     * @param int $mode
     * @return void
     */
    public function crashClient(int $mode = self::CRASH_FAST_MODE): void
    {
        if ($mode === self::CRASH_FAST_MODE) {
            $this->getNetworkSession()->sendDataPacket(RemoveActorPacket::create($this->getId()));
        } elseif ($mode === self::CRASH_SLOW_MODE) {
            $this->teleport(new Position($this->getPosition()->getX(), Limits::INT32_MAX - 1, $this->getPosition()->getY(), $this->getWorld()));
        } else {
            $this->getServer()->getLogger()->alert(sprintf("Unknown crash mode: %s", $mode));
        }
    }

    /**
     * @return string
     */
    public function getLowerCaseName(): string
    {
        return $this->lowerCaseName;
    }

    /**
     * @return int
     */
    public function getDeviceOS(): int
    {
        return $this->deviceOS;
    }

    /**
     * @return string
     */
    public function getDeviceModel(): string
    {
        return $this->deviceModel;
    }

    /**
     * @return int
     */
    public function getCurrentInputMode(): int
    {
        return $this->currentInputMode;
    }

    /**
     * @return string
     */
    public function getGameVersion(): string
    {
        return $this->gameVersion;
    }

    /**
     * @return string
     */
    public function getDeviceOSName(): string
    {
        $deviceOS = $this->getDeviceOS();

        if ($deviceOS === DeviceOS::ANDROID && $this->getDeviceModel() === "") {
            return "Linux";
        } else {
            return match ($deviceOS) {
                DeviceOS::ANDROID => "Android",
                DeviceOS::IOS => "iOS",
                DeviceOS::OSX => "macOS",
                DeviceOS::AMAZON => "Fire OS",
                DeviceOS::GEAR_VR => "Gear VR",
                DeviceOS::HOLOLENS => "Hololens",
                DeviceOS::WINDOWS_10 => "Windows",
                DeviceOS::WIN32 => "Windows 32",
                DeviceOS::DEDICATED => "Dedicated",
                DeviceOS::TVOS => "tvOS",
                DeviceOS::PLAYSTATION => "PlayStation",
                DeviceOS::NINTENDO => "Nintendo Switch",
                DeviceOS::XBOX => "Xbox",
                DeviceOS::WINDOWS_PHONE => "Windows Phone",
                default => "Unknown"
            };
        }
    }

    /**
     * @return string
     */
    public function getDeviceOSNameForMessages(): string
    {
        $deviceOS = $this->getDeviceOS();

        if ($deviceOS === DeviceOS::ANDROID && $this->getDeviceModel() === "") {
            return "Linux";
        } else {
            return match ($deviceOS) {
                DeviceOS::ANDROID => "Android",
                DeviceOS::IOS => "iOS",
                DeviceOS::OSX => "macOS",
                DeviceOS::AMAZON => "Fire OS",
                DeviceOS::GEAR_VR => "Gear VR",
                DeviceOS::HOLOLENS => "Hololens",
                DeviceOS::WINDOWS_10 => "Windows",
                DeviceOS::WIN32 => "Windows 32",
                DeviceOS::DEDICATED => "Dedicated",
                DeviceOS::TVOS => "tvOS",
                DeviceOS::PLAYSTATION => "PlayStation",
                DeviceOS::NINTENDO => "Nintendo Switch",
                DeviceOS::XBOX => "Xbox",
                DeviceOS::WINDOWS_PHONE => "Windows Phone",
                default => "Unknown"
            };
        }
    }

    /**
     * @return string
     */
    public function getDeviceOSIcon(): string
    {
        return match ($this->getDeviceOSName()) {
            "Linux" => "",
            "Android" => "",
            "iOS", "tvOS" => "",
            "macOS" => "",
            "Fire OS" => "",
            "Gear VR", "Hololens" => "",
            "Windows", "Windows 32" => "",
            "PlayStation" => "",
            "Nintendo Switch" => "",
            "Xbox" => "",
            default => ""
        };
    }

    /**
     * @return string
     */
    public function getCurrentInputModeName(): string
    {
        return match ($this->getCurrentInputMode()) {
            InputMode::MOUSE_KEYBOARD => "Keyboard & Mouse",
            InputMode::TOUCHSCREEN => "Touch",
            InputMode::GAME_PAD => "Gamepad",
            InputMode::MOTION_CONTROLLER => "Motion",
            default => "Unknown"
        };
    }

    /**
     * @return string
     */
    public function getPlatform(): string
    {
        return match ($this->getDeviceOSName()) {
            "Android", "iOS", "Fire OS", "Windows Phone" => "Mobile",
            "Windows", "Linux", "macOS", "Windows 32" => "PC",
            "PlayStation", "Nintendo Switch", "Xbox" => "Console",
            "Gear VR", "Hololens" => "VR",
            "Dedicated", "Unknown" => "Undefined",
            default => "Unknown"
        };
    }

    /**
     * @return string
     */
    public function getRank(): string
    {
        return PracticePlugin::getInstance()->getRankManager()->getRankFromArray($this);
    }

    /**
     * @return int
     */
    public function getRankPriority(): int
    {
        return PracticePlugin::getInstance()->getRankManager()->getRankPriorityFromArray($this);
    }

    /**
     * @return string
     */
    public function getRankColored(): string
    {
        return match ($this->getRank()) {
            RankManager::PLAYER_RANK => "§7Player",
            RankManager::MYSTERY_RANK => "§5Mystery",
            RankManager::GANGSTER_RANK => "§aGangster",
            RankManager::IMMORTAL_RANK => "§dImmortal",
            RankManager::SNOWMAN_RANK => "§fSnow§9man",
            RankManager::BOOSTER_RANK => "§gBooster",
            RankManager::FAMOUS_RANK => "§6Famous",
            RankManager::MODERATOR_RANK => "§bModerator",
            RankManager::ADMIN_RANK => "§3Admin",
            RankManager::BUILDER_RANK => "§eBuilder",
            RankManager::STAFF_RANK => "§cStaff",
            RankManager::OWNER_RANK => "§4Owner",
            default => "§0Unknown"
        };
    }

    /**
     * @return string
     */
    public function getRankColor(): string
    {
        return match (PracticePlugin::getInstance()->getRankManager()->getRankByXuid($this)) {
            RankManager::PLAYER_RANK => "§7",
            RankManager::MYSTERY_RANK => "§5",
            RankManager::GANGSTER_RANK => "§a",
            RankManager::IMMORTAL_RANK => "§d",
            RankManager::SNOWMAN_RANK => "§9",
            RankManager::BOOSTER_RANK => "§g",
            RankManager::FAMOUS_RANK => "§6",
            RankManager::MODERATOR_RANK => "§b",
            RankManager::ADMIN_RANK => "§3",
            RankManager::BUILDER_RANK => "§e",
            RankManager::STAFF_RANK => "§c",
            RankManager::OWNER_RANK => "§4",
            default => "§0"
        };
    }

    /**
     * @param Location $damagerLocation
     * @return void
     */
    public function customDeathAnimation(Location $damagerLocation): void
    {
        $deadBody = new FakeDeadHuman($this->getLocation(), $this->getSkin(), $damagerLocation);
        $deadBody->spawnToAll();

        $lightning = new PracticeLightningBoltEntity($this->getLocation());
        $lightning->spawnToAll();
    }
}